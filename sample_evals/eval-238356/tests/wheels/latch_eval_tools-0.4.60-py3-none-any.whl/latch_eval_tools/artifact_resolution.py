"""Inventory submissions and validate Decisions selections, without model credentials."""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any

MAX_FILES = 20_000  # Files a submission may hold; more fail rather than truncate.
MAX_CHOICES = 253  # Decisions permits 255 choices; reserve missing and ambiguous.
# One batch's share of the 192 KiB Decisions request, as sent: its inventory entries (JSON-escaped
# twice, inside the user prompt) and one choice per role. The rest is left for the task, the
# agent's response and the instructions.
BATCH_BYTES = 128 * 1024
PREVIEW_BYTES = 512
MISSING_FILE_FALLBACK_MIN_PROBABILITY = 0.05
RESOLVER_VERSION = "artifact-decisions-v2"
EXCLUDED_ROOTS = {"data", "node_modules", ".git", ".venv", "venv"}
EXCLUDED_HARNESS_FILES = {"trajectory.json", "agent_output.log", "refusal_verdict.json"}


def submission_file(root: Path, relative: str) -> Path:
    path = Path(relative)
    if (
        not relative
        or path.is_absolute()
        or any(p in {"", ".", ".."} for p in relative.split("/"))
    ):
        raise ValueError("artifact path must be a normalized relative path")
    source = root
    for part in path.parts:
        source = source / part
        if source.is_symlink():
            raise ValueError("artifact paths cannot contain symlinks")
    if not source.is_file() or not source.resolve().is_relative_to(root.resolve()):
        raise ValueError("artifact is not a file inside the submission directory")
    return source


def file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def inventory_submission(root: Path, *, include_data: bool = False) -> dict[str, Any]:
    """Include binaries as metadata; never execute or deserialize submitted code.

    `data/` is normally the task's input data and is skipped. `include_data` lists it like any
    other directory, for a workspace whose `data/` holds only files the agent created or changed
    (a rollout with a writable copy of its data, pruned afterwards to the agent's changes)."""
    excluded_roots = EXCLUDED_ROOTS - {"data"} if include_data else EXCLUDED_ROOTS
    if root.is_symlink() or not root.is_dir():
        raise ValueError("submission directory is missing or unsafe")
    files: list[dict[str, Any]] = []
    paths = []
    for directory, directories, names in os.walk(root, followlinks=False):
        directories[:] = sorted(
            name
            for name in directories
            if name not in excluded_roots
            and not name.startswith(".")
            and not (Path(directory) / name).is_symlink()
        )
        for name in sorted(names):
            path = Path(directory) / name
            if not path.is_symlink() and not name.startswith("."):
                paths.append(path)
                if len(paths) > MAX_FILES + len(EXCLUDED_HARNESS_FILES):
                    raise ValueError(
                        f"artifact resolution supports at most {MAX_FILES} files; inventory was not truncated"
                    )
    for path in sorted(paths):
        relative = path.relative_to(root)
        if relative.parts[0] in excluded_roots or any(
            p.startswith(".") for p in relative.parts
        ):
            continue
        if (
            relative.as_posix() in EXCLUDED_HARNESS_FILES
            or not path.is_file()
            or path.is_symlink()
        ):
            continue
        path = submission_file(root, relative.as_posix())
        if len(files) >= MAX_FILES:
            raise ValueError(
                f"artifact resolution supports at most {MAX_FILES} files; inventory was not truncated"
            )
        with path.open("rb") as stream:
            head = stream.read(PREVIEW_BYTES)
        try:
            preview = head.decode("utf-8") if b"\x00" not in head else None
        except UnicodeDecodeError:
            preview = None
        files.append(
            {
                "id": f"file_{len(files)}",
                "path": relative.as_posix(),
                "size_bytes": path.stat().st_size,
                "sha256": file_digest(path),
                "suffix": path.suffix.lower(),
                "preview": preview,
            }
        )
    digest = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()
    return {"version": RESOLVER_VERSION, "digest": digest, "files": files}


def _choice(file: dict[str, Any]) -> dict[str, str]:
    return {"value": file["id"], "description": file["path"]}


def resolution_questions(
    artifacts: dict[str, Any], inventory: dict[str, Any], *, batch: str = ""
) -> list[dict[str, Any]]:
    """One question per role. `batch` (set by `resolution_batches`) says which part of the
    inventory these files are, and that `missing` then means "not among these files"."""
    choices = [_choice(f) for f in inventory["files"]]
    choices += [
        {"value": "missing", "description": "The requested deliverable is absent."},
        {
            "value": "ambiguous",
            "description": "The intended final deliverable cannot be identified reliably.",
        },
    ]
    return [
        {
            "type": "choice",
            "name": name,
            "instructions": f"{batch}Identify the intended final deliverable: {spec['description']}. Choose its file ID using the task, inventory, and agent handoff. Identity is independent of correctness. Choose missing when absent or ambiguous when evidence cannot distinguish candidates.",
            "choices": choices,
        }
        for name, spec in artifacts.items()
    ]


def _sent_bytes(artifacts: dict[str, Any], file: dict[str, Any]) -> int:
    """What one inventory entry adds to a Decisions request: the entry escaped twice (it sits in
    the JSON user prompt, itself a string in the request) and its choice in each role's question."""
    return len(json.dumps(json.dumps(file))) + len(artifacts) * (
        len(json.dumps(_choice(file))) + 2
    )


def resolution_batches(
    artifacts: dict[str, Any], inventory: dict[str, Any]
) -> list[dict[str, Any]] | None:
    """Split an inventory too large for one Decisions request into batches, or None when it fits.

    Each batch, in inventory order, holds at most MAX_CHOICES files and BATCH_BYTES as sent, and
    asks the usual question about its own files. A final call compares their top files."""
    files = inventory["files"]
    if len(files) <= MAX_CHOICES and (
        sum(_sent_bytes(artifacts, f) for f in files) <= BATCH_BYTES
    ):
        return None
    groups: list[list[dict[str, Any]]] = [[]]
    used = 0
    for file in files:
        size = _sent_bytes(artifacts, file)
        if groups[-1] and (len(groups[-1]) >= MAX_CHOICES or used + size > BATCH_BYTES):
            groups.append([])
            used = 0
        groups[-1].append(file)
        used += size
    batches = []
    start = 1
    for group in groups:
        end = start + len(group) - 1
        batch = f"These are files {start}-{end} of the workspace's {len(files)}, asked about in {len(groups)} batches; the deliverable is in at most one of them, so choose missing when it is not among these files. "
        batches.append(
            {
                "file_ids": [f["id"] for f in group],
                "questions": resolution_questions(
                    artifacts, {"files": group}, batch=batch
                ),
            }
        )
        start = end + 1
    return batches


def resolution_finalists(
    artifacts: dict[str, Any],
    inventory: dict[str, Any],
    batches: list[dict[str, Any]],
) -> dict[str, Any]:
    """Validate batches and retain each one's top file per role for a final model comparison.

    Missing/ambiguous do not suppress a batch's top file. Only the final call decides whether
    a deliverable exists. Probabilities from different batches are never compared.
    """
    files = {f["id"]: f for f in inventory["files"]}
    if not batches or [i for b in batches for i in b["file_ids"]] != list(files):
        raise ValueError("artifact resolution batches do not cover the inventory")
    per_batch = [
        bind_resolution(
            artifacts,
            {
                "digest": inventory["digest"],
                "files": [files[i] for i in b["file_ids"]],
            },
            b["decision"],
        )["bindings"]
        for b in batches
    ]
    finalists: dict[str, list[str]] = {}
    questions = []
    for role in artifacts:
        ids = []
        for batch, bound in zip(batches, per_batch):
            probabilities = {
                p["value"]: p["probability"] for p in bound[role]["probabilities"]
            }
            if not batch["file_ids"]:
                continue
            winner = max(batch["file_ids"], key=probabilities.__getitem__)
            # Preserve a tied model choice, otherwise use inventory order.
            choice = bound[role]["choice"]
            if (
                choice in batch["file_ids"]
                and probabilities[choice] == probabilities[winner]
            ):
                winner = choice
            ids.append(winner)
        if len(ids) > MAX_CHOICES:
            raise ValueError("artifact finalists exceed the Decisions choice limit")
        finalists[role] = ids
        questions.extend(
            resolution_questions(
                {role: artifacts[role]},
                {"files": [files[i] for i in ids]},
                batch="These files are the top candidates from separate workspace batches. Compare them together to identify the intended final deliverable. ",
            )
        )
    selected = {i for ids in finalists.values() for i in ids}
    return {
        "inventory": {
            **inventory,
            "files": [f for f in inventory["files"] if f["id"] in selected],
        },
        "file_ids": finalists,
        "questions": questions,
    }


def bind_batched_resolution(
    artifacts: dict[str, Any],
    inventory: dict[str, Any],
    batches: list[dict[str, Any]],
    final_decision: dict[str, Any],
) -> dict[str, Any]:
    """Bind only the final comparison, validating its choices against each role's finalists."""
    finalists = resolution_finalists(artifacts, inventory, batches)
    answers = final_decision.get("answers")
    if not isinstance(answers, list) or len(answers) != len(artifacts):
        raise ValueError("Decisions returned an incomplete artifact mapping")
    files = {f["id"]: f for f in inventory["files"]}
    batch_by_file = {i: n for n, b in enumerate(batches, 1) for i in b["file_ids"]}
    bindings: dict[str, Any] = {}
    for answer in answers:
        role = answer.get("name")
        if role not in artifacts or role in bindings:
            raise ValueError("Decisions returned a duplicate or unknown artifact role")
        bound = bind_resolution(
            {role: artifacts[role]},
            {
                "digest": inventory["digest"],
                "files": [files[i] for i in finalists["file_ids"][role]],
            },
            {"answers": [answer]},
        )["bindings"][role]
        if bound["status"] == "resolved":
            bound["batch"] = batch_by_file[bound["choice"]]
        bindings[role] = bound
    return {
        "version": RESOLVER_VERSION,
        "inventory_digest": inventory["digest"],
        "bindings": bindings,
        "batches": len(batches),
        "finalists": finalists["file_ids"],
    }


def bind_resolution(
    artifacts: dict[str, Any],
    inventory: dict[str, Any],
    decision: dict[str, Any],
    *,
    min_confidence: float | None = None,
    min_margin: float | None = None,
) -> dict[str, Any]:
    """Bind the highest-probability outcome, leaving file correctness to the grader.

    When missing wins, prefer the top file if its probability is strictly above 5%.

    Threshold arguments are accepted but ignored for older published flow callers.
    On a tie, prefer the model's choice if it is tied for first; otherwise use
    inventory order, followed by missing and ambiguous.
    """
    answers = decision.get("answers")
    if not isinstance(answers, list) or len(answers) != len(artifacts):
        raise ValueError("Decisions returned an incomplete artifact mapping")
    candidates = {f["id"]: f for f in inventory["files"]}
    choices = [*candidates, "missing", "ambiguous"]
    allowed = set(choices)
    bindings: dict[str, Any] = {}
    for answer in answers:
        role = answer.get("name")
        if role not in artifacts or role in bindings or answer.get("type") != "choice":
            raise ValueError(
                "Decisions returned a refused, duplicate, or unknown artifact role"
            )
        choice, confidence = answer.get("choice"), answer.get("confidence")
        probabilities = answer.get("probabilities")
        if (
            choice not in allowed
            or type(confidence) not in {int, float}
            or not math.isfinite(confidence)
            or not 0 <= confidence <= 1
            or not isinstance(probabilities, list)
        ):
            raise ValueError("Decisions returned an invalid artifact choice")
        probs: dict[str, float] = {}
        for item in probabilities:
            key, probability = item.get("value"), item.get("probability")
            if (
                key not in allowed
                or key in probs
                or type(probability) not in {int, float}
                or not math.isfinite(probability)
                or not 0 <= probability <= 1
            ):
                raise ValueError("Decisions returned invalid artifact probabilities")
            probs[key] = probability
        if set(probs) != allowed or not math.isclose(
            sum(probs.values()), 1, abs_tol=0.01
        ):
            raise ValueError(
                "Decisions returned an incomplete probability distribution"
            )
        winner = max(choices, key=probs.__getitem__)
        if probs[choice] < probs[winner]:
            choice = winner
        if choice == "missing" and candidates:
            file_choice = max(candidates, key=probs.__getitem__)
            model_choice = answer["choice"]
            if model_choice in candidates and probs[model_choice] == probs[file_choice]:
                file_choice = model_choice
            if probs[file_choice] > MISSING_FILE_FALLBACK_MIN_PROBABILITY:
                choice = file_choice
        margin = probs[choice] - max(
            (p for key, p in probs.items() if key != choice), default=0
        )
        status = choice if choice in {"missing", "ambiguous"} else "resolved"
        binding = {
            "status": status,
            "choice": choice,
            "probability": probs[choice],
            "confidence": confidence,
            "margin": margin,
            "probabilities": probabilities,
        }
        if status == "resolved":
            binding.update(
                {k: candidates[choice][k] for k in ("path", "sha256", "size_bytes")}
            )
        bindings[role] = binding
    return {
        "version": RESOLVER_VERSION,
        "inventory_digest": inventory["digest"],
        "bindings": bindings,
    }


def verified_bindings(root: Path, resolution: dict[str, Any]) -> dict[str, str]:
    result: dict[str, str] = {}
    for role, binding in resolution["bindings"].items():
        if binding["status"] != "resolved":
            continue
        path = submission_file(root, binding["path"])
        if file_digest(path) != binding["sha256"]:
            raise ValueError(f"resolved artifact changed before grading: {role}")
        result[role] = str(path.resolve())
    return result
