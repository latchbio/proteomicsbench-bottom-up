import json
from collections.abc import Iterator
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, field_validator

LLMRefusalProvider = Literal["openai", "anthropic", "google", "xai", "unknown"]
LLMRefusalSource = Literal[
    "workflow_error", "trajectory", "agent_output", "refusal_sidecar"
]

# Refusal diagnostics are included in the bounded V2 agent completion. Budget the
# three free-form fields against their JSON representation so quotes, control
# characters, and multibyte text cannot unexpectedly dominate the completion.
_DIAGNOSTIC_CODE_JSON_BYTES = 512
_DIAGNOSTIC_MESSAGE_JSON_BYTES = 4096
_DIAGNOSTIC_RAW_EXCERPT_JSON_BYTES = 4096
_TRUNCATION_MARKER = "…"


_SIDECAR_PROVIDER_MAP: dict[str, LLMRefusalProvider] = {
    "anthropic": "anthropic",
    "anthropic-messages": "anthropic",
    "openai-completions": "openai",
    "openai": "openai",
    "openai-responses": "openai",
    "google": "google",
    "google-generative-ai": "google",
    "google-vertex": "google",
}


def _json_string_size_bytes(value: str) -> int:
    return len(json.dumps(value, ensure_ascii=False).encode("utf-8"))


def _truncate_json_string(value: str, *, max_bytes: int) -> str:
    value = value.replace("\x00", "\ufffd")
    if _json_string_size_bytes(value) <= max_bytes:
        return value

    # Search by Unicode code point while measuring the encoded JSON string. This
    # keeps the result valid UTF-8 and accounts for JSON escaping expansion.
    low = 0
    high = len(value)
    while low < high:
        midpoint = (low + high + 1) // 2
        candidate = f"{value[:midpoint]}{_TRUNCATION_MARKER}"
        if _json_string_size_bytes(candidate) <= max_bytes:
            low = midpoint
        else:
            high = midpoint - 1
    return f"{value[:low]}{_TRUNCATION_MARKER}"


class LLMRefusalDiagnostic(BaseModel):
    model_config = ConfigDict(frozen=True)

    kind: Literal["llm_refusal"] = "llm_refusal"
    provider: LLMRefusalProvider
    code: str | None = None
    message: str
    source: LLMRefusalSource
    raw_excerpt: str | None = None

    @field_validator("code")
    @classmethod
    def _bound_code(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _truncate_json_string(value, max_bytes=_DIAGNOSTIC_CODE_JSON_BYTES)

    @field_validator("message")
    @classmethod
    def _bound_message(cls, value: str) -> str:
        return _truncate_json_string(value, max_bytes=_DIAGNOSTIC_MESSAGE_JSON_BYTES)

    @field_validator("raw_excerpt")
    @classmethod
    def _bound_raw_excerpt(cls, value: str | None) -> str | None:
        if value is None:
            return None
        return _truncate_json_string(
            value,
            max_bytes=_DIAGNOSTIC_RAW_EXCERPT_JSON_BYTES,
        )


def _parse_json_record(value: str | None) -> dict[str, Any] | None:
    if value is None or value == "":
        return None
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


# These are message/provider envelopes emitted by Pi, Claude Code, Codex and
# the OpenAI APIs. Unknown event types are not evidence. Add new harness formats
# here with a contract test; never fall back to walking arbitrary JSON values.
_REFUSAL_ENVELOPE_TYPES = frozenset(
    {
        "assistant",
        "message",
        "message_start",
        "message_delta",
        "message_end",
        "turn_end",
        "agent_end",
        "result",
        "error",
        "invalid_request_error",
        "harness_error",
        "turn.failed",
        "response",
        "response.failed",
        "response.completed",
        "response.incomplete",
        "response.refusal.delta",
        "response.refusal.done",
        "completion.chunk",
        "chat.completion",
        "chat.completion.chunk",
        "item.completed",
        "agent_message",
        "text",
        "output_text",
        "refusal",
    }
)
_REFUSAL_TEXT_FIELDS = (
    "text",
    "message",
    "content",
    "result",
    "refusal",
)
_REFUSAL_ERROR_FIELDS = ("error", "error_message", "errorMessage", "exception_str")
_REFUSAL_ERROR_TYPES = frozenset(
    {
        "error",
        "invalid_request_error",
        "harness_error",
        "turn.failed",
        "response.failed",
    }
)
_REFUSAL_SIGNAL_FIELDS = (
    "code",
    "stop_reason",
    "stopReason",
    "finish_reason",
    "finishReason",
    # Gemini prompt-level blocks (promptFeedback.blockReason) are merged into
    # the parent record under these keys.
    "block_reason",
    "blockReason",
)
_REFUSAL_CONTAINER_FIELDS = (
    # AgentWorkflowOutput wraps structured harness error details in agent_result.
    "agent_result",
    "messages",
    "message",
    "response",
    "choices",
    # Gemini: each candidate carries its own finishReason.
    "candidates",
    "delta",
    "content",
    "output",
    "item",
)
# Gemini finishReason / promptFeedback.blockReason values that mean the
# provider declined to answer. STOP, MAX_TOKENS, OTHER and the like are not
# refusals. Mirrors the Pi sidecar list in pi_extensions/provider_events.js.
_GOOGLE_BLOCK_REASONS = frozenset(
    {
        "SAFETY",
        "PROHIBITED_CONTENT",
        "BLOCKLIST",
        "SPII",
        "RECITATION",
        "IMAGE_SAFETY",
        "IMAGE_PROHIBITED_CONTENT",
        "IMAGE_RECITATION",
        "IMAGE_OTHER",
    }
)
# OpenAI / Azure OpenAI structured error codes for policy rejections.
_OPENAI_REFUSAL_CODES = frozenset(
    {
        "cyber_policy",
        "biological_risk",
        "bio_policy",
        "content_policy_violation",
        "invalid_prompt",
        "moderation_blocked",
        "content_filter",
        "ResponsibleAIPolicyViolation",
    }
)


def _merge_nested_signals(
    value: dict[str, Any], record: dict[str, str]
) -> dict[str, str]:
    """Fold provider sub-objects into the parent record.

    OpenAI Responses `incomplete_details.reason` and Gemini
    `promptFeedback.blockReason` sit one level below the fields the string scan
    reads. Folding them into the same record keeps the first-match semantics
    and lets the block reason become the diagnostic code.

    Anthropic `stop_details` is deliberately not read here. The bare
    `stop_reason` of "refusal" or "sensitive" is still recognized on its own by
    `_detect_from_record`.
    """
    merged = dict(record)

    incomplete = value.get("incomplete_details")
    if isinstance(incomplete, dict):
        reason = incomplete.get("reason")
        if isinstance(reason, str) and reason and "finish_reason" not in merged:
            merged["finish_reason"] = reason

    prompt_feedback = value.get("promptFeedback")
    if not isinstance(prompt_feedback, dict):
        prompt_feedback = value.get("prompt_feedback")
    if isinstance(prompt_feedback, dict):
        block_reason = prompt_feedback.get("blockReason")
        if not isinstance(block_reason, str):
            block_reason = prompt_feedback.get("block_reason")
        if (
            isinstance(block_reason, str)
            and block_reason
            and "block_reason" not in merged
        ):
            merged["block_reason"] = block_reason
        block_message = prompt_feedback.get("blockReasonMessage")
        if not isinstance(block_message, str):
            block_message = prompt_feedback.get("block_reason_message")
        if isinstance(block_message, str) and block_message and "message" not in merged:
            merged = {"message": block_message, **merged}

    return merged


def _iter_refusal_records(
    value: object, *, error_context: bool = False
) -> Iterator[tuple[dict[str, str], bool]]:
    """Select response/error fields with their error-channel provenance.

    In particular, tool results (even failed ones), tool arguments, prompts,
    reasoning and metadata must never become provider-refusal evidence. Legacy
    role-less records remain supported, but only through the same named fields.
    Explicit error payloads may use provider-specific `type` discriminators.
    Response prose is diagnostic context only; it cannot establish a refusal.
    """
    if isinstance(value, str):
        if value:
            yield {"message": value}, error_context
        return
    if isinstance(value, list):
        for item in value:
            yield from _iter_refusal_records(item, error_context=error_context)
        return
    if not isinstance(value, dict):
        return

    role = value.get("role")
    if role is not None and role != "assistant":
        return
    event_type = value.get("type")
    # Claude's partial stream and Codex's session transcript each wrap a typed
    # event. Only these envelopes may contribute their otherwise opaque payload.
    if event_type == "stream_event":
        yield from _iter_refusal_records(value.get("event"))
        return
    if event_type == "response_item":
        yield from _iter_refusal_records(value.get("payload"))
        return
    if event_type is not None and (
        not isinstance(event_type, str)
        or (event_type not in _REFUSAL_ENVELOPE_TYPES and not error_context)
    ):
        return

    error_context = event_type in _REFUSAL_ERROR_TYPES or (
        error_context and role is None and event_type not in _REFUSAL_ENVELOPE_TYPES
    )

    # Grok puts assistant text in data; data on tool/unknown events stays opaque.
    if event_type == "text" and isinstance(value.get("data"), str):
        yield {"text": value["data"]}, False
    if event_type == "error":
        yield from _iter_refusal_records(value.get("data"), error_context=True)
    # OpenAI Responses streams refusal text as a string delta on its own event.
    if event_type in {"response.refusal.delta", "response.refusal.done"}:
        refusal_text = value.get("delta")
        if not isinstance(refusal_text, str):
            refusal_text = value.get("refusal")
        if isinstance(refusal_text, str) and refusal_text:
            yield {"refusal": refusal_text}, False
    record = {
        key: item
        for key in (*_REFUSAL_TEXT_FIELDS, *_REFUSAL_SIGNAL_FIELDS)
        if isinstance(item := value.get(key), str) and item
    }
    record = _merge_nested_signals(value, record)
    if record:
        yield record, error_context
    error_record = {
        key: item
        for key in _REFUSAL_ERROR_FIELDS
        if isinstance(item := value.get(key), str) and item
    }
    if error_record:
        # Carry the sibling error code alongside the message. Providers that
        # split the transport signal (`code`) from the decline text (`error`)
        # across two keys of the same object -- xAI's 403 does exactly this --
        # are otherwise impossible to judge, since neither half is evidence
        # on its own.
        sibling_code = value.get("code")
        if isinstance(sibling_code, str) and sibling_code:
            error_record.setdefault("code", sibling_code)
        yield error_record, True
    for key in _REFUSAL_CONTAINER_FIELDS:
        child = value.get(key)
        if isinstance(child, (dict, list)):
            yield from _iter_refusal_records(child)
    # Azure OpenAI nests the policy code under error.innererror.
    for key in ("error", "errors", "innererror"):
        child = value.get(key)
        if isinstance(child, (dict, list)):
            yield from _iter_refusal_records(child, error_context=True)


# Decline wording xAI returns in a 403 body. Only ever consulted alongside the
# `permission-denied` transport signal -- never on its own.
_XAI_DECLINE_MARKERS: tuple[str, ...] = (
    "can't help with that",
    "cannot help with that",
    "can't assist with that",
    "cannot assist with that",
)
_ANTHROPIC_FALLBACK_MARKERS: tuple[str, ...] = (
    "refusals-and-fallback",
    "configuring a fallback model",
    "reduce refusals for your users",
)


def _find_message(
    strings: list[str], provider: Literal["openai", "anthropic", "google", "xai"]
) -> str:
    provider_markers: tuple[str, ...]
    if provider == "xai":
        provider_markers = _XAI_DECLINE_MARKERS
    elif provider == "openai":
        provider_markers = (
            "invalid prompt",
            "limited access",
            "safety reasons",
            "cyber policy",
            "content_filter",
            "safety system",
        )
    elif provider == "google":
        provider_markers = (
            "blocked",
            "safety",
            "prohibited",
        )
    else:
        provider_markers = (
            "unable to respond",
            "usage policy",
            "violat",
        ) + _ANTHROPIC_FALLBACK_MARKERS

    for item in strings:
        lowered = item.lower()
        if any(marker in lowered for marker in provider_markers):
            return item
    for item in strings:
        if item.strip():
            return item
    return "The model refused to respond to this request."


def _co_occurring_string(
    strings: list[str],
    lowered_strings: list[str],
    required: str,
    alternatives: tuple[str, ...],
) -> str | None:
    """Match provider wording within one error field, never across records."""
    for item, lowered_item in zip(strings, lowered_strings):
        if required in lowered_item and any(
            alternative in lowered_item for alternative in alternatives
        ):
            return item
    return None


def _excerpt(strings: list[str]) -> str | None:
    joined = "\n".join(item for item in strings if item.strip())
    if joined == "":
        return None
    return joined[:1000]


def _diagnostic_from_sidecar(record: dict[str, Any]) -> LLMRefusalDiagnostic:
    raw_provider = record.get("provider")
    provider = (
        _SIDECAR_PROVIDER_MAP.get(raw_provider, "unknown")
        if isinstance(raw_provider, str)
        else "unknown"
    )
    raw_reason = record.get("raw_reason")
    explanation = record.get("explanation")
    message = (
        explanation
        if isinstance(explanation, str) and explanation
        else f"Model refusal ({raw_reason or 'unknown reason'})"
    )
    return LLMRefusalDiagnostic(
        provider=provider,
        code=raw_reason if isinstance(raw_reason, str) else None,
        message=message,
        source="refusal_sidecar",
        raw_excerpt=json.dumps(record)[:1000],
    )


def _detect_from_record(
    record: dict[str, str], *, source: LLMRefusalSource, error_context: bool
) -> LLMRefusalDiagnostic | None:
    strings = list(record.values())
    lowered_strings = [item.lower() for item in strings]
    lowered = "\n".join(lowered_strings)
    code = record.get("code")
    stop_reason = record.get("stop_reason") or record.get("stopReason")
    finish_reason = record.get("finish_reason") or record.get("finishReason")
    block_reason = record.get("block_reason") or record.get("blockReason")

    # OpenAI message/content-block refusals are explicit signals even when the
    # refusal text itself contains none of the fallback wording below.
    refusal_text = record.get("refusal")
    if refusal_text is not None:
        return LLMRefusalDiagnostic(
            provider="openai",
            code=code or "refusal",
            message=refusal_text,
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    if stop_reason in {"refusal", "sensitive"}:
        return LLMRefusalDiagnostic(
            provider="anthropic",
            code=code or stop_reason,
            message=_find_message(strings, "anthropic"),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    if code in _OPENAI_REFUSAL_CODES or finish_reason == "content_filter":
        return LLMRefusalDiagnostic(
            provider="openai",
            code=code or finish_reason or "cyber_policy",
            message=_find_message(strings, "openai"),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    # Gemini: a blocked prompt reports promptFeedback.blockReason with no
    # candidates; a blocked response reports the candidate's finishReason.
    if block_reason is not None or finish_reason in _GOOGLE_BLOCK_REASONS:
        return LLMRefusalDiagnostic(
            provider="google",
            code=block_reason or finish_reason,
            message=_find_message(strings, "google"),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    # A model can quote even an exact provider rejection in an ordinary answer.
    # Text compatibility belongs only to errors whose envelope/field identifies
    # them as such. Semantic refusals in answer prose belong to evaluation.
    if not error_context:
        return None

    anthropic_fallback_hit = any(
        marker in lowered for marker in _ANTHROPIC_FALLBACK_MARKERS
    )
    anthropic_policy_hit = _co_occurring_string(
        strings,
        lowered_strings,
        "usage policy",
        ("claude", "anthropic", "unable to respond"),
    )
    if anthropic_policy_hit is not None or anthropic_fallback_hit:
        return LLMRefusalDiagnostic(
            provider="anthropic",
            code=code or "refusal",
            message=anthropic_policy_hit or _find_message(strings, "anthropic"),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    if "cyber policy" in lowered:
        return LLMRefusalDiagnostic(
            provider="openai",
            code=code or "cyber_policy",
            message=_find_message(strings, "openai"),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    # Codex can surface a provider safety rejection as a message-only error,
    # without a content_filter finish reason or structured refusal code.
    openai_biology_hit = next(
        (
            message
            for message in strings
            if "this content was flagged for possible biological risk"
            in message.lower()
        ),
        None,
    )
    if openai_biology_hit is not None:
        return LLMRefusalDiagnostic(
            provider="openai",
            code=code or "biological_risk",
            message=openai_biology_hit,
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    openai_prompt_hit = _co_occurring_string(
        strings, lowered_strings, "invalid prompt", ("openai", "limited access")
    )
    openai_safety_hit = _co_occurring_string(
        strings, lowered_strings, "limited access to this content", ("safety reasons",)
    )

    if (
        "invalid_prompt" in lowered
        or openai_prompt_hit is not None
        or openai_safety_hit is not None
    ):
        return LLMRefusalDiagnostic(
            provider="openai",
            code=code or "invalid_prompt",
            message=(
                openai_prompt_hit
                or openai_safety_hit
                or _find_message(strings, "openai")
            ),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    # xAI declines a policy-blocked turn with an HTTP 403 whose body is the
    # decline sentence itself -- no finish_reason, no structured code. Verified
    # against api.x.ai on 2026-10-20: `{'code': 'permission-denied', 'error':
    # "I'm sorry, I can't help with that request."}`. The decline wording alone
    # is far too generic to be evidence, so require the transport-level
    # permission signal to co-occur with it in the same error record.
    if (code == "permission-denied" or "permission-denied" in lowered) and any(
        marker in lowered for marker in _XAI_DECLINE_MARKERS
    ):
        return LLMRefusalDiagnostic(
            provider="xai",
            code="permission-denied",
            message=_find_message(strings, "xai"),
            source=source,
            raw_excerpt=_excerpt(strings),
        )

    return None


def _detect_from_value(
    value: object, *, source: LLMRefusalSource, error_context: bool = False
) -> LLMRefusalDiagnostic | None:
    for record, record_is_error in _iter_refusal_records(
        value, error_context=error_context
    ):
        refusal = _detect_from_record(
            record, source=source, error_context=record_is_error
        )
        if refusal is not None:
            return refusal
    return None


def detect_llm_refusal(
    *,
    trajectory_data: Any | None = None,
    workflow_error_data: str | None = None,
    agent_error: str | None = None,
    agent_output_data: Any | None = None,
    refusal_events_data: list[dict[str, Any]] | None = None,
) -> LLMRefusalDiagnostic | None:
    if refusal_events_data:
        first = refusal_events_data[0]
        if isinstance(first, dict):
            return _diagnostic_from_sidecar(first)

    trajectory_refusal = _detect_from_value(trajectory_data, source="trajectory")
    if trajectory_refusal is not None:
        return trajectory_refusal

    workflow_error = _parse_json_record(workflow_error_data)
    workflow_refusal = _detect_from_value(
        workflow_error if workflow_error is not None else workflow_error_data,
        source="workflow_error",
        error_context=True,
    )
    if workflow_refusal is not None:
        return workflow_refusal

    agent_output_refusal = _detect_from_value(agent_output_data, source="agent_output")
    if agent_output_refusal is not None:
        return agent_output_refusal

    return _detect_from_value(agent_error, source="agent_output", error_context=True)
