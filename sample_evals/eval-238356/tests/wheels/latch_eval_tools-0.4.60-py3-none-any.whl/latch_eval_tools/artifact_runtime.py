"""Execute an artifact grading package: unpack the tarball, run `grader.sh`, read `results.json`.

This is the half of the artifact grader that has no opinion about where it runs. It takes a
tarball that is already on local disk and a rollout output directory that is already mounted, so
the same code runs inside a Yeast func sandbox (`yeast_flows.graders.grade_artifact`) and in
tests. Fetching the package from Latch Data and choosing the sandbox are the caller's job.

Everything the package itself does wrong (non-zero exit, timeout, missing or invalid
`results.json`) becomes a fail-closed payload with `metrics.grader_system_error`, never an
exception: the platform reports those as grader failures rather than wrong answers.
"""

import json
import os
import subprocess
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Optional

from latch_eval_tools.graders.artifact import (
    ARTIFACT_ENTRYPOINT,
    ARTIFACT_RESULTS_FILENAME,
    ARTIFACT_STDERR_FILENAME,
    artifact_system_error_payload,
    normalize_artifact_payload,
    validate_artifact_results,
)

MAX_RESULTS_BYTES = 8 * 1024 * 1024


class PackageError(ValueError):
    """The tarball is not a usable artifact grading package."""


def _safe_member(member: tarfile.TarInfo, dest: Path) -> bool:
    """A member is safe when it is a regular file or directory whose resolved path stays under
    `dest`. Symlinks, hardlinks, devices and FIFOs are refused outright."""
    if not (member.isfile() or member.isdir()):
        return False
    name = member.name
    if name.startswith("/") or os.path.isabs(name):
        return False
    target = (dest / name).resolve()
    dest_resolved = dest.resolve()
    return target == dest_resolved or dest_resolved in target.parents


def extract_package(tarball: Path, dest: Path) -> Path:
    """Unpack `tarball` (gzip or plain tar) into `dest` and return the package directory, which
    is `dest` itself or its single top-level directory when the archive was rooted that way.
    Raises `PackageError` when the archive is unreadable, contains unsafe members, or has no
    `grader.sh` at the package root."""
    dest.mkdir(parents=True, exist_ok=True)
    try:
        with tarfile.open(tarball, mode="r:*") as archive:
            members = archive.getmembers()
            unsafe = [m.name for m in members if not _safe_member(m, dest)]
            if unsafe:
                raise PackageError(
                    f"package contains unsafe members (links, devices or paths outside the archive): {unsafe[:5]}"
                )
            if hasattr(tarfile, "data_filter"):
                archive.extractall(dest, members=members, filter="data")
            else:
                archive.extractall(dest, members=members)
    except tarfile.TarError as exc:
        raise PackageError(f"package is not a readable tar archive: {exc}") from exc
    if (dest / ARTIFACT_ENTRYPOINT).is_file():
        return dest
    entries = [p for p in dest.iterdir() if p.name not in {"__MACOSX"}]
    if (
        len(entries) == 1
        and entries[0].is_dir()
        and (entries[0] / ARTIFACT_ENTRYPOINT).is_file()
    ):
        return entries[0]
    raise PackageError(f"package has no {ARTIFACT_ENTRYPOINT} at its root")


def grader_argv(
    package_dir: Path,
    *,
    rollout_output_dir: Path,
    trajectory_path: Path,
    grader_output_dir: Path,
    artifact_map_path: Optional[Path] = None,
) -> list[str]:
    argv = [
        "bash",
        str(package_dir / ARTIFACT_ENTRYPOINT),
        "--rollout_output_dir",
        str(rollout_output_dir),
        "--trajectory_path",
        str(trajectory_path),
        "--grader_output_dir",
        str(grader_output_dir),
    ]
    if artifact_map_path is not None:
        argv.extend(["--artifact_map_path", str(artifact_map_path)])
    return argv


def run_artifact_package(
    package_dir: Path,
    *,
    rollout_output_dir: Path,
    trajectory_path: Optional[Path],
    grader_output_dir: Path,
    timeout_seconds: int,
    env: Optional[dict[str, str]] = None,
    artifact_map_path: Optional[Path] = None,
    grader_paths: Optional[dict[str, str]] = None,
) -> dict[str, Any]:
    """Run a package using the eval's declared file-input or artifact-map interface.

    With grader_paths, copy verified Decisions selections to the declared paths in
    a private submission directory and use the existing three-argument package CLI.
    Otherwise retain the artifact-map CLI when a map is supplied. Neither the package
    nor the original submission changes; there is no retry that bypasses Decisions.
    """
    if grader_paths is not None:
        from latch_eval_tools.artifact_inputs import stage_artifact_inputs

        try:
            if artifact_map_path is None:
                raise ValueError("grader_paths requires an artifact resolution map")
            grader_output_dir.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(
                prefix="resolved-inputs-", dir=grader_output_dir
            ) as directory:
                submission = Path(directory)
                inputs = stage_artifact_inputs(
                    grader_paths,
                    rollout_output_dir=rollout_output_dir,
                    artifact_map_path=artifact_map_path,
                    destination=submission,
                )
                payload = _run_artifact_package(
                    package_dir,
                    rollout_output_dir=submission,
                    trajectory_path=trajectory_path,
                    grader_output_dir=grader_output_dir,
                    timeout_seconds=timeout_seconds,
                    env=env,
                )
            payload["metrics"]["artifact_inputs"] = inputs
            return payload
        except (OSError, ValueError, KeyError, TypeError) as error:
            return artifact_system_error_payload(
                f"declared artifact inputs could not be prepared: {error}"
            )
    return _run_artifact_package(
        package_dir,
        rollout_output_dir=rollout_output_dir,
        trajectory_path=trajectory_path,
        grader_output_dir=grader_output_dir,
        timeout_seconds=timeout_seconds,
        env=env,
        artifact_map_path=artifact_map_path,
    )


def _run_artifact_package(
    package_dir: Path,
    *,
    rollout_output_dir: Path,
    trajectory_path: Optional[Path],
    grader_output_dir: Path,
    timeout_seconds: int,
    env: Optional[dict[str, str]] = None,
    artifact_map_path: Optional[Path] = None,
) -> dict[str, Any]:
    """Run the package's `grader.sh` and return a valid per-grader payload.

    `trajectory_path` is always passed on the command line (the contract has three positional
    options and packages may require all of them); when the rollout left no trajectory the path
    points at `<grader_output_dir>/trajectory-missing.json`, which does not exist. The package's
    stderr is written to `<grader_output_dir>/stderr.log` and its tail goes into the reasoning of
    any fail-closed payload."""
    grader_output_dir.mkdir(parents=True, exist_ok=True)
    results_path = grader_output_dir / ARTIFACT_RESULTS_FILENAME
    stderr_path = grader_output_dir / ARTIFACT_STDERR_FILENAME
    if trajectory_path is None:
        trajectory_path = grader_output_dir / "trajectory-missing.json"
    argv = grader_argv(
        package_dir,
        rollout_output_dir=rollout_output_dir,
        trajectory_path=trajectory_path,
        grader_output_dir=grader_output_dir,
        artifact_map_path=artifact_map_path,
    )
    process_env = {**os.environ, **(env or {})}
    try:
        completed = subprocess.run(
            argv,
            cwd=package_dir,
            env=process_env,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        stderr = (
            exc.stderr
            if isinstance(exc.stderr, str)
            else (exc.stderr or b"").decode("utf-8", "replace")
        )
        stderr_path.write_text(stderr, encoding="utf-8")
        return artifact_system_error_payload(
            f"{ARTIFACT_ENTRYPOINT} exceeded its {timeout_seconds}s timeout",
            stderr=stderr,
        )
    except OSError as exc:
        return artifact_system_error_payload(
            f"could not start {ARTIFACT_ENTRYPOINT}: {exc}"
        )
    stderr_path.write_text(completed.stderr, encoding="utf-8")
    if completed.returncode != 0:
        reason = f"{ARTIFACT_ENTRYPOINT} exited with status {completed.returncode}"
        if (
            artifact_map_path is not None
            and "unrecognized arguments: --artifact_map_path" in completed.stderr
        ):
            reason += (
                "; package does not accept --artifact_map_path. Declare grader_path for "
                "every config.artifacts role to use fixed-path inputs, or update the "
                "package to read the artifact map."
            )
        return artifact_system_error_payload(
            reason,
            stderr=completed.stderr,
        )
    if not results_path.is_file():
        return artifact_system_error_payload(
            f"{ARTIFACT_ENTRYPOINT} did not write {ARTIFACT_RESULTS_FILENAME}",
            stderr=completed.stderr,
        )
    if results_path.stat().st_size > MAX_RESULTS_BYTES:
        return artifact_system_error_payload(
            f"{ARTIFACT_RESULTS_FILENAME} is larger than {MAX_RESULTS_BYTES} bytes",
            stderr=completed.stderr,
        )
    try:
        payload = json.loads(
            results_path.read_text(encoding="utf-8"), parse_constant=_reject_constant
        )
    except ValueError as exc:
        return artifact_system_error_payload(
            f"{ARTIFACT_RESULTS_FILENAME} is not valid JSON: {exc}",
            stderr=completed.stderr,
        )
    problems = validate_artifact_results(payload)
    if problems:
        return artifact_system_error_payload(
            f"{ARTIFACT_RESULTS_FILENAME} is invalid: " + "; ".join(problems),
            stderr=completed.stderr,
        )
    return normalize_artifact_payload(payload)


def _reject_constant(name: str) -> Any:
    raise ValueError(f"{name} is not valid JSON")
