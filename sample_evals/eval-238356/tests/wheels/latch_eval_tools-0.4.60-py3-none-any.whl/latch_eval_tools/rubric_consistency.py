"""Compatibility alias for the shared rubric implementation."""

import sys

from latch_eval_tools._rubric import rubric_consistency as _implementation

sys.modules[__name__] = _implementation
