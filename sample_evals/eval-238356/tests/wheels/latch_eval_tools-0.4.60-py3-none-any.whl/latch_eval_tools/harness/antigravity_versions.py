"""Bounded Antigravity release selection and immutable per-run installation data."""

import json
import re
from pathlib import Path
from typing import Self
from urllib.request import urlopen

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, model_validator

ANTIGRAVITY_MIN_VERSION = (1, 5, 9)
ANTIGRAVITY_MAX_VERSION = (1, 6, 0)
ANTIGRAVITY_VERSION_RANGE = (
    f">={'.'.join(map(str, ANTIGRAVITY_MIN_VERSION))} "
    f"<{'.'.join(map(str, ANTIGRAVITY_MAX_VERSION))}"
)
ANTIGRAVITY_VERSION_RECORD = "harness_version.json"
ANTIGRAVITY_RELEASES_URL = (
    "https://antigravity-cli-auto-updater-974169037036.us-central1.run.app/releases"
)
ANTIGRAVITY_DOWNLOAD_ROOT = (
    "https://storage.googleapis.com/antigravity-public/antigravity-cli"
)
STABLE_VERSION = re.compile(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)")


def supported_antigravity_version(version: str) -> tuple[int, int, int] | None:
    match = STABLE_VERSION.fullmatch(version)
    if match is None:
        return None
    parsed = (int(match[1]), int(match[2]), int(match[3]))
    return (
        parsed if ANTIGRAVITY_MIN_VERSION <= parsed < ANTIGRAVITY_MAX_VERSION else None
    )


def normalize_antigravity_version(version: str) -> str:
    version = version.strip()
    if version != "latest" and supported_antigravity_version(version) is None:
        raise ValueError(
            f"Antigravity requires latest or a stable version {ANTIGRAVITY_VERSION_RANGE}"
        )
    return version


class AntigravityRelease(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, extra="forbid")

    requested_version: str
    resolved_version: str
    url: str
    sha512: str = Field(pattern=r"^[0-9a-f]{128}$")

    @model_validator(mode="after")
    def validate_release(self) -> Self:
        normalize_antigravity_version(self.requested_version)
        if supported_antigravity_version(self.resolved_version) is None:
            raise ValueError("Antigravity release must have a supported exact version")
        if self.requested_version not in {"latest", self.resolved_version}:
            raise ValueError("Antigravity release differs from the requested version")
        prefix = re.escape(f"{ANTIGRAVITY_DOWNLOAD_ROOT}/{self.resolved_version}-")
        if (
            re.fullmatch(prefix + r"[0-9]+/linux-x64/cli_linux_x64\.tar\.gz", self.url)
            is None
        ):
            raise ValueError("Antigravity release has an unexpected download URL")
        return self


class _ReleaseIndexEntry(BaseModel):
    model_config = ConfigDict(strict=True)

    version: str
    execution_id: str = Field(pattern=r"^[0-9]+$")


class _ReleaseManifest(BaseModel):
    model_config = ConfigDict(strict=True)

    version: str
    url: str
    sha512: str


def resolve_antigravity_version(version: str, record_path: Path) -> AntigravityRelease:
    """Resolve from the full official catalog, then reuse the recorded artifact.

    The current-release manifest alone cannot resolve a bounded latest after a
    new minor ships. Historical manifests retain each release's URL and digest.
    """
    requested = normalize_antigravity_version(version)
    if record_path.exists():
        release = AntigravityRelease.model_validate_json(record_path.read_text())
        if release.requested_version != requested:
            raise ValueError("Antigravity version record does not match this run")
        return release

    with urlopen(ANTIGRAVITY_RELEASES_URL, timeout=30) as response:
        entries = TypeAdapter(list[_ReleaseIndexEntry]).validate_python(
            json.load(response)
        )
    candidates = []
    for entry in entries:
        parsed = supported_antigravity_version(entry.version)
        if parsed is not None and requested in {"latest", entry.version}:
            candidates.append((parsed, entry))
    if not candidates:
        raise ValueError(
            f"No Antigravity release satisfies {requested!r} ({ANTIGRAVITY_VERSION_RANGE})"
        )
    _, selected = max(candidates, key=lambda candidate: candidate[0])
    artifact_root = f"{ANTIGRAVITY_DOWNLOAD_ROOT}/{selected.version}-{selected.execution_id}/linux-x64"
    with urlopen(f"{artifact_root}/manifest.json", timeout=30) as response:
        manifest = _ReleaseManifest.model_validate(json.load(response))
    if manifest.version != selected.version or manifest.url != (
        f"{artifact_root}/cli_linux_x64.tar.gz"
    ):
        raise ValueError("Antigravity manifest does not match the selected release")
    release = AntigravityRelease(
        requested_version=requested,
        resolved_version=manifest.version,
        url=manifest.url,
        sha512=manifest.sha512,
    )
    temporary = record_path.with_suffix(".tmp")
    temporary.write_text(release.model_dump_json(indent=2) + "\n")
    temporary.replace(record_path)
    return release
