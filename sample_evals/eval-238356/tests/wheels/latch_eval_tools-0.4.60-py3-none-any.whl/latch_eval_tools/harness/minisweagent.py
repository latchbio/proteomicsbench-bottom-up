import io
import json
import os
import shlex
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml
from openai import APIConnectionError, APIError, APIStatusError

from latch_eval_tools.harness.llm_connection import (
    GatewayConnection,
)
from latch_eval_tools.harness.output import read_legacy_answer
from latch_eval_tools.harness.run_summary import build_miniswe_run_summary
from latch_eval_tools.harness.termination import HarnessErrorCode
from latch_eval_tools.harness.utils import (
    COMPLETION_MARKERS,
    DEFAULT_DOCKER_IMAGE,
    benchmark_convention,
    ensure_docker_image,
    find_answer_file,
    find_finished_file,
    get_agent_workspace_dir,
    get_agent_workspace_mount_args,
    get_memory_limit_bytes,
    is_docker_container_oom_killed,
    is_docker_container_running,
    load_data_instructions,
    prompt_with_suffix,
    read_packaged_prompt,
    render_packaged_prompt,
)

OPERATION_TIMEOUT = 300
EVAL_TIMEOUT = 600
OOM_EXIT_CODE = 137
MAX_OOM_RESTARTS = 10
MAX_TOOL_OUTPUT_BYTES = 64 * 1024
UTF8_SIZE_CHUNK_CHARS = 1024 * 1024


def _failure_details(
    *,
    exit_status: str | None,
    timed_out: bool,
    agent_error: Exception | None,
    output_error: dict[str, Any] | None,
) -> dict[str, Any] | None:
    details = dict(output_error or {})
    code: HarnessErrorCode | None = None
    if timed_out or exit_status in {"LimitsExceeded", "TimeExceeded"}:
        code = "agent_budget_exhausted"
    elif exit_status == "EnvironmentFailed" or isinstance(agent_error, OSError):
        code = "harness_execution_failed"
    elif agent_error is not None:
        code = "agent_turn_failed"
    elif output_error is not None:
        code = (
            "harness_execution_failed"
            if output_error.get("error_code") == "harness_execution_failed"
            else "output_contract_failed"
        )
    if code is None:
        return None
    details.update(error_code=code, timed_out=timed_out)
    details.setdefault("error", str(agent_error) if agent_error is not None else code)
    # LiteLLM's provider exceptions inherit OpenAI's concrete exception classes.
    if isinstance(agent_error, APIStatusError):
        details["api_error_status"] = agent_error.status_code
    elif isinstance(agent_error, APIError):
        details["api_error_code"] = (
            "provider_stream_error"
            if isinstance(agent_error, APIConnectionError)
            else "provider_api_error"
        )
    return details


def _utf8_size_bytes(value: str) -> int:
    if value.isascii():
        return len(value)

    size_bytes = 0
    for offset in range(0, len(value), UTF8_SIZE_CHUNK_CHARS):
        chunk = value[offset : offset + UTF8_SIZE_CHUNK_CHARS]
        size_bytes += len(chunk.encode("utf-8"))
    return size_bytes


def _utf8_prefix_within_budget(value: str, budget_bytes: int) -> str:
    candidate = value[:budget_bytes].encode("utf-8")
    return candidate[:budget_bytes].decode("utf-8", errors="ignore")


def _utf8_suffix_within_budget(value: str, budget_bytes: int) -> str:
    candidate = value[-budget_bytes:].encode("utf-8")
    return candidate[-budget_bytes:].decode("utf-8", errors="ignore")


def _truncate_message_raw_output(message: dict[str, Any]) -> None:
    raw_extra = message.get("extra")
    if raw_extra is None:
        return
    if not isinstance(raw_extra, dict):
        raise TypeError("mini-swe-agent message extra must be a dictionary")

    raw_output = raw_extra.get("raw_output")
    if raw_output is None:
        return
    if not isinstance(raw_output, str):
        raise TypeError("mini-swe-agent message raw_output must be a string")

    original_size_bytes = _utf8_size_bytes(raw_output)
    if original_size_bytes <= MAX_TOOL_OUTPUT_BYTES:
        return

    prefix = (
        "[tool output truncated by latch-eval-tools; "
        f"original_size_bytes={original_size_bytes}; "
        f"retained_limit_bytes={MAX_TOOL_OUTPUT_BYTES}]\n"
    )
    separator = "\n...[middle of tool output elided]...\n"
    payload_budget_bytes = MAX_TOOL_OUTPUT_BYTES - len(prefix) - len(separator)
    head_budget_bytes = payload_budget_bytes // 2
    tail_budget_bytes = payload_budget_bytes - head_budget_bytes
    head = _utf8_prefix_within_budget(raw_output, head_budget_bytes)
    tail = _utf8_suffix_within_budget(raw_output, tail_budget_bytes)
    retained_output = prefix + head + separator + tail

    raw_extra["raw_output"] = retained_output
    raw_extra["tool_output_truncated"] = True
    raw_extra["tool_output_original_size_bytes"] = original_size_bytes
    raw_extra["tool_output_retained_size_bytes"] = _utf8_size_bytes(retained_output)


class AgentTimeoutError(KeyboardInterrupt):
    # Use a KeyboardInterrupt-style base so model/provider retry layers that catch
    # Exception do not swallow the eval-level timeout and keep running past deadline.
    pass


def _timeout_handler(signum, frame):
    raise AgentTimeoutError("Agent exceeded time limit")


class StreamingLogFile:
    def __init__(self, file_path):
        self.file_path = file_path
        self.buffer = io.StringIO()

    def write(self, data):
        self.buffer.write(data)
        with open(self.file_path, "a") as f:
            f.write(data)
            f.flush()

    def flush(self):
        pass

    def getvalue(self):
        return self.buffer.getvalue()


def _persist_agent_trajectory(agent, trajectory_file: Path):
    trajectory_data = agent.serialize()
    temp_file = trajectory_file.with_suffix(".tmp")
    temp_file.write_text(json.dumps(trajectory_data, indent=2))
    temp_file.replace(trajectory_file)


def _render_logged_message_content(message: dict) -> str:
    content = message.get("content")
    if isinstance(content, str):
        rendered_content = content
    elif content is None:
        rendered_content = ""
    else:
        rendered_content = json.dumps(content, indent=2)

    tool_calls = message.get("tool_calls") or []
    if not tool_calls:
        return rendered_content

    rendered_tool_calls = []
    for tool_call in tool_calls:
        function = tool_call.get("function") or {}
        rendered_tool_calls.append(
            f"{function.get('name', 'unknown')}({function.get('arguments', '')})"
        )

    tool_call_summary = "Tool calls:\n" + "\n".join(rendered_tool_calls)
    if rendered_content:
        return f"{rendered_content}\n{tool_call_summary}"
    return tool_call_summary


def _patch_agent_for_progress(log_file, trajectory_file: Path, agent_class):
    if getattr(agent_class, "_latch_progress_patch_applied", False):
        return

    original_add_messages = agent_class.add_messages

    def patched_add_messages(
        self: Any,
        *messages: dict[str, Any],
    ) -> list[dict[str, Any]]:
        for message in messages:
            _truncate_message_raw_output(message)
        added_messages = original_add_messages(self, *messages)

        with open(log_file, "a") as f:
            for message in added_messages:
                role = message.get("role")
                content = _render_logged_message_content(message)
                if role == "assistant":
                    step_num = len(
                        [m for m in self.messages if m.get("role") == "assistant"]
                    )
                    f.write(f"\n[Step {step_num}]\n")
                    f.write(f"Assistant: {content}\n")
                elif role in {"tool", "user"} and len(self.messages) > 2:
                    f.write(f"Observation: {content}\n")
                elif role == "exit":
                    f.write(f"\n[Exit]\n{content}\n")
            f.flush()

        _persist_agent_trajectory(self, trajectory_file)
        return added_messages

    agent_class.add_messages = patched_add_messages
    agent_class._latch_progress_patch_applied = True


def get_model_kwargs(model_name: str) -> dict[str, Any]:
    if model_name in {
        "openai/gpt-5.5",
        "openai/gpt-5.4",
        "openai/gpt-5.3-codex",
        "openai/gpt-5.3",
        "openai/gpt-5.2",
    }:
        return {
            "model_kwargs": {"reasoning": {"effort": "xhigh"}},
            "model_class": "litellm_response",
        }
    elif model_name in {"openai/gpt-5.1"}:
        return {
            "model_kwargs": {"reasoning": {"effort": "high"}},
            "model_class": "litellm_response",
        }
    elif model_name in {
        "anthropic/claude-opus-4-6",
        "anthropic/claude-opus-4-7",
        "anthropic/claude-sonnet-4-6",
        "anthropic/claude-halva-eap",
        # Fable 5.1 (EAP "melon"): thinking is always-on, so it must use adaptive
        # thinking (never "enabled"+budget_tokens, which 400s on this model).
        "anthropic/claude-melon-lp-eap",
    }:
        return {
            "model_kwargs": {
                "thinking": {"type": "adaptive"},
                "output_config": {"effort": "max"},
            }
        }
    elif model_name in {"anthropic/claude-opus-4-5"}:
        return {
            "model_kwargs": {
                "thinking": {"type": "enabled", "budget_tokens": 32000},
                "output_config": {"effort": "high"},
            }
        }
    elif model_name.startswith("anthropic/"):
        return {
            "model_kwargs": {"thinking": {"type": "enabled", "budget_tokens": 32000}}
        }
    elif model_name.startswith("gemini/"):
        return {
            "model_kwargs": {
                "generationConfig": {"thinkingConfig": {"thinkingLevel": "HIGH"}}
            }
        }
    elif model_name == "xai/grok-4.3":
        return {"model_kwargs": {"reasoning_effort": "high"}}
    elif model_name.startswith("xai/") and model_name.endswith("-reasoning"):
        return {"model_class": "litellm_response"}
    elif model_name == "openai/moonshotai/Kimi-K2.6":
        return {
            "cost_tracking": "ignore_errors",
            "model_kwargs": {
                "api_base": "https://inference.baseten.co/v1",
                "api_key": os.environ["BASETEN_API_KEY"],
                "extra_body": {"thinking": {"type": "enabled", "keep": "all"}},
            },
        }
    else:
        return {}


def _apply_benchmark_convention(value: Any) -> Any:
    """Recursively rewrite legacy answer-protocol names in config strings."""
    if isinstance(value, str):
        return benchmark_convention(value)
    if isinstance(value, dict):
        return {k: _apply_benchmark_convention(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_apply_benchmark_convention(v) for v in value]
    return value


def run_minisweagent_task(
    task_prompt: str,
    work_dir: Path,
    model_name: str,
    agent_config: dict[str, Any] | None = None,
    model_config: dict[str, Any] | None = None,
    env_config: dict[str, Any] | None = None,
    operation_timeout: int = OPERATION_TIMEOUT,
    eval_timeout: int = EVAL_TIMEOUT,
    docker_image: str = DEFAULT_DOCKER_IMAGE,
    memory_limit_bytes: int | None = None,
    system_prompt: str | None = None,
    prompt_suffix: str | None = load_data_instructions(),
    completion: bool = False,
    benchmark: bool = False,
    completion_file_path: str | None = None,
    llm_connection: GatewayConnection | None = None,
    writable_data: bool = False,
) -> dict:
    """Run MiniSWE agent on a task.

    Args:
        task_prompt: Task description for the agent
        work_dir: Working directory for the agent
        model_name: Optional model name (e.g., "anthropic/claude-sonnet-4")
        agent_config: Optional agent configuration dict
        operation_timeout: Timeout for individual operations (seconds)
        eval_timeout: Timeout for entire evaluation (seconds)
        completion: When True, completion is signaled by the agent writing the
            file ``finished.txt`` in its workspace
        completion_file_path: Optional relative workspace output path required
            alongside the submit marker. Output validation remains with the caller.
        writable_data: ``data/`` holds the caller's private copies, so it is
            mounted writable (``get_agent_workspace_mount_args``).

    Returns:
        dict with keys "answer" (parsed JSON or None) and "metadata"
    """
    assert model_name is not None, f"Expect a model name got {model_name}"
    from minisweagent.environments.docker import DockerEnvironment
    from minisweagent.exceptions import LimitsExceeded, Submitted
    from minisweagent.models import get_model

    # Mini-SWE reads inference environment files and prints during import. Keep
    # its model adapters inside this inference entry point, as for gateway models.
    from latch_eval_tools.harness.refusal_miniswe import (
        RefusalAwareAgent,
        refusal_aware_model_config,
    )

    agent_dir = get_agent_workspace_dir(work_dir)
    completion_file = (
        agent_dir / completion_file_path if completion_file_path is not None else None
    )

    class FlexibleAgent(RefusalAwareAgent):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._override_start_time = time.monotonic()

        def step(self) -> list[dict]:
            if time.monotonic() - self._override_start_time > eval_timeout:
                raise LimitsExceeded(
                    {
                        "role": "exit",
                        "content": "LimitsExceeded",
                        "extra": {"exit_status": "LimitsExceeded", "submission": ""},
                    }
                )
            return super().step()

    class FlexibleDockerEnvironment(DockerEnvironment):
        completion_markers = COMPLETION_MARKERS

        def execute(
            self, action: dict, cwd: str = "", *, timeout: int | None = None
        ) -> dict[str, Any]:
            nonlocal oom_detected, oom_restarts, container_restarts
            output = super().execute(action, cwd=cwd, timeout=timeout)

            if output.get("returncode") == 0 and not output.get("exception_info"):
                return output

            container_running = bool(self.container_id) and is_docker_container_running(
                self.container_id,
                docker_executable=self.config.executable,
            )
            container_oom_killed = bool(
                self.container_id
            ) and is_docker_container_oom_killed(
                self.container_id,
                docker_executable=self.config.executable,
            )
            command_hit_oom = (
                output.get("returncode") == OOM_EXIT_CODE or container_oom_killed
            )
            if command_hit_oom:
                oom_detected = True
                if oom_restarts >= MAX_OOM_RESTARTS:
                    raise LimitsExceeded(
                        {
                            "role": "exit",
                            "content": "Container OOM recovery exhausted",
                            "extra": {
                                "exit_status": "EnvironmentFailed",
                                "submission": "",
                            },
                        }
                    )
                oom_restarts += 1

            if not container_running:
                self.cleanup()
                self.container_id = None
                self._start_container()
                container_restarts += 1
                failure_reason = (
                    "after likely exceeding the execution container memory limit."
                    if command_hit_oom
                    else "because the execution container stopped unexpectedly."
                )
                container_action = "A fresh execution container has been started."
            elif command_hit_oom:
                failure_reason = (
                    "after likely exceeding the execution container memory limit."
                )
                container_action = (
                    "The existing execution container is still running, so only "
                    "that command needs to be retried."
                )
            else:
                return output

            recovery_message = render_packaged_prompt(
                "miniswe_memory_warning.md",
                failure_reason=failure_reason,
                container_action=container_action,
                workspace_dir=self.config.cwd,
            )
            existing_output = output.get("output", "")
            if existing_output and not existing_output.endswith("\n"):
                existing_output += "\n"
            output["output"] = f"{existing_output}{recovery_message}"
            output.setdefault("extra", {})
            output["extra"]["container_restarted"] = not container_running
            output["extra"]["oom_detected"] = command_hit_oom
            output["extra"]["oom_restarts"] = oom_restarts
            return output

        def _check_finished(self, output: dict):
            """Raises Submitted when the agent has signaled completion.

            Legacy ``completion=True`` uses ``finished.txt`` directly. A declared
            report also requires the submit marker, so drafts do not end the run.
            """
            finished_file = find_finished_file(agent_dir) if completion else None
            if completion and (
                completion_file is None or completion_file == finished_file
            ):
                if finished_file is None:
                    return
                submission = ""
                if completion_file is None:
                    try:
                        submission = finished_file.read_text(encoding="utf-8")
                    except (OSError, UnicodeDecodeError):
                        pass
                raise Submitted(
                    {
                        "role": "exit",
                        "content": submission,
                        "extra": {"exit_status": "Submitted", "submission": submission},
                    }
                )

            lines = output.get("output", "").lstrip().splitlines(keepends=True)
            if (
                lines
                and lines[0].strip() in self.completion_markers
                and output["returncode"] == 0
            ):
                submission = "".join(lines[1:])
                if completion_file is not None:
                    answer_present = completion_file.is_file()
                else:
                    answer_present = find_answer_file(agent_dir) is not None
                if not answer_present:
                    return
                raise Submitted(
                    {
                        "role": "exit",
                        "content": submission,
                        "extra": {"exit_status": "Submitted", "submission": submission},
                    }
                )

    original_dir = os.getcwd()

    agent_log_file = work_dir / "agent_output.log"
    trajectory_file = work_dir / "trajectory.json"
    trajectory_file.write_text(json.dumps({"messages": []}, indent=2))
    _patch_agent_for_progress(agent_log_file, trajectory_file, FlexibleAgent)
    if agent_log_file.exists():
        agent_log_file.unlink()

    captured_output = StreamingLogFile(agent_log_file)
    original_stdout = sys.stdout
    original_stderr = sys.stderr

    class TeeOutput:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for stream in self.streams:
                stream.write(data)
                if hasattr(stream, "flush"):
                    stream.flush()

        def flush(self):
            for stream in self.streams:
                if hasattr(stream, "flush"):
                    stream.flush()

    agent = None
    agent_duration_seconds = 0.0
    timed_out = False
    agent_error: Exception | None = None
    oom_detected = False
    oom_restarts = 0
    container_restarts = 0
    try:
        os.chdir(str(agent_dir))

        effective_prompt_suffix = prompt_suffix
        if benchmark and effective_prompt_suffix:
            effective_prompt_suffix = benchmark_convention(effective_prompt_suffix)
        enhanced_prompt = prompt_with_suffix(task_prompt, effective_prompt_suffix)
        config = yaml.safe_load(read_packaged_prompt("miniswe_config.yaml"))
        if benchmark:
            config = _apply_benchmark_convention(config)
        effective_agent_config: dict[str, Any] = config["agent"] | (
            agent_config if isinstance(agent_config, dict) else {}
        )
        if system_prompt not in (None, ""):
            effective_agent_config["system_template"] = "{{ latch_system_prompt }}"
        effective_env_config: dict[str, Any] = config["environment"] | (
            env_config if isinstance(env_config, dict) else {}
        )
        effective_model_config: dict[str, Any] = (
            config["model"]
            | get_model_kwargs(model_name)
            | (model_config if isinstance(model_config, dict) else {})
        )
        if not docker_image:
            raise ValueError("docker_image is required for mini-swe Docker execution")
        if memory_limit_bytes is None:
            memory_limit_bytes = get_memory_limit_bytes()
        docker_env_config = effective_env_config | {
            "image": docker_image,
            "cwd": "/workspace",
            "run_args": [
                "--rm",
                "--memory",
                str(memory_limit_bytes),
                "--memory-swap",
                str(memory_limit_bytes),
                *get_agent_workspace_mount_args(agent_dir, writable_data=writable_data),
            ],
            "timeout": operation_timeout,
            "container_timeout": str(eval_timeout),
        }

        if model_name is not None and model_name.startswith("mistral/"):
            os.environ.setdefault("MSWEA_COST_TRACKING", "ignore_errors")

        ensure_docker_image(docker_image)

        sys.stdout = TeeOutput(original_stdout, captured_output)
        sys.stderr = TeeOutput(original_stderr, captured_output)
        if llm_connection is None:
            model = get_model(
                model_name, config=refusal_aware_model_config(effective_model_config)
            )
        else:
            # MiniSWE initializes config and prints on import. Defer its gateway
            # subclasses until inference so importing a grader cannot corrupt
            # machine-readable verifier output or read inference environment files.
            from latch_eval_tools.harness.gateway_miniswe import gateway_miniswe_model

            model = gateway_miniswe_model(
                model_name, effective_model_config, llm_connection
            )
        try:
            env = FlexibleDockerEnvironment(**docker_env_config)
        except subprocess.CalledProcessError as e:
            stdout = (e.stdout or "").strip()
            stderr = (e.stderr or "").strip()
            raise RuntimeError(
                "Failed to start mini-swe Docker environment.\n"
                f"Command: {shlex.join(e.cmd)}\n"
                f"stdout:\n{stdout or '<empty>'}\n"
                f"stderr:\n{stderr or '<empty>'}"
            ) from e
        agent = FlexibleAgent(model, env, **effective_agent_config)

        old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
        signal.alarm(eval_timeout)

        agent_started_at = time.monotonic()
        try:
            agent_result = agent.run(
                enhanced_prompt,
                latch_system_prompt=system_prompt or "",
            )
            if (
                completion_file is not None
                and agent_result["exit_status"] != "Submitted"
            ):
                raise RuntimeError(f"Agent exited with {agent_result['exit_status']}")
        except AgentTimeoutError:
            timed_out = True
            print(f"\nAgent timed out after {eval_timeout} seconds")
        except Submitted:
            pass
        except Exception as e:
            agent_error = e
            import traceback

            traceback.print_exc()
        finally:
            agent_duration_seconds = time.monotonic() - agent_started_at
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

            sys.stdout = original_stdout
            sys.stderr = original_stderr

            print(
                f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} Agent output saved to: {agent_log_file}"
            )

            if hasattr(agent, "messages"):
                _persist_agent_trajectory(agent, trajectory_file)
                print(f"Agent trajectory saved to: {trajectory_file}")
                print(f"  Total message exchanges: {len(agent.messages)}")

        agent_answer = None
        error_details = None
        if completion_file is None:
            last_message = ""
            if agent is not None:
                for message in reversed(agent.messages):
                    content = message.get("content")
                    if message.get("role") == "assistant" and isinstance(content, str):
                        last_message = content
                        break
            agent_answer, error_details = read_legacy_answer(
                agent_dir, completion=completion, last_message=last_message
            )

        metadata = {}
        if agent is not None:
            metadata["total_cost"] = agent.cost
            metadata["n_steps"] = agent.n_calls
            metadata["n_messages"] = len(agent.messages)
        metadata["memory_limit_bytes"] = memory_limit_bytes
        metadata["oom_restarts"] = oom_restarts
        metadata["container_restarts"] = container_restarts
        if timed_out:
            metadata["timed_out"] = True
            metadata["eval_timeout_seconds"] = eval_timeout
        if oom_detected:
            metadata["oom_detected"] = True
        if error_details:
            metadata["error_details"] = error_details

        structured_agent_error = (
            f"{type(agent_error).__name__}: {agent_error}"
            if agent_error is not None
            else None
        )
        serialized_trajectory = (
            agent.serialize() if agent is not None else {"messages": []}
        )
        trajectory_info = serialized_trajectory.get("info")
        exit_status = (
            trajectory_info.get("exit_status")
            if isinstance(trajectory_info, dict)
            else None
        )
        error_details = _failure_details(
            exit_status=exit_status if isinstance(exit_status, str) else None,
            timed_out=timed_out,
            agent_error=agent_error,
            output_error=error_details,
        )
        if error_details is not None:
            metadata["error_details"] = error_details
        if timed_out:
            structured_agent_error = "Agent budget exhausted"
        run_summary = build_miniswe_run_summary(
            serialized_trajectory=serialized_trajectory,
            duration_seconds=agent_duration_seconds,
            total_cost_usd=agent.cost if agent is not None else None,
            step_count=agent.n_calls if agent is not None else None,
            agent_error=structured_agent_error,
        )
        metadata["run_summary"] = run_summary.model_dump(mode="json")
        if run_summary.termination in {"refused", "failed"}:
            agent_answer = None
            metadata["error_details"] = error_details or {
                "error": "LLM refusal"
                if run_summary.termination == "refused"
                else "Agent failed"
            }

        metadata["harness_config"] = {
            "agent_config": effective_agent_config,
            "model_config": effective_model_config,
            "env_config": docker_env_config,
        }

        return {"answer": agent_answer, "metadata": metadata}

    finally:
        os.chdir(original_dir)
