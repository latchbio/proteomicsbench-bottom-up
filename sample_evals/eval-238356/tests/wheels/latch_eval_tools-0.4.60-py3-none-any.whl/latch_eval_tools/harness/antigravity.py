from pathlib import Path

from latch_eval_tools.harness._cli_runner import EVAL_TIMEOUT, _run_cli_agent
from latch_eval_tools.harness.llm_connection import GatewayConnection
from latch_eval_tools.harness.utils import DEFAULT_DOCKER_IMAGE


def run_antigravity_task(
    task_prompt: str,
    work_dir: Path,
    model_name: str,
    llm_connection: GatewayConnection,
    eval_timeout: int = EVAL_TIMEOUT,
    docker_image: str = DEFAULT_DOCKER_IMAGE,
    memory_limit_bytes: int | None = None,
    completion: bool = False,
    benchmark: bool = False,
    completion_file_path: str | None = None,
    writable_data: bool = False,
) -> dict:
    if not model_name.startswith("gemini/"):
        raise ValueError("Antigravity requires a gemini/ model")
    if not llm_connection.is_relay:
        raise ValueError("Antigravity requires a per-run relay connection")
    return _run_cli_agent(
        agent_type="antigravity",
        cli_command=["agy"],
        task_prompt=task_prompt,
        work_dir=work_dir,
        model_name=model_name,
        model_map={model_name: model_name.removeprefix("gemini/")},
        llm_connection=llm_connection,
        eval_timeout=eval_timeout,
        docker_image=docker_image,
        memory_limit_bytes=memory_limit_bytes,
        completion=completion,
        benchmark=benchmark,
        completion_file_path=completion_file_path,
        writable_data=writable_data,
    )
