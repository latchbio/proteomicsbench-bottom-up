"""Mini-SWE gateway adapters that keep native model accounting and cache markers.

Connection secrets live on the adapter, outside Mini-SWE's serializable config.
Only the inference call changes; parsing, cost limits and retries stay upstream.
"""

from copy import deepcopy
from typing import Any

import litellm
from litellm.types.llms.openai import ResponsesAPIResponse
from litellm.types.utils import ModelResponse
from minisweagent.models.utils.actions_toolcall import BASH_TOOL
from minisweagent.models.utils.actions_toolcall_response import BASH_TOOL_RESPONSE_API

from latch_eval_tools.harness.llm_connection import (
    GatewayConnection,
    request_reasoning_headers,
    split_model,
    wire_model,
)
from latch_eval_tools.harness.refusal_miniswe import (
    RefusalAwareChatModel,
    RefusalAwareResponseModel,
)


def request_options(
    model: str, options: dict[str, Any], connection: GatewayConnection
) -> tuple[str, dict[str, Any]]:
    provider, _ = split_model(model)
    options = deepcopy(options)
    if provider == "gemini":
        generation = options.pop("generationConfig", {})
        thinking = generation.get("thinkingConfig", {}).get("thinkingLevel")
        if thinking is not None:
            options["reasoning_effort"] = str(thinking).lower()
    # Native Anthropic preserves thinking/cache blocks. Other protocols use the
    # OpenAI-compatible ingress; Bifrost resolves the Gemini Flash routing policy.
    target = (
        model if provider == "anthropic" else "openai/" + connection.wire_model(model)
    )
    if provider != "anthropic" and "reasoning_effort" in options:
        # LiteLLM cannot infer another provider's reasoning support from a gateway
        # alias. Explicitly forward this parameter instead of silently dropping it.
        options["allowed_openai_params"] = list(
            dict.fromkeys(
                [*options.get("allowed_openai_params", []), "reasoning_effort"]
            )
        )
    options.update(
        api_base=connection.endpoint(
            "anthropic-messages" if provider == "anthropic" else "openai-completions"
        ),
        api_key=connection.api_key,
        extra_headers={
            **options.get("extra_headers", {}),
            **connection.headers,
            **request_reasoning_headers(options),
        },
    )
    if wire_model(model) == "deepseek-v4p1-flash":
        options["extra_headers"].update(
            {
                "x-bf-session-affinity": "off",
                "x-bf-eh-Modal-Session-Id": connection.session_id,
            }
        )
    return target, options


def accounting_response(
    response: ModelResponse | ResponsesAPIResponse, model: str
) -> ModelResponse | ResponsesAPIResponse:
    """Keep transport metadata from overriding the logical model's cost registry."""
    provider, name = split_model(model)
    priced = response.model_copy(deep=True)
    priced.model = f"{provider}/{name}"
    priced._hidden_params = {
        **priced._hidden_params,
        "custom_llm_provider": provider,
        "model": priced.model,
    }
    return priced


class GatewayChatModel(RefusalAwareChatModel):
    def __init__(self, *, connection: GatewayConnection, **kwargs: Any):
        super().__init__(**kwargs)
        self.connection = connection

    def _calculate_cost(self, response: ModelResponse) -> dict[str, float]:
        return super()._calculate_cost(
            accounting_response(response, self.config.model_name)
        )

    def _query(self, messages: list[dict[str, str]], **kwargs: Any):
        model, options = request_options(
            self.config.model_name, self.config.model_kwargs | kwargs, self.connection
        )
        return litellm.completion(
            model=model, messages=messages, tools=[BASH_TOOL], **options
        )


class GatewayResponseModel(RefusalAwareResponseModel):
    def __init__(self, *, connection: GatewayConnection, **kwargs: Any):
        super().__init__(**kwargs)
        self.connection = connection

    def _calculate_cost(self, response: ResponsesAPIResponse) -> dict[str, float]:
        return super()._calculate_cost(
            accounting_response(response, self.config.model_name)
        )

    def _query(self, messages: list[dict[str, str]], **kwargs: Any):
        model, options = request_options(
            self.config.model_name, self.config.model_kwargs | kwargs, self.connection
        )
        return litellm.responses(
            model=model, input=messages, tools=[BASH_TOOL_RESPONSE_API], **options
        )


def gateway_miniswe_model(
    model_name: str, config: dict[str, Any], connection: GatewayConnection
) -> GatewayChatModel | GatewayResponseModel:
    config = deepcopy(config)
    model_class = config.pop("model_class", "")
    if model_class not in {"", "litellm", "litellm_response"}:
        raise ValueError(f"Unsupported Mini-SWE gateway model class: {model_class!r}")
    if model_name.startswith("anthropic/"):
        config.setdefault("set_cache_control", "default_end")
    # Credentials must never enter the template/trajectory config.
    config.setdefault("model_kwargs", {}).pop("api_key", None)
    cls = (
        GatewayResponseModel if model_class == "litellm_response" else GatewayChatModel
    )
    return cls(model_name=model_name, connection=connection, **config)
