"""CLI version validation and Pi per-run resolution shared by both launchers."""

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.request import urlopen

from latch_eval_tools.harness.antigravity_versions import normalize_antigravity_version

PI_VERSION_RANGE = ">=1.3.0 <1.5.0"
PI_VERSION_PATTERN = r"1\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)"
PI_VERSION_RECORD = "harness_version.json"
PI_REGISTRY_URL = "https://registry.npmjs.org/@earendil-works%2fpi-coding-agent"
NPM_MIN_PUBLISH_AGE = timedelta(hours=1)


def normalize_harness_version(harness: str, version: str) -> str:
    """Validate inputs without registry I/O; latest is resolved at execution time."""
    version = version.strip()
    if harness == "antigravity":
        return normalize_antigravity_version(version)
    if harness == "pi" and version and version != "latest":
        match = re.fullmatch(PI_VERSION_PATTERN, version)
        if match is None or not 3 <= int(match[1]) < 5:
            raise ValueError(
                f"This runner requires a stable Pi version {PI_VERSION_RANGE}; got {version!r}. "
                "Use the earlier V2 release for legacy Pi."
            )
    return version


def newest_pi_version(metadata: object, published_before: datetime) -> str:
    """Select by numeric SemVer, independently of npm's latest dist-tag, among
    releases old enough to pass the install's `npm --before` cutoff."""
    if not isinstance(metadata, dict) or not isinstance(metadata.get("versions"), dict):
        raise ValueError("Pi registry response must contain a versions object")
    published = metadata.get("time")
    if not isinstance(published, dict):
        published = {}
    candidates: list[tuple[int, int, str]] = []
    for version in metadata["versions"]:
        if not isinstance(version, str):
            raise ValueError("Pi registry version keys must be strings")
        match = re.fullmatch(PI_VERSION_PATTERN, version)
        published_at = published.get(version)
        if (
            match is not None
            and 3 <= int(match[1]) < 5
            and isinstance(published_at, str)
            and datetime.fromisoformat(published_at.replace("Z", "+00:00"))
            <= published_before
        ):
            candidates.append((int(match[1]), int(match[2]), version))
    if not candidates:
        raise ValueError(f"No stable Pi version satisfies {PI_VERSION_RANGE}")
    return max(candidates)[2]


def resolve_pi_version(version: str, record_path: Path) -> str:
    """Resolve once before installation; reuse the run's record on setup retries."""
    requested = normalize_harness_version("pi", version)
    if not requested:
        raise ValueError("Pi version is required")
    if record_path.exists():
        record = json.loads(record_path.read_text())
        if not isinstance(record, dict) or record.get("requested_version") != requested:
            raise ValueError("Pi version record does not match this run's request")
        resolved = record.get("resolved_version")
        if not isinstance(resolved, str) or resolved in ("", "latest"):
            raise ValueError("Pi version record must contain a concrete version")
        normalize_harness_version("pi", resolved)
        if requested != "latest" and resolved != requested:
            raise ValueError(
                "Pi version record differs from the requested exact version"
            )
        return resolved

    resolved = requested
    if requested == "latest":
        with urlopen(PI_REGISTRY_URL, timeout=30) as response:
            resolved = newest_pi_version(
                json.load(response),
                datetime.now(timezone.utc) - NPM_MIN_PUBLISH_AGE,
            )
    record = {"requested_version": requested, "resolved_version": resolved}
    temporary = record_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(record, indent=2) + "\n")
    temporary.replace(record_path)
    return resolved
