"""Native terminal signals, independent of answer files and refusal history."""

from typing import Any, Literal

from latch_eval_tools.harness.antigravity_support import antigravity_result
from latch_eval_tools.llm_refusal import detect_llm_refusal

HarnessTermination = Literal["completed", "failed", "refused", "unknown"]
HarnessErrorCode = Literal[
    "agent_budget_exhausted",
    "output_contract_failed",
    "harness_execution_failed",
    "agent_turn_failed",
]


def cli_budget_exhausted(agent_type: str, events: list[dict[str, Any]]) -> bool:
    if agent_type != "claudecode":
        return False
    for event in reversed(events):
        if event.get("type") == "result":
            return event.get("subtype") in {"error_max_turns", "error_max_budget_usd"}
    return False


def pi_terminal_assistant_message(
    events: list[dict[str, Any]],
) -> dict[str, Any] | None:
    for event in reversed(events):
        if event.get("type") in {"agent_start", "turn_start"}:
            return None  # A new attempt/turn has not produced a terminal response.
        if event.get("type") == "agent_end":
            messages = event.get("messages")
            if isinstance(messages, list):
                for message in reversed(messages):
                    if isinstance(message, dict) and message.get("role") == "assistant":
                        return message
        elif event.get("type") in {"message", "message_end", "turn_end"}:
            message = event.get("message")
            if isinstance(message, dict) and message.get("role") == "assistant":
                return message
    return None


def cli_termination(
    agent_type: str,
    events: list[dict[str, Any]],
) -> HarnessTermination:
    """Reduce ordered native events; a later completed attempt can recover.

    Unknown or incomplete streams stay unknown. Native terminal events close a
    run; response-channel refusal evidence can qualify that terminal result.
    Tool output, sidecar history and answer files cannot close a run.
    """
    if agent_type == "antigravity":
        result = antigravity_result(events)
        if result is None:
            return "unknown"
        status = result.get("status")
        if status != "SUCCESS":
            return (
                "failed"
                if status in {"ERROR", "CANCELED", "INTERRUPTED", "INVALID", "WAITING"}
                else "unknown"
            )
        response = result.get("response")
        return (
            "refused"
            if isinstance(response, str)
            and detect_llm_refusal(
                trajectory_data=[{"role": "assistant", "content": response}]
            )
            is not None
            else "completed"
        )
    if agent_type == "pi":
        message = pi_terminal_assistant_message(events)
        if message is None:
            return "unknown"
        if detect_llm_refusal(trajectory_data=[message]) is not None:
            return "refused"
        stop = message.get("stopReason")
        return (
            "completed"
            if stop == "stop"
            else "failed"
            if stop in {"error", "aborted"}
            else "unknown"
        )

    termination: HarnessTermination = "unknown"
    pending_refusal = False
    for event in events:
        kind = event.get("type")
        terminal: dict[str, Any] | None = None
        failed = False
        if agent_type == "openaicodex":
            if kind == "turn.started":
                termination = "unknown"
                pending_refusal = False
            elif kind == "item.completed":
                pending_refusal = (
                    pending_refusal
                    or detect_llm_refusal(trajectory_data=[event]) is not None
                )
            elif kind == "error":
                termination = (
                    "refused"
                    if detect_llm_refusal(trajectory_data=[event]) is not None
                    else "failed"
                )
            elif kind in {"turn.completed", "turn.failed"}:
                terminal = event
                failed = kind == "turn.failed"
        elif agent_type == "claudecode" and kind == "result":
            terminal = event
            failed = (
                event.get("terminal_reason") == "api_error"
                or event.get("is_error") is True
                or event.get("subtype") not in {None, "success"}
            )
        elif agent_type == "grokbuild":
            if kind == "error":
                terminal = event
                failed = True
            elif kind == "text":
                pending_refusal = (
                    pending_refusal
                    or detect_llm_refusal(trajectory_data=[event]) is not None
                )
            elif kind == "end":
                terminal = event
                failed = (
                    termination in {"failed", "refused"}
                    or event.get("error") is not None
                )
                pending_refusal = pending_refusal or termination == "refused"

        if terminal is not None:
            refusal = detect_llm_refusal(trajectory_data=[terminal])
            termination = (
                "refused"
                if refusal is not None or pending_refusal
                else "failed"
                if failed
                else "completed"
            )
            pending_refusal = False
    return termination
