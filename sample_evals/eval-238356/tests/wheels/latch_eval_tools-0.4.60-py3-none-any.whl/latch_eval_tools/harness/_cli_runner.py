import json
import math
import os
import random
import re
import shlex
import subprocess
import threading
import time
import uuid
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import datetime, timezone
from importlib.resources import files
from pathlib import Path
from typing import Any

from latch_eval_tools.harness.antigravity_support import (
    antigravity_result,
    collect_antigravity_trajectory,
)
from latch_eval_tools.harness.llm_connection import (
    PI_GATEWAY_CONFIG_SCRIPT,
    PI_RUNTIME_VALIDATION_SCRIPT,
    GatewayConnection,
    wire_model,
)
from latch_eval_tools.harness.output import read_legacy_answer
from latch_eval_tools.harness.run_summary import (
    CliHarnessAgentType,
    build_cli_run_summary,
)
from latch_eval_tools.harness.runtime_patches import GROK_CUSTOM_MODEL_CONFIG_TOMLS
from latch_eval_tools.harness.termination import (
    HarnessErrorCode,
    HarnessTermination,
    cli_budget_exhausted,
    cli_termination,
)
from latch_eval_tools.harness.termination import (
    pi_terminal_assistant_message as _pi_terminal_assistant_message,
)
from latch_eval_tools.harness.utils import (
    DEFAULT_DOCKER_IMAGE,
    benchmark_convention,
    ensure_docker_image,
    find_answer_file,
    find_finished_file,
    get_agent_workspace_dir,
    get_agent_workspace_mount_args,
    get_memory_limit_bytes,
    is_docker_container_oom_killed,
    is_docker_container_running,
    load_trajectory_identifier,
    prompt_with_suffix,
    render_packaged_prompt,
)
from latch_eval_tools.llm_refusal import detect_llm_refusal

REFUSAL_VERDICT_FILENAME = "refusal_verdict.json"
FALLBACK_API_KEYS_ENV = "ANTHROPIC_API_KEY_FALLBACKS"
ANTIGRAVITY_GEMINI_EFFORTS = ("low", "medium", "high", "xhigh")


def read_fallback_api_keys(env: dict[str, str]) -> list[str]:
    """Pop the ordered Anthropic fallback keys so the agent only ever sees ANTHROPIC_API_KEY."""
    raw = env.pop(FALLBACK_API_KEYS_ENV, None)
    if not raw:
        return []
    keys = json.loads(raw)
    if not isinstance(keys, list) or not all(
        isinstance(key, str) and key for key in keys
    ):
        raise ValueError(
            f"{FALLBACK_API_KEYS_ENV} must be a JSON array of non-empty strings"
        )
    return keys


def configure_grok(
    container_name: str,
    model_name: str | None,
    llm_connection: GatewayConnection | None,
) -> None:
    if llm_connection is not None:
        if model_name is None:
            raise ValueError("A gateway Grok connection requires a model")
        config = llm_connection.grok_config(model_name)
    else:
        config = GROK_CUSTOM_MODEL_CONFIG_TOMLS.get(model_name or "")
    if config is None:
        return
    subprocess.run(
        [
            "docker",
            "exec",
            "-i",
            container_name,
            "sh",
            "-c",
            'mkdir -p "$HOME/.grok" && cat > "$HOME/.grok/config.toml"',
        ],
        input=config,
        check=True,
        capture_output=True,
        text=True,
        timeout=30,
    )


def _write_refusal_verdict(
    work_dir: Path,
    trajectory: list[dict[str, Any]],
    *,
    refusal_events: list[dict[str, Any]] | None = None,
    agent_error: str | None = None,
) -> None:
    # Detect refusals against the in-memory trajectory here (the harness has it
    # local) and persist the verdict, so consumers never re-read the trajectory.
    try:
        refusal = detect_llm_refusal(
            trajectory_data=trajectory,
            refusal_events_data=refusal_events,
            agent_error=agent_error,
        )
        payload = refusal.model_dump(mode="json") if refusal is not None else None
        (work_dir / REFUSAL_VERDICT_FILENAME).write_text(json.dumps(payload))
    except Exception as exc:
        print(f"failed to write refusal verdict: {exc}")


EVAL_TIMEOUT = 6000
TRAJECTORY_SNAPSHOT_INTERVAL_SECONDS = 1.0
ANTHROPIC_ENV_KEYS = {"ANTHROPIC_API_KEY"}
OPENAI_ENV_KEYS = {"OPENAI_API_KEY", "CODEX_API_KEY"}
PI_ENV_KEYS = {
    "ANTHROPIC_API_KEY",
    "FIREWORKS_API_KEY",
    "OPENAI_API_KEY",
    "GEMINI_API_KEY",
    "XAI_API_KEY",
    "OPENROUTER_API_KEY",
    "MISTRAL_API_KEY",
    "META_API_KEY",
}
GROK_ENV_KEYS = {"XAI_API_KEY"}

# pi ships no built-in OpenRouter provider, so we register a custom
# openai-completions provider in /root/.pi/agent/models.json. The pi state dir
# (work_dir/.pi) is bind-mounted to /root/.pi, so writing the file on the host
# lands it where pi looks. Notes on the fields:
#   - cost is per-MILLION tokens (OpenRouter list price: $3 / $15, $0.30 cache read).
#   - contextWindow/maxTokens must be explicit; pi defaults to 128k/16k and would
#     otherwise truncate K3's 1M window and long reasoning. (maxTokens passthrough
#     for openai-completions requires pi >= 0.80.3, issue #5595.)
#   - compat.thinkingFormat "openai" sends the top-level reasoning_effort
#     field documented by these providers; thinkingLevelMap preserves each
#     model's configured effort mappings.
#   - compat.supportsUsageInStreaming keeps stream_options.include_usage on so
#     usage (input/output/cache tokens) and cost are reported back.
OPENROUTER_PROVIDER_NAME = "openrouter"
OPENROUTER_PROVIDER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODEL_CONFIGS: dict[str, dict] = {
    "openrouter/deepseek/deepseek-v4.1-flash": {
        "id": "deepseek/deepseek-v4.1-flash",
        "name": "DeepSeek V4.1 Flash",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        "maxTokens": 393216,
        "cost": {"input": 0.15, "output": 0.60, "cacheRead": 0.003, "cacheWrite": 0},
        "thinkingLevelMap": {
            "low": "low",
            "medium": "high",
            "high": "high",
            "xhigh": "max",
            "max": "max",
        },
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    # DeepSeek-V4.1-Flash-1017: re-post-trained snapshot of V4.1 Flash (same
    # architecture). OpenRouter lists none / low / high / max efforts (default
    # high; max is the highest). Each supported level maps to itself, with off
    # sending "none" (omitting effort would reason at the default, high).
    # Levels DeepSeek does not have (minimal, medium, xhigh) are None, i.e.
    # unsupported, and Pi clamps them up to the next supported level.
    # Cost is DeepSeek's off-peak list price; weekday peak windows bill 2x and
    # many cheaper third-party endpoints exist.
    # https://openrouter.ai/api/v1/models/deepseek/deepseek-v4.1-flash-1017/endpoints
    "openrouter/deepseek/deepseek-v4.1-flash-1017": {
        "id": "deepseek/deepseek-v4.1-flash-1017",
        "name": "DeepSeek V4.1 Flash 1017",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        "maxTokens": 393216,
        "cost": {"input": 0.15, "output": 0.60, "cacheRead": 0.003, "cacheWrite": 0},
        "thinkingLevelMap": {
            "off": "none",
            "minimal": None,
            "low": "low",
            "medium": None,
            "high": "high",
            "xhigh": None,
            "max": "max",
        },
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    "openrouter/nvidia/nemotron-3.5-lightning": {
        "id": "nvidia/nemotron-3.5-lightning",
        "name": "Nemotron 3.5 Lightning",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 262144,
        "maxTokens": 32768,
        "cost": {"input": 0.065, "output": 0.18, "cacheRead": 0, "cacheWrite": 0},
        "thinkingLevelMap": {"xhigh": "high", "max": "high"},
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    "openrouter/moonshotai/kimi-k3": {
        "id": "moonshotai/kimi-k3",
        "name": "Kimi K3",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        "maxTokens": 131072,
        "cost": {"input": 3, "output": 15, "cacheRead": 0.3, "cacheWrite": 0},
        # Kimi K3 only accepts "max" effort, so that is the only level mapped.
        "thinkingLevelMap": {"max": "max"},
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    # Kimi K3.1 Pro (successor to K3; text+image+video in, 1M window). Pi
    # 1.4.0's OpenRouter catalog stops at K3, so it is registered here.
    # OpenRouter lists none / low / high / max (default max). Each maps only
    # to its own value, except off: Moonshot documents K3.1 Pro as always
    # thinking (low / high / max only) and has returned 400 for disabled
    # thinking, so off is unsupported. Pi clamps the rest upward, so off runs
    # at low and the harness default (xhigh) runs at max.
    # https://platform.kimi.ai/docs/guide/use-reasoning-effort
    # Providers serve up to ~920K output (DigitalOcean 132K); maxTokens is
    # capped at 128K, as for K3, so long prompts still fit. Not every endpoint
    # takes max_completion_tokens, so max_tokens is sent instead.
    # Cost is Moonshot's standard list price; cheaper quantized third-party
    # endpoints exist, and Moonshot's highspeed endpoint bills 2x.
    # https://openrouter.ai/api/v1/models/moonshotai/kimi-k3.1-pro/endpoints
    "openrouter/moonshotai/kimi-k3.1-pro": {
        "id": "moonshotai/kimi-k3.1-pro",
        "name": "Kimi K3.1 Pro",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        "maxTokens": 131072,
        "cost": {"input": 2, "output": 10, "cacheRead": 0.2, "cacheWrite": 0},
        "thinkingLevelMap": {
            "off": None,
            "minimal": None,
            "low": "low",
            "medium": None,
            "high": "high",
            "xhigh": None,
            "max": "max",
        },
        "compat": {
            "supportsDeveloperRole": False,
            "thinkingFormat": "openrouter",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
    # DeepSeek-V4-Flash-0731 supports low/high/max effort; only those levels are
    # mapped, each to itself.
    # Cost is OpenRouter list price ($0.14 / $0.28 per 1M, $0.028 cache read;
    # Cloudflare provider).
    "openrouter/deepseek/deepseek-v4-flash-0731": {
        "id": "deepseek/deepseek-v4-flash-0731",
        "name": "DeepSeek V4 Flash",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 1048576,
        "maxTokens": 393216,
        "cost": {"input": 0.14, "output": 0.28, "cacheRead": 0.028, "cacheWrite": 0},
        "thinkingLevelMap": {"low": "low", "high": "high", "max": "max"},
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    # Qwen3.8-27B: dense VL model that only accepts "xhigh" effort, so that is
    # the only level mapped.
    # https://openrouter.ai/qwen/qwen3.8-27b
    "openrouter/qwen/qwen3.8-27b": {
        "id": "qwen/qwen3.8-27b",
        "name": "Qwen3.8 27B",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 262144,
        "maxTokens": 131072,
        "cost": {"input": 0.45, "output": 3.2, "cacheRead": 0, "cacheWrite": 0},
        "thinkingLevelMap": {"xhigh": "xhigh"},
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    "openrouter/nvidia/nemotron-3-super-120b-a12b": {
        "id": "nvidia/nemotron-3-super-120b-a12b",
        "name": "Nemotron 3 Super",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 262144,
        "maxTokens": 32768,
        "cost": {"input": 0.08, "output": 0.45, "cacheRead": 0, "cacheWrite": 0},
        "compat": {
            "thinkingFormat": "openai",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    },
    # OpenRouter advertises reasoning_effort for Ultra.
    # https://openrouter.ai/api/v1/models/nvidia/nemotron-3-ultra-550b-a55b/endpoints
    # Conservative limits fit every currently advertised endpoint. Costs use
    # the lowest-priced endpoint; actual routing may cost more.
    "openrouter/nvidia/nemotron-3-ultra-550b-a55b": {
        "id": "nvidia/nemotron-3-ultra-550b-a55b",
        "name": "Nemotron 3 Ultra",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 202800,
        "maxTokens": 16384,
        "cost": {"input": 0.5, "output": 2.2, "cacheRead": 0.1, "cacheWrite": 0},
        "compat": {
            "supportsDeveloperRole": False,
            "thinkingFormat": "openrouter",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
    # Mistral Large 4 (1.05T total / 49B active MoE, text+image). At preview,
    # Mistral's reasoning_effort took only "none" or "high", so only pi's high
    # level is mapped. The Oct 29 open-weight release announced low / medium /
    # high (low replaces none), but the API docs still list none / high, so
    # low and medium stay unmapped until the API is verified to accept them.
    # https://mistral.ai/news/mistral-large-4-oss/
    # OpenRouter serves a 512K window with up to 262K output; maxTokens is
    # capped at 128K so the request still fits once the prompt grows large.
    # Mistral has no developer role.
    # https://docs.mistral.ai/studio/conversations/reasoning
    # Cost is list price ($1.36 / $4.18 per 1M, $0.14 cache read). OpenRouter
    # bills a 50% launch discount for now.
    # https://openrouter.ai/api/v1/models/mistralai/mistral-large-4-0/endpoints
    "openrouter/mistralai/mistral-large-4-0": {
        "id": "mistralai/mistral-large-4-0",
        "name": "Mistral Large 4",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 524288,
        "maxTokens": 131072,
        "cost": {"input": 1.36, "output": 4.18, "cacheRead": 0.14, "cacheWrite": 0},
        "thinkingLevelMap": {"high": "high"},
        "compat": {
            "supportsDeveloperRole": False,
            "thinkingFormat": "openrouter",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
    # Inception Mercury 3 (diffusion LLM, text only). Pi 1.3.0's catalog stops
    # at Mercury 2.5, so it is registered here. OpenRouter documents efforts
    # none / low / medium / high, and each level maps only to its own value:
    # off sends "none" (omitting effort would reason at the default medium),
    # and minimal / xhigh / max are unsupported. Pi clamps the harness default
    # (xhigh) to high, Mercury's highest effort.
    # Inception is the only provider; it serves a 1M window with up to 128K
    # output. Developer role is off, as in pi's built-in Mercury 2.5 entry.
    # https://openrouter.ai/api/v1/models/inception/mercury-3/endpoints
    "openrouter/inception/mercury-3": {
        "id": "inception/mercury-3",
        "name": "Mercury 3",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 1000000,
        "maxTokens": 131072,
        "cost": {"input": 0.10, "output": 0.35, "cacheRead": 0.01, "cacheWrite": 0},
        "thinkingLevelMap": {
            "off": "none",
            "minimal": None,
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": None,
            "max": None,
        },
        "compat": {
            "supportsDeveloperRole": False,
            "thinkingFormat": "openrouter",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
    # Z.ai GLM 5.3 (text only, 1M window). Pi's built-in OpenRouter entry
    # advertises the largest output cap any provider offers (943K), which
    # would route every request away from the providers capped at 128K,
    # Z.AI's own endpoint included. It is registered here with a 128K cap
    # that every provider accepts. Reasoning is mandatory and OpenRouter
    # documents only low / high / max (default max), so each maps only to its
    # own value, as in Pi's catalog; off / minimal / medium / xhigh are
    # unsupported. Pi clamps them upward, so off runs at low and the harness
    # default (xhigh) runs at max.
    # Cost is list price ($1.40 / $4.40 per 1M, $0.26 cache read; Z.AI and
    # most providers). Cheaper, mostly fp4, endpoints exist.
    # https://openrouter.ai/api/v1/models/z-ai/glm-5.3/endpoints
    "openrouter/z-ai/glm-5.3": {
        "id": "z-ai/glm-5.3",
        "name": "GLM 5.3",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 1048576,
        "maxTokens": 131072,
        "cost": {"input": 1.40, "output": 4.40, "cacheRead": 0.26, "cacheWrite": 0},
        "thinkingLevelMap": {
            "off": None,
            "minimal": None,
            "low": "low",
            "medium": None,
            "high": "high",
            "xhigh": None,
            "max": "max",
        },
        "compat": {
            "supportsDeveloperRole": False,
            "thinkingFormat": "openrouter",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
}

for version in ("3.7", "3.8"):
    remote_id = f"google/gemini-{version}-flash"
    OPENROUTER_MODEL_CONFIGS[f"openrouter/{remote_id}"] = {
        "id": remote_id,
        "name": f"Gemini {version} Flash",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        "maxTokens": 65536,
        # Introductory list prices through 2026-12-31, USD per million tokens.
        "cost": {
            "input": 0.75,
            "output": 3.75,
            "cacheRead": 0.075,
            "cacheWrite": 0,
        },
        "thinkingLevelMap": {
            "minimal": "minimal",
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "high",
            "max": "high",
        },
        "compat": {
            "thinkingFormat": "openrouter",
            "supportsReasoningEffort": True,
            "supportsUsageInStreaming": True,
        },
    }

GEMINI_MODEL_CONFIGS: dict[str, dict[str, Any]] = {
    "gemini-4-argon": {
        "id": "gemini-4-argon",
        "name": "Gemini 4 Argon",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        # The gateway uses streaming Chat Completions, without a long-decode loop.
        "maxTokens": 65536,
        # Introductory standard prices through 2026-11-30, USD per million tokens.
        # https://ai.google.dev/gemini-api/docs/generate-content/latest-model
        # Gateway provider/tier surcharges are not included in Pi's estimate.
        "cost": {"input": 2, "output": 10, "cacheRead": 0.1, "cacheWrite": 0},
        "thinkingLevelMap": {"low": "low", "medium": "medium", "high": "high"},
    },
    "gemini-4-carbon": {
        "id": "gemini-4-carbon",
        "name": "Gemini 4 Carbon",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        # The gateway uses streaming Chat Completions, without a long-decode loop.
        "maxTokens": 65536,
        # Introductory standard prices through 2026-11-30 ($4/$20 after), USD per
        # million tokens. https://ai.google.dev/gemini-api/docs/whats-new-gemini-4-carbon
        # Gateway provider/tier surcharges are not included in Pi's estimate.
        "cost": {"input": 2, "output": 10, "cacheRead": 0.1, "cacheWrite": 0},
        "thinkingLevelMap": {"low": "low", "medium": "medium", "high": "high"},
    },
    # Thinking levels are low / medium / high (default) / xhigh. Bifrost's
    # gemini-4-hydrogen table entry
    # (services/bifrost_reasoning/patches/gemini-4-hydrogen-xhigh.patch) forwards
    # xhigh rather than clamping it to high.
    "gemini-4-hydrogen": {
        "id": "gemini-4-hydrogen",
        "name": "Gemini 4 Hydrogen",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        # The gateway uses streaming Chat Completions, without a long-decode loop.
        "maxTokens": 65536,
        # Flat standard prices across the full context, USD per million tokens.
        # https://ai.google.dev/gemini-api/docs/whats-new-gemini-4-hydrogen
        # Gateway provider/tier surcharges are not included in Pi's estimate.
        "cost": {"input": 1.5, "output": 7.5, "cacheRead": 0.075, "cacheWrite": 0},
        "thinkingLevelMap": {
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "xhigh",
        },
    },
    # Paid tier only. Thinking levels are low / medium / high (default) / xhigh;
    # minimal is rejected with an error. Bifrost's gemini-4-neon table entry
    # (services/bifrost_reasoning/patches/gemini-4-hydrogen-xhigh.patch) forwards
    # xhigh rather than clamping it to high.
    "gemini-4-neon": {
        "id": "gemini-4-neon",
        "name": "Gemini 4 Neon",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        # The gateway uses streaming Chat Completions, without a long-decode loop.
        "maxTokens": 65536,
        # Flat standard prices across the full context, USD per million tokens;
        # implicit caching only. https://ai.google.dev/gemini-api/docs/whats-new-gemini-4-neon
        # Gateway provider/tier surcharges are not included in Pi's estimate.
        "cost": {"input": 3, "output": 15, "cacheRead": 0.15, "cacheWrite": 0},
        # Pi treats unmapped levels as supported; null them so Pi clamps minimal
        # up to low instead of sending a level the model rejects.
        "thinkingLevelMap": {
            "off": None,
            "minimal": None,
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "xhigh",
        },
    },
    # Early-access checkpoint on shared capacity; internal evaluation only.
    # Google publishes no EAP pricing, so cost mirrors Argon's introductory rate
    # as a placeholder. xhigh is live; Bifrost's gemini-4-hydrogen table entry
    # (services/bifrost_reasoning/patches/gemini-4-hydrogen-xhigh.patch) also
    # matches this id and forwards it rather than clamping it to high.
    "gemini-4-hydrogen-eap": {
        "id": "gemini-4-hydrogen-eap",
        "name": "Gemini 4 Hydrogen (EAP)",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        "maxTokens": 65536,
        "cost": {"input": 2, "output": 10, "cacheRead": 0.1, "cacheWrite": 0},
        "thinkingLevelMap": {
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "xhigh",
        },
    },
    # Early-access checkpoint; internal evaluation only. Gemini API v1beta only
    # (Bifrost's Gemini provider defaults to v1beta). Thinking levels are low /
    # medium / high (default) / xhigh; there is no minimal. Bifrost's
    # gemini-4-cobalt-eap table entry
    # (services/bifrost_reasoning/patches/gemini-4-hydrogen-xhigh.patch) forwards
    # xhigh rather than clamping it to high. No charge during early access, and
    # only implicit caching is available, so every rate is zero.
    "gemini-4-cobalt-eap": {
        "id": "gemini-4-cobalt-eap",
        "name": "Gemini 4 Cobalt (EAP)",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1048576,
        # The gateway uses streaming Chat Completions, without a long-decode loop.
        "maxTokens": 65536,
        "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0},
        # Pi treats unmapped levels as supported; null them so Pi clamps minimal
        # up to low instead of sending a level the model rejects.
        "thinkingLevelMap": {
            "off": None,
            "minimal": None,
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "xhigh",
        },
    },
}

# OpenAI models newer than Pi's built-in catalog. Pi 1.4.0 has no GPT-6.1 Terra
# and resolves it to generic GPT-5.5-style metadata: max maps to null (so the
# max default clamps to xhigh) and cost is $5/$30. Fields mirror Pi's own
# GPT-6.1 Sol entry, including the 272K context window it uses at the
# long-context price boundary.
# https://developers.openai.com/api/docs/models/gpt-6.1-terra
OPENAI_MODEL_CONFIGS: dict[str, dict[str, Any]] = {
    # reasoning.effort takes none / low / medium (default) / high / xhigh /
    # max. There is no minimal; Pi clamps it up to low. Pi leaves xhigh and
    # max unsupported unless they are mapped.
    "openai/gpt-6.1-terra": {
        "id": "gpt-6.1-terra",
        "name": "GPT-6.1 Terra",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 272000,
        "maxTokens": 128000,
        # Over 272K input tokens the whole request bills at 2x input/cache, 1.5x output.
        "cost": {
            "input": 1,
            "output": 5,
            "cacheRead": 0.05,
            "cacheWrite": 1.25,
            "tiers": [
                {
                    "inputTokensAbove": 272000,
                    "input": 2,
                    "output": 7.5,
                    "cacheRead": 0.1,
                    "cacheWrite": 2.5,
                }
            ],
        },
        "thinkingLevelMap": {
            "off": "none",
            "minimal": None,
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "xhigh",
            "max": "max",
        },
        "compat": {
            "supportsStrictMode": True,
            "supportsOpenAIGrammarTools": True,
            "supportsAdditionalTools": True,
            "supportsToolSearch": True,
            "supportsMidConvoSystemMessages": True,
            "supportsExplicitPromptCacheMode": True,
        },
        "inputLimits": {
            "maxRequestBytes": 536870912,
            "images": {
                "maxPerRequest": 1500,
                "resize": {
                    "maxWidth": 2000,
                    "maxHeight": 2000,
                    "maxBytes": 4718592,
                    "jpegQuality": 80,
                },
            },
        },
    },
}


def _gpt_6_2_pi_model_config(
    slug: str, name: str, *, input: float, output: float, cache_read: float
) -> dict[str, Any]:
    # GPT-6.2 Astra and Sol (released 2026-11-17) are newer than Pi's catalog.
    # Both reject none; OpenAI maps none/minimal to low. low..max pass through.
    # Cache writes cost 1.25x input; over 272K input tokens the whole request
    # bills at 2x input/cache and 1.5x output.
    return {
        **OPENAI_MODEL_CONFIGS["openai/gpt-6.1-terra"],
        "id": slug,
        "name": name,
        "cost": {
            "input": input,
            "output": output,
            "cacheRead": cache_read,
            "cacheWrite": input * 1.25,
            "tiers": [
                {
                    "inputTokensAbove": 272000,
                    "input": input * 2,
                    "output": output * 1.5,
                    "cacheRead": cache_read * 2,
                    "cacheWrite": input * 2.5,
                }
            ],
        },
        "thinkingLevelMap": {
            "off": None,
            "minimal": None,
            "low": "low",
            "medium": "medium",
            "high": "high",
            "xhigh": "xhigh",
            "max": "max",
        },
    }


# https://developers.openai.com/api/docs/models/gpt-6.2-astra
# https://developers.openai.com/api/docs/models/gpt-6.2-sol
OPENAI_MODEL_CONFIGS["openai/gpt-6.2-astra"] = _gpt_6_2_pi_model_config(
    "gpt-6.2-astra", "GPT-6.2 Astra", input=8, output=40, cache_read=0.4
)
OPENAI_MODEL_CONFIGS["openai/gpt-6.2-sol"] = _gpt_6_2_pi_model_config(
    "gpt-6.2-sol", "GPT-6.2 Sol", input=2, output=10, cache_read=0.1
)

FIREWORKS_PROVIDER_NAME = "fireworks"
FIREWORKS_PROVIDER_BASE_URL = "https://api.fireworks.ai/inference/v1"
FIREWORKS_MODEL_CONFIGS: dict[str, dict] = {
    # Fireworks has no shared reasoning effort knob. Pi parses reasoning output
    # without sending the OpenAI reasoning_effort field to this provider.
    "fireworks/accounts/fireworks/models/nemotron-lightning-3p5-30b-a3b": {
        "id": "accounts/fireworks/models/nemotron-lightning-3p5-30b-a3b",
        "name": "Nemotron Lightning 3.5",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 262144,
        "maxTokens": 32768,
        "cost": {"input": 0.05, "output": 0.2, "cacheRead": 0.01, "cacheWrite": 0},
        "compat": {
            "supportsReasoningEffort": False,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
    # Keep the old ID usable for saved run profiles; prefer OpenRouter Ultra
    # above for configurable reasoning effort.
    "fireworks/accounts/fireworks/models/nemotron-3-ultra-nvfp4": {
        "id": "accounts/fireworks/models/nemotron-3-ultra-nvfp4",
        "name": "Nemotron 3 Ultra NVFP4",
        "reasoning": True,
        "input": ["text"],
        "contextWindow": 262144,
        "maxTokens": 32768,
        "cost": {"input": 0.6, "output": 2.4, "cacheRead": 0.12, "cacheWrite": 0},
        "compat": {
            "supportsReasoningEffort": False,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
}

# Mistral's own chat completions API (https://api.mistral.ai/v1/chat/completions)
# is OpenAI-compatible, so pi talks to it through the same openai-completions
# provider shape as OpenRouter/Fireworks. La Plateforme only accepts the
# system/user/assistant/tool roles and only lists max_tokens, matching the
# compat flags below.
# https://docs.mistral.ai/capabilities/completion/
MISTRAL_PROVIDER_NAME = "mistral"
MISTRAL_PROVIDER_BASE_URL = "https://api.mistral.ai/v1"
MISTRAL_MODEL_CONFIGS: dict[str, dict] = {
    # Same model as openrouter/mistralai/mistral-large-4-0, served first-party.
    # Limits mirror the OpenRouter entry. Cost is Mistral's list price from the
    # Oct 29, 2026 open-weight release ($0.70 / $2.10, $0.07 cached), down from
    # the $1.36 / $4.18 preview price.
    # https://mistral.ai/news/mistral-large-4-oss/
    "mistral/mistral-large-4-0": {
        "id": "mistral-large-4-0",
        "name": "Mistral Large 4",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 524288,
        "maxTokens": 131072,
        "cost": {"input": 0.70, "output": 2.10, "cacheRead": 0.07, "cacheWrite": 0},
        "compat": {
            "supportsDeveloperRole": False,
            "supportsUsageInStreaming": True,
            "maxTokensField": "max_tokens",
        },
    },
}

# Direct Anthropic Messages API, with adaptive thinking required by Sonnet 5.5.
# https://platform.claude.com/docs/en/models/sonnet-5-5/overview
ANTHROPIC_MODEL_CONFIGS: dict[str, dict] = {
    "anthropic/claude-sonnet-5-5": {
        "id": "claude-sonnet-5-5",
        "name": "Claude Sonnet 5.5",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1000000,
        "maxTokens": 128000,
        "cost": {"input": 2, "output": 10, "cacheRead": 0.1, "cacheWrite": 2.5},
        # Pi only exposes max when the model explicitly maps it.
        "thinkingLevelMap": {"max": "max"},
        "compat": {
            "forceAdaptiveThinking": True,
            "supportsTemperature": False,
        },
    },
    # Haiku 5.5 has the same adaptive-thinking / no-sampling-params contract.
    # Cost is the <=100K-prompt tier; longer prompts bill at 5x.
    # https://platform.claude.com/docs/en/models/haiku-5-5/overview
    "anthropic/claude-haiku-5-5": {
        "id": "claude-haiku-5-5",
        "name": "Claude Haiku 5.5",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1000000,
        "maxTokens": 128000,
        "cost": {"input": 0.1, "output": 0.5, "cacheRead": 0.01, "cacheWrite": 0.125},
        # Pi only exposes max when the model explicitly maps it.
        "thinkingLevelMap": {"max": "max"},
        "compat": {
            "forceAdaptiveThinking": True,
            "supportsTemperature": False,
        },
    },
    # Fable 5.1: thinking is always on (adaptive only) and sampling params 400.
    # Cache reads are a reduced $0.25/M. Explicitly map max so Pi exposes it
    # instead of clamping it to high; other levels use Pi's defaults.
    # https://docs.anthropic.com/en/docs/about-claude/pricing
    "anthropic/claude-fable-5-1": {
        "id": "claude-fable-5-1",
        "name": "Claude Fable 5.1",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1000000,
        "maxTokens": 128000,
        "cost": {"input": 10, "output": 50, "cacheRead": 0.25, "cacheWrite": 12.5},
        "thinkingLevelMap": {"max": "max"},
        "compat": {
            "forceAdaptiveThinking": True,
            "supportsTemperature": False,
        },
    },
    # Fable 5.2, under its launch id and the pre-launch EAP id ("onigiri"). Pi
    # has no built-in metadata for either, so register both here. Thinking is
    # always on (adaptive only). $8 / $40; cache reads are a reduced $0.20/M
    # and cache writes the standard 1.25x. Limits assumed from Fable 5.1.
    "anthropic/claude-fable-5-2": {
        "id": "claude-fable-5-2",
        "name": "Claude Fable 5.2",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1000000,
        "maxTokens": 128000,
        "cost": {"input": 8, "output": 40, "cacheRead": 0.2, "cacheWrite": 10},
        "thinkingLevelMap": {"max": "max"},
        "compat": {
            "forceAdaptiveThinking": True,
            "supportsTemperature": False,
        },
    },
    "anthropic/claude-onigiri-eap": {
        "id": "claude-onigiri-eap",
        "name": "Claude Fable 5.2",
        "reasoning": True,
        "input": ["text", "image"],
        "contextWindow": 1000000,
        "maxTokens": 128000,
        "cost": {"input": 8, "output": 40, "cacheRead": 0.2, "cacheWrite": 10},
        "thinkingLevelMap": {"max": "max"},
        "compat": {
            "forceAdaptiveThinking": True,
            "supportsTemperature": False,
        },
    },
}

PI_CUSTOM_PROVIDERS = {
    "anthropic": (
        "https://api.anthropic.com",
        "ANTHROPIC_API_KEY",
        ANTHROPIC_MODEL_CONFIGS,
    ),
    OPENROUTER_PROVIDER_NAME: (
        OPENROUTER_PROVIDER_BASE_URL,
        "OPENROUTER_API_KEY",
        OPENROUTER_MODEL_CONFIGS,
    ),
    FIREWORKS_PROVIDER_NAME: (
        FIREWORKS_PROVIDER_BASE_URL,
        "FIREWORKS_API_KEY",
        FIREWORKS_MODEL_CONFIGS,
    ),
    MISTRAL_PROVIDER_NAME: (
        MISTRAL_PROVIDER_BASE_URL,
        "MISTRAL_API_KEY",
        MISTRAL_MODEL_CONFIGS,
    ),
}


# Only these native models have been verified with our supported Pi versions.
PI_NATIVE_FIREWORKS_MODELS = frozenset({"fireworks/accounts/fireworks/models/ember-1"})


def pi_custom_provider_config(model_name: str) -> dict:
    provider = model_name.partition("/")[0]
    if provider not in PI_CUSTOM_PROVIDERS:
        raise ValueError(f"No custom Pi provider for {model_name!r}")
    base_url, key, model_configs = PI_CUSTOM_PROVIDERS[provider]
    model = model_configs.get(model_name)
    if model is None and model_name in PI_NATIVE_FIREWORKS_MODELS:
        # Preserve Pi's native API, limits and thinking map (e.g. Ember-1).
        # Explicit legacy model overrides above still take precedence.
        return {"apiKey": f"${key}"}
    if model is None:
        raise ValueError(f"No pi {provider} model config registered for {model_name!r}")
    return {
        "baseUrl": base_url,
        "apiKey": f"${key}",
        "api": "anthropic-messages"
        if provider == "anthropic"
        else "openai-completions",
        "models": [model],
    }


PI_ANTHROPIC_IMAGE_MAX_BYTES = 1024 * 1024
PI_ANTHROPIC_COMPACTION_RESERVE_TOKENS = 65536


def _pi_anthropic_overrides(model_id: str) -> dict[str, Any]:
    return {
        model_id: {
            "inputLimits": {
                "images": {"resize": {"maxBytes": PI_ANTHROPIC_IMAGE_MAX_BYTES}}
            }
        }
    }


def _write_pi_anthropic_settings(agent_dir: Path) -> None:
    (agent_dir / "settings.json").write_text(
        json.dumps(
            {"compaction": {"reserveTokens": PI_ANTHROPIC_COMPACTION_RESERVE_TOKENS}},
            indent=2,
        ),
        encoding="utf-8",
    )


def _write_pi_model_config(work_dir: Path, model_name: str) -> None:
    provider, _, model_id = model_name.partition("/")
    agent_dir = work_dir / AGENT_STATE_DIRS["pi"] / "agent"
    agent_dir.mkdir(parents=True, exist_ok=True)
    if provider == "anthropic":
        provider_config = (
            pi_custom_provider_config(model_name)
            if model_name in ANTHROPIC_MODEL_CONFIGS
            else {}
        )
        provider_config["modelOverrides"] = _pi_anthropic_overrides(model_id)
        _write_pi_anthropic_settings(agent_dir)
    else:
        provider_config = pi_custom_provider_config(model_name)
    models_json = {"providers": {provider: provider_config}}
    (agent_dir / "models.json").write_text(
        json.dumps(models_json, indent=2), encoding="utf-8"
    )


def _write_pi_extension(work_dir: Path, name: str) -> None:
    extension_path = work_dir / AGENT_STATE_DIRS["pi"] / name
    extension_path.parent.mkdir(parents=True, exist_ok=True)
    extension_source = (
        files("latch_eval_tools")
        .joinpath("pi_extensions", name)
        .read_text(encoding="utf-8")
    )
    extension_path.write_text(extension_source, encoding="utf-8")


OOM_EXIT_CODE = 137
MAX_OOM_RESTARTS = 10

AGENT_STATE_DIRS = {
    "antigravity": ".gemini",
    "claudecode": ".claude",
    "openaicodex": ".codex",
    "pi": ".pi",
    "grokbuild": ".grok",
}
# By default the host state dir is bind-mounted onto /root/<state_dir_name>.
# grok is the exception: its ENTIRE install (binary in ~/.grok/downloads,
# symlinked via ~/.grok/bin) lives under ~/.grok, so mounting the state dir onto
# /root/.grok would shadow the binary and break `grok`. Mount onto the sessions
# subdir instead -- persists sessions across container recreation without
# hiding the install. (Verified: an empty mount over /root/.grok makes `grok`
# vanish from PATH; a mount over /root/.grok/sessions leaves it intact.)
AGENT_CONTAINER_STATE_MOUNTS = {
    "grokbuild": "/root/.grok/sessions",
}
AGENT_IDENTIFIER_KEYS = {
    "antigravity": "conversation_id",
    "claudecode": "session_id",
    "openaicodex": "thread_id",
    "pi": "id",
    # grok's final `end` event carries `sessionId` at the top level, so the flat
    # load_trajectory_identifier() finds it and resume works.
    "grokbuild": "sessionId",
}
PI_IGNORED_EVENT_TYPES = {"message_update", "tool_execution_update"}
PI_TOOL_TIMEOUT_EXTENSION_CONTAINER_PATH = "/root/.pi/tool_timeout.js"
PI_RUNTIME_EXTENSION_CONTAINER_PATH = "/root/.pi/provider_events.js"
PI_MAX_TURNS_EXTENSION_CONTAINER_PATH = "/root/.pi/max_turns.js"
PI_SINGLE_TOOL_CALL_EXTENSION_CONTAINER_PATH = "/root/.pi/single_tool_call.js"
PROVIDER_RETRYABLE_STATUS_CODES = frozenset(
    {408, 409, 425, 429, 500, 502, 503, 504, 520, 529}
)
PROVIDER_CAPACITY_STATUS_CODES = frozenset({429, 529})
PROVIDER_MESSAGE_MAX_CHARS = 500
DEFAULT_PROVIDER_RETRY_WAIT_SECONDS = 30 * 60.0
PROVIDER_RETRY_BACKOFF_MULTIPLIER = 2.0
PROVIDER_RETRY_MAX_DELAY_SECONDS = 300.0
PROVIDER_CAPACITY_FALLBACK_SECONDS = 60.0
PROVIDER_CAPACITY_JITTER_SECONDS = 15.0
PROVIDER_TRANSPORT_FALLBACK_SECONDS = 5.0
PROVIDER_TRANSPORT_JITTER_SECONDS = 5.0
PROVIDER_HINT_JITTER_SECONDS = 5.0
PI_ASSISTANT_EVENT_TYPES = frozenset({"message", "message_end", "turn_end"})
PI_STREAM_ERROR_MESSAGES = frozenset(
    {
        "Provider finish_reason: error",
        "Provider finish_reason: network_error",
        "Provider returned error: Provider finish_reason: error",
    }
)


@dataclass(frozen=True)
class ProviderFailure:
    status_code: int | None
    retry_after_seconds: float | None
    # Diagnostic payload, not identity: the provider's own text is what tells us
    # whether a 429 is quota or capacity, and the 2026-08-26 incident took hours
    # to diagnose without it.
    message: str | None = field(default=None, compare=False)
    stream_error: bool = False

    @property
    def retryable(self) -> bool:
        return self.status_code in PROVIDER_RETRYABLE_STATUS_CODES

    @property
    def capacity_limited(self) -> bool:
        return self.status_code in PROVIDER_CAPACITY_STATUS_CODES

    @property
    def error_code(self) -> str:
        if self.status_code is None:
            return (
                "provider_stream_error" if self.stream_error else "provider_api_error"
            )
        if self.status_code == 429:
            return "rate_limit"
        if self.status_code == 529:
            return "overloaded"
        if self.status_code >= 500:
            return "server_error"
        return f"http_{self.status_code}"


def _optional_int(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _optional_nonnegative_float(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    parsed = float(value)
    if not math.isfinite(parsed) or parsed < 0:
        return None
    return parsed


def _optional_nonnegative_decimal(value: object) -> float | None:
    if isinstance(value, str):
        try:
            return _optional_nonnegative_float(float(value))
        except ValueError:
            return None
    return _optional_nonnegative_float(value)


def _json_object(value: str) -> dict[str, object] | None:
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed


def _provider_error_payload(
    error_message: str,
) -> tuple[int | None, dict[str, object]] | None:
    # Pi can truncate long provider bodies or append a second JSON object.
    # The explicit HTTP error status still controls retry/backoff in that case.
    status = re.match(r"^\s*([45][0-9]{2})(?=[:\s])", error_message)
    prefix_status = int(status[1]) if status is not None else None
    json_start = error_message.find("{")
    payload = _json_object(error_message[json_start:]) if json_start >= 0 else None
    if payload is None and prefix_status is None:
        return None
    return prefix_status, payload or {}


def _payload_error(payload: dict[str, object]) -> dict[str, object] | None:
    value = payload.get("error")
    if not isinstance(value, dict):
        return None
    return value


def _nested_google_payload(
    payload: dict[str, object],
) -> dict[str, object] | None:
    outer_error = _payload_error(payload)
    if outer_error is None:
        return None
    message = outer_error.get("message")
    if not isinstance(message, str):
        return None
    return _json_object(message)


def _provider_status(
    prefix_status: int | None,
    payload: dict[str, object],
) -> int | None:
    if prefix_status is not None:
        return prefix_status
    status = _optional_int(payload.get("code"))
    if status is not None:
        return status
    error_payload = _payload_error(payload)
    if error_payload is None:
        return None
    return _optional_int(error_payload.get("code"))


def _grpc_retry_delay_seconds(value: object) -> float | None:
    if not isinstance(value, str) or not value.endswith("s"):
        return None
    try:
        return _optional_nonnegative_float(float(value[:-1]))
    except ValueError:
        return None


def _google_retry_hint_seconds(
    nested_payload: dict[str, object] | None,
) -> float | None:
    if nested_payload is None:
        return None
    nested_error = _payload_error(nested_payload)
    if nested_error is None:
        return None
    details = nested_error.get("details")
    if not isinstance(details, list):
        return None
    for detail in details:
        if not isinstance(detail, dict):
            continue
        if detail.get("@type") != "type.googleapis.com/google.rpc.RetryInfo":
            continue
        return _grpc_retry_delay_seconds(detail.get("retryDelay"))
    return None


def _openrouter_retry_hint_seconds(payload: dict[str, object]) -> float | None:
    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        return None

    retry_after = _optional_nonnegative_float(metadata.get("retry_after_seconds"))
    headers = metadata.get("headers")
    if not isinstance(headers, dict):
        return retry_after

    header_retry_after = _optional_nonnegative_decimal(headers.get("Retry-After"))
    if header_retry_after is not None:
        retry_after = max(retry_after or 0.0, header_retry_after)

    reset_milliseconds = _optional_nonnegative_decimal(headers.get("X-RateLimit-Reset"))
    if reset_milliseconds is not None:
        reset_delay = max((reset_milliseconds / 1000.0) - time.time(), 0.0)
        retry_after = max(retry_after or 0.0, reset_delay)
    return retry_after


def _pi_has_no_answer_content(message: dict[str, Any]) -> bool:
    content = message.get("content")
    if not isinstance(content, list):
        return False
    for block in content:
        if not isinstance(block, dict):
            return False
        if block.get("type") == "thinking":
            continue
        if block.get("type") != "text":
            return False
        text = block.get("text")
        if not isinstance(text, str) or text.strip():
            return False
    return True


def _pi_provider_failure(attempt_events: list[dict]) -> ProviderFailure | None:
    message = _pi_terminal_assistant_message(attempt_events)
    if message is None or message.get("stopReason") != "error":
        return None
    raw_error_message = message.get("errorMessage")
    error_message = (
        raw_error_message.strip()
        if isinstance(raw_error_message, str) and raw_error_message.strip()
        else "Pi returned a terminal provider error"
    )
    parsed = _provider_error_payload(error_message)
    prefix_status, payload = parsed if parsed is not None else (None, {})
    status_code = _provider_status(prefix_status, payload)
    if status_code is None:
        return ProviderFailure(
            status_code=None,
            retry_after_seconds=None,
            message=error_message[:PROVIDER_MESSAGE_MAX_CHARS],
            stream_error=(
                _pi_has_no_answer_content(message)
                and (
                    error_message in PI_STREAM_ERROR_MESSAGES
                    or error_message.startswith("Stream ended without ")
                )
            ),
        )
    nested_payload = _nested_google_payload(payload)
    retry_hints = [
        hint
        for hint in (
            _openrouter_retry_hint_seconds(payload),
            _google_retry_hint_seconds(nested_payload),
        )
        if hint is not None
    ]
    return ProviderFailure(
        status_code=status_code,
        retry_after_seconds=max(retry_hints, default=None),
        message=error_message[:PROVIDER_MESSAGE_MAX_CHARS],
    )


def _claudecode_provider_failure(
    attempt_events: list[dict],
    *,
    include_inflight_retry: bool,
) -> ProviderFailure | None:
    for result_index in range(len(attempt_events) - 1, -1, -1):
        result = attempt_events[result_index]
        if result.get("type") != "result":
            continue
        if result.get("terminal_reason") != "api_error":
            return None
        status_code = _optional_int(result.get("api_error_status"))
        if status_code is None:
            return None

        retry_after_seconds: float | None = None
        for event in reversed(attempt_events[:result_index]):
            if event.get("type") in {"assistant", "result"}:
                break
            if event.get("type") != "system" or event.get("subtype") != "api_retry":
                continue
            if _optional_int(event.get("error_status")) != status_code:
                continue
            retry_delay_ms = _optional_nonnegative_float(event.get("retry_delay_ms"))
            if retry_delay_ms is not None:
                retry_after_seconds = retry_delay_ms / 1000.0
            break

        return ProviderFailure(
            status_code=status_code,
            retry_after_seconds=retry_after_seconds,
        )

    if include_inflight_retry:
        for event in reversed(attempt_events):
            if event.get("type") == "assistant":
                return None
            if event.get("type") != "system" or event.get("subtype") != "api_retry":
                continue
            status_code = _optional_int(event.get("error_status"))
            if status_code is None:
                return None
            retry_delay_ms = _optional_nonnegative_float(event.get("retry_delay_ms"))
            return ProviderFailure(
                status_code=status_code,
                retry_after_seconds=(
                    retry_delay_ms / 1000.0 if retry_delay_ms is not None else None
                ),
            )
    return None


def _codex_provider_failure(events: list[dict]) -> ProviderFailure | None:
    # codex exec JSONL discards the typed error code (rust-v0.160.1).
    # Match only protocol/src/error.rs provider formats in native error frames.
    for event in reversed(events):
        kind = event.get("type")
        if kind in {"turn.started", "turn.completed"}:
            return None
        if kind not in {"turn.failed", "error"}:
            continue
        error = event.get("error") if kind == "turn.failed" else event
        if not isinstance(error, dict):
            return None
        message = error.get("message")
        if not isinstance(message, str):
            return None
        status = re.match(
            r"^(?:unexpected status |exceeded retry limit, last status: )([45][0-9]{2})(?=[:\s])",
            message,
        )
        status_code = int(status[1]) if status is not None else None
        if message.startswith("rate limit exceeded: "):
            status_code = 429
        stream_error = message.startswith("stream disconnected before completion: ")
        if status_code is None and not stream_error:
            return None
        return ProviderFailure(
            status_code=status_code,
            retry_after_seconds=None,
            message=message[:PROVIDER_MESSAGE_MAX_CHARS],
            stream_error=stream_error,
        )
    return None


def _grok_provider_failure(events: list[dict]) -> ProviderFailure | None:
    for event in reversed(events):
        if event.get("type") == "error":
            error = event.get("message", event.get("data"))
        elif event.get("type") == "end" and event.get("error") is not None:
            error = event["error"]
        else:
            continue
        if isinstance(error, str):
            # Native grok wraps its structured API error in this exact envelope.
            payload = _json_object(error.removeprefix("Internal error: "))
        else:
            payload = error if isinstance(error, dict) else None
        status_code = _optional_int(payload.get("http_status")) if payload else None
        message = payload.get("message") if payload else error
        if not isinstance(message, str):
            message = "Grok provider error"
        if status_code is None:
            status = re.match(r"^API error \(status ([45][0-9]{2})[ )]", message)
            status_code = int(status[1]) if status is not None else None
        if status_code is None or not 400 <= status_code <= 599:
            return None
        return ProviderFailure(
            status_code=status_code,
            retry_after_seconds=None,
            message=message[:PROVIDER_MESSAGE_MAX_CHARS],
        )
    return None


def classify_terminal_provider_failure(
    agent_type: str,
    attempt_events: list[dict],
    *,
    include_inflight_retry: bool = False,
) -> ProviderFailure | None:
    if agent_type == "claudecode":
        return _claudecode_provider_failure(
            attempt_events,
            include_inflight_retry=include_inflight_retry,
        )
    if agent_type == "pi":
        return _pi_provider_failure(attempt_events)
    if cli_termination(agent_type, attempt_events) != "failed":
        return None
    if agent_type == "openaicodex":
        return _codex_provider_failure(attempt_events)
    if agent_type == "grokbuild":
        return _grok_provider_failure(attempt_events)
    return None


def provider_retry_delay_seconds(failure: ProviderFailure, attempt: int) -> float:
    if not failure.retryable:
        raise ValueError("provider failure is not retryable")
    if attempt < 1:
        raise ValueError("provider retry attempt must be positive")
    if failure.retry_after_seconds is not None:
        base = failure.retry_after_seconds + random.uniform(
            0.0, PROVIDER_HINT_JITTER_SECONDS
        )
    elif failure.capacity_limited:
        base = PROVIDER_CAPACITY_FALLBACK_SECONDS + random.uniform(
            0.0, PROVIDER_CAPACITY_JITTER_SECONDS
        )
    else:
        base = PROVIDER_TRANSPORT_FALLBACK_SECONDS + random.uniform(
            0.0, PROVIDER_TRANSPORT_JITTER_SECONDS
        )
    # A zero provider hint must not create an unbounded tight retry loop. With
    # a minimum one-second base, ten doublings already exceed the local cap.
    delay = min(
        max(base, 1.0) * PROVIDER_RETRY_BACKOFF_MULTIPLIER ** min(attempt - 1, 10),
        PROVIDER_RETRY_MAX_DELAY_SECONDS,
    )
    # The cap bounds our backoff, never the provider's minimum wait.
    return max(delay, failure.retry_after_seconds or 0.0)


def _made_provider_progress(
    agent_type: CliHarnessAgentType, attempt_events: list[dict]
) -> bool:
    """Only a completed successful model response resets consecutive backoff."""
    for event in attempt_events:
        message = event.get("message")
        if not isinstance(message, dict) or message.get("role") != "assistant":
            continue
        if (
            agent_type == "pi"
            and event.get("type") in PI_ASSISTANT_EVENT_TYPES
            and message.get("stopReason") in {"stop", "toolUse", "length"}
        ):
            return True
        if (
            agent_type == "claudecode"
            and event.get("type") == "assistant"
            and message.get("stop_reason") in {"end_turn", "tool_use", "max_tokens"}
        ):
            return True
    return False


def teardown_container(container_name: str) -> None:
    try:
        remove_result = subprocess.run(
            ["docker", "rm", "-f", container_name],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if remove_result.returncode != 0:
            stderr = remove_result.stderr.strip()
            if not stderr or "No such container" not in stderr:
                print(f"Failed to remove container {container_name}: {stderr}")
    except Exception as exc:
        print(f"Failed to remove container {container_name}: {exc}")


def _build_agent_command(
    agent_type: str,
    cli_command: list[str],
    model_name: str | None,
    model_map: dict[str, str] | None,
    claude_code_extra_args: list[str] | None,
    resume_identifier: str | None = None,
    system_prompt: str | None = None,
    prompt_text: str | None = None,
    max_turns: int = 0,
    fork: bool = False,
    llm_connection: GatewayConnection | None = None,
) -> list[str]:
    if agent_type == "claudecode":
        agent_cmd = list(cli_command)
        if resume_identifier is not None:
            agent_cmd.extend(["--resume", resume_identifier])
            if fork:
                agent_cmd.append("--fork-session")
        agent_cmd.extend(
            [
                "--print",
                "--dangerously-skip-permissions",
                "--effort",
                "max",
                "--verbose",
                "--output-format",
                "stream-json",
                "--include-partial-messages",
                "--thinking-display",
                "summarized",
            ]
        )
        if max_turns > 0:
            agent_cmd.extend(["--max-turns", str(max_turns)])
        if claude_code_extra_args:
            agent_cmd.extend(claude_code_extra_args)
        if system_prompt not in (None, ""):
            agent_cmd.extend(["--system-prompt", system_prompt])
    elif agent_type == "openaicodex":
        agent_cmd = list(cli_command)
        if resume_identifier is not None:
            agent_cmd.append("resume")
        agent_cmd.extend(
            [
                "--dangerously-bypass-approvals-and-sandbox",
                "--skip-git-repo-check",
                "--json",
                "-c",
                'model_reasoning_effort="max"',
                "-c",
                'model_reasoning_summary="detailed"',
                "-c",
                "hide_agent_reasoning=false",
                "-c",
                "show_raw_agent_reasoning=true",
                "-c",
                "model_supports_reasoning_summaries=true",
            ]
        )
    elif agent_type == "pi":
        agent_cmd = list(cli_command)
        agent_cmd.extend(["--mode", "json", "--print"])
        if resume_identifier is not None:
            agent_cmd.extend(["--fork" if fork else "--session", resume_identifier])
        agent_cmd.extend(["--thinking", "max"])
        agent_cmd.extend(["--extension", PI_TOOL_TIMEOUT_EXTENSION_CONTAINER_PATH])
        agent_cmd.extend(["--extension", PI_RUNTIME_EXTENSION_CONTAINER_PATH])
        if max_turns > 0:
            agent_cmd.extend(
                [
                    "--extension",
                    PI_MAX_TURNS_EXTENSION_CONTAINER_PATH,
                    "--max-turns",
                    str(max_turns),
                ]
            )
        if system_prompt not in (None, ""):
            agent_cmd.extend(["--system-prompt", system_prompt])
    elif agent_type == "antigravity":
        if system_prompt or max_turns or fork:
            raise ValueError(
                "Antigravity does not support system_prompt, max_turns or fork"
            )
        effort = (
            llm_connection.configured_reasoning_effort
            if llm_connection is not None
            else None
        ) or "high"
        effort = effort.lower()
        if effort not in ANTIGRAVITY_GEMINI_EFFORTS:
            raise ValueError(
                "Antigravity Gemini effort must be low, medium, high or xhigh"
            )
        agent_cmd = [
            *cli_command,
            "--settings",
            '{"modelProvider":"gemini"}',
            "--dangerously-skip-permissions",
            "--disable-slash-commands",
            "--output-format",
            "stream-json",
            "--effort",
            effort,
            "--print",
            prompt_text or "",
        ]
        if resume_identifier is not None:
            agent_cmd.extend(["--conversation", resume_identifier])
    elif agent_type == "grokbuild":
        agent_cmd = list(cli_command)
        agent_cmd.extend(
            [
                "--no-auto-update",
                "--no-alt-screen",
                "--always-approve",
                "--cwd",
                "/workspace",
                "--output-format",
                "streaming-json",
            ]
        )
        if resume_identifier is not None:
            agent_cmd.extend(["--resume", resume_identifier])
        if system_prompt not in (None, ""):
            agent_cmd.extend(["--system-prompt", system_prompt])
        agent_cmd.extend(["-p", prompt_text if prompt_text is not None else ""])
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")

    preserve_claude_session_model = (
        agent_type == "claudecode" and resume_identifier is not None
    )
    if not preserve_claude_session_model and model_name and model_map:
        mapped_model = model_map.get(model_name, model_name)
        agent_cmd.extend(["--model", mapped_model])
    elif not preserve_claude_session_model and model_name:
        agent_cmd.extend(["--model", model_name])
    if llm_connection is not None:
        if agent_type == "pi" and model_name is not None:
            index = agent_cmd.index("--model")
            agent_cmd[index + 1] = "latch/" + llm_connection.wire_model(model_name)
        elif agent_type == "openaicodex":
            agent_cmd.extend(llm_connection.codex_args())
    if agent_type == "openaicodex" and resume_identifier is not None:
        agent_cmd.append(resume_identifier)
    return agent_cmd


def cli_container_env_flags(
    agent_type: CliHarnessAgentType,
    env: dict[str, str],
    *,
    eval_timeout: int,
    operation_timeout: int,
) -> list[str]:
    env_flags: list[str] = ["-e", "NODE_DISABLE_COMPILE_CACHE=1"]
    ENV_KEYS = {}
    if agent_type == "claudecode":
        ENV_KEYS = ANTHROPIC_ENV_KEYS
    elif agent_type == "openaicodex":
        ENV_KEYS = OPENAI_ENV_KEYS
    elif agent_type == "pi":
        ENV_KEYS = PI_ENV_KEYS
    elif agent_type == "grokbuild":
        ENV_KEYS = GROK_ENV_KEYS
    elif agent_type == "antigravity":
        ENV_KEYS = {"GEMINI_API_KEY", "GOOGLE_GEMINI_BASE_URL"}
        env_flags.extend(["-e", "AGY_CLI_DISABLE_AUTO_UPDATE=true"])
    else:
        raise ValueError(f"Unknown agent type: {agent_type}")
    extra_env_keys = set(json.loads(env.get("EXTRA_ENV_KEYS") or "[]"))
    ENV_KEYS = ENV_KEYS | extra_env_keys
    for key in ENV_KEYS:
        value = env.get(key)
        if value:
            env_flags.extend(["-e", f"{key}={value}"])
    if agent_type == "claudecode":
        bash_timeout_ms = eval_timeout * 1000
        env_flags.extend(
            [
                "-e",
                f"BASH_DEFAULT_TIMEOUT_MS={bash_timeout_ms}",
                "-e",
                f"BASH_MAX_TIMEOUT_MS={bash_timeout_ms}",
            ]
        )
    if agent_type == "pi":
        env_flags.extend(
            [
                "-e",
                "PI_SKIP_VERSION_CHECK=1",
                "-e",
                "PI_TELEMETRY=0",
                "-e",
                "NODE_OPTIONS=--max-old-space-size=8192",
            ]
        )
        if operation_timeout > 0:
            env_flags.extend(
                ["-e", f"PI_BASH_DEFAULT_TIMEOUT_SECONDS={operation_timeout}"]
            )
    return env_flags


def _create_cli_container(
    container_name: str,
    agent_type: str,
    work_dir: Path,
    agent_dir: Path,
    env_flags: list[str],
    docker_image: str,
    memory_limit_bytes: int,
    writable_data: bool = False,
) -> str:
    state_dir_name = AGENT_STATE_DIRS.get(agent_type)
    if state_dir_name is None:
        raise ValueError(f"Unknown agent type for state dir: {agent_type}")

    agent_state_dir = work_dir / state_dir_name
    agent_state_dir.mkdir(parents=True, exist_ok=True)
    container_state_mount = AGENT_CONTAINER_STATE_MOUNTS.get(
        agent_type, f"/root/{state_dir_name}"
    )
    subprocess.run(
        [
            "docker",
            "create",
            "--name",
            container_name,
            "-i",
            "--memory",
            str(memory_limit_bytes),
            "--memory-swap",
            str(memory_limit_bytes),
            *get_agent_workspace_mount_args(agent_dir, writable_data=writable_data),
            "-v",
            f"{agent_state_dir}:{container_state_mount}",
            "-w",
            "/workspace",
            *env_flags,
            docker_image,
            "sleep",
            "infinity",
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return container_state_mount


def _start_cli_container(container_name: str) -> None:
    try:
        result = subprocess.run(
            ["docker", "start", container_name],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            stderr = result.stderr.strip()
            print(f"Failed to start container {container_name}: {stderr}")
        assert result.returncode == 0, f"Failed to start container {container_name}"
    except Exception as e:
        print(f"Error starting container {container_name}: {e}")
        raise e


def _extract_last_message(trajectory: list[dict], agent_type: str) -> str:
    """Best-effort extract the agent's last assistant message from a CLI
    trajectory. Used by completion mode to surface a non-null agent_answer.
    Trajectory shape varies per CLI (claudecode/codex stream different events
    than pi), so this is permissive — any string that looks like assistant
    output works.
    """
    if agent_type == "antigravity":
        result = antigravity_result(trajectory)
        response = result.get("response") if result is not None else None
        return response if isinstance(response, str) else ""
    if agent_type == "grokbuild":
        # grok streams assistant text as flat {"type":"text","data":"..."} chunks,
        # emitting a fresh run of them after each tool call. Return the last
        # contiguous run (the final narration), not every chunk concatenated.
        segments: list[str] = []
        current: list[str] = []
        for event in trajectory:
            if event.get("type") == "text" and isinstance(event.get("data"), str):
                current.append(event["data"])
            elif current:
                segments.append("".join(current))
                current = []
        if current:
            segments.append("".join(current))
        for segment in reversed(segments):
            if segment.strip():
                return segment.strip()
        return ""

    for event in reversed(trajectory):
        if not isinstance(event, dict):
            continue
        message = event.get("message")
        if isinstance(message, dict) and message.get("role") == "assistant":
            content = message.get("content")
            if isinstance(content, str) and content.strip() != "":
                return content
            if isinstance(content, list):
                # Anthropic-style content blocks: [{"type":"text","text":"..."}]
                for block in reversed(content):
                    if (
                        isinstance(block, dict)
                        and block.get("type") == "text"
                        and isinstance(block.get("text"), str)
                        and block["text"].strip() != ""
                    ):
                        return block["text"]
        # codex/claudecode sometimes emit top-level {"type":"text","text":...}
        if event.get("type") == "text":
            text = event.get("text")
            if isinstance(text, str) and text.strip() != "":
                return text
    return ""


def _pi_clean_exit_needs_resume(attempt_events: list[dict]) -> bool:
    for event in reversed(attempt_events):
        if event.get("type") == "compaction_end":
            return event.get("aborted") is not True

        message = _pi_terminal_assistant_message([event])
        if message is not None:
            return message.get("stopReason") == "length"

    return False


def _iter_jsonl_objects(source: Path) -> Iterator[dict[str, Any]]:
    try:
        with source.open(encoding="utf-8") as source_file:
            for line in source_file:
                stripped = line.strip()
                if stripped == "":
                    continue
                try:
                    event = json.loads(stripped)
                except json.JSONDecodeError:
                    continue
                if isinstance(event, dict):
                    yield event
    except (OSError, UnicodeDecodeError) as exc:
        print(f"Failed to read harness sidecar {source}: {exc}")


def _read_codex_sidecar_events(
    work_dir: Path,
    trajectory: list[dict[str, Any]],
) -> list[dict[str, Any]] | None:
    thread_id = None
    for event in trajectory:
        value = event.get("thread_id")
        if isinstance(value, str) and value:
            thread_id = value
            break
    if thread_id is None:
        return None

    codex_dir = work_dir / AGENT_STATE_DIRS["openaicodex"]
    if not codex_dir.exists():
        return None

    matched_source = False
    events: list[dict[str, Any]] = []
    for source in sorted(codex_dir.rglob("*")):
        if source.is_dir() or source.is_symlink() or thread_id not in source.name:
            continue
        matched_source = True
        for event in _iter_jsonl_objects(source):
            event_type = event.get("type")
            payload = event.get("payload")
            if not isinstance(payload, dict):
                continue
            if event_type == "response_item" and payload.get("type") in {
                "function_call",
                "reasoning",
            }:
                events.append(event)
            elif event_type == "event_msg" and payload.get("type") == "token_count":
                events.append(event)
    return events if matched_source else None


def _read_pi_refusal_events(
    work_dir: Path,
) -> list[dict[str, Any]] | None:
    source = work_dir / AGENT_STATE_DIRS["pi"] / "refusal_events.jsonl"
    if not source.exists() or source.is_dir() or source.is_symlink():
        return None
    return list(_iter_jsonl_objects(source))


def _append_codex_sidecar_reasoning(
    trajectory: list[dict[str, Any]],
    sidecar_events: list[dict[str, Any]],
) -> int:

    existing_reasoning_ids = {
        event.get("payload", {}).get("id")
        for event in trajectory
        if (
            isinstance(event, dict)
            and event.get("type") == "response_item"
            and isinstance(event.get("payload"), dict)
            and event["payload"].get("type") == "reasoning"
        )
    }

    appended = 0
    for event in sidecar_events:
        if event.get("type") != "response_item":
            continue
        payload = event.get("payload")
        if not isinstance(payload, dict) or payload.get("type") != "reasoning":
            continue
        payload_id = payload.get("id")
        if payload_id in existing_reasoning_ids:
            continue
        trajectory.append(
            {
                "type": "response_item",
                "source": "codex_sidecar",
                "timestamp": event.get("timestamp"),
                "payload": payload,
            }
        )
        existing_reasoning_ids.add(payload_id)
        appended += 1

    return appended


def gateway_pi_descriptor(
    model_name: str, connection: GatewayConnection
) -> dict[str, Any]:
    provider, _, model_id = model_name.partition("/")
    known_model = (
        (
            GEMINI_MODEL_CONFIGS.get(model_id)
            if provider in {"gemini", "google"}
            else None
        )
        or OPENAI_MODEL_CONFIGS.get(model_name)
        or OPENROUTER_MODEL_CONFIGS.get(model_name)
        or FIREWORKS_MODEL_CONFIGS.get(model_name)
        or MISTRAL_MODEL_CONFIGS.get(model_name)
        or ANTHROPIC_MODEL_CONFIGS.get(model_name)
        or OPENROUTER_MODEL_CONFIGS.get(
            "openrouter/google/" + model_name.split("/", 1)[-1]
        )
    )
    descriptor = connection.pi_descriptor(model_name, known_model)
    if model_name.startswith("anthropic/"):
        descriptor["provider"]["modelOverrides"] = _pi_anthropic_overrides(
            wire_model(model_name)
        )
    return descriptor


def validate_pi_runtime(container_name: str) -> None:
    """Reject unsupported installations before a direct-provider run can start."""
    result = subprocess.run(
        [
            "docker",
            "exec",
            container_name,
            "sh",
            "-c",
            "node --experimental-import-meta-resolve --input-type=module -e "
            + shlex.quote(PI_RUNTIME_VALIDATION_SCRIPT)
            + ' "$(command -v pi)"',
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Pi runtime validation failed: {result.stderr.strip()[-4000:]}"
        )


def configure_gateway_pi(
    container_name: str, work_dir: Path, model_name: str, connection: GatewayConnection
) -> None:
    """Resolve model metadata in the installed Pi; config survives container restarts."""
    descriptor = work_dir / AGENT_STATE_DIRS["pi"] / "agent" / "gateway.json"
    descriptor.parent.mkdir(parents=True, exist_ok=True)
    descriptor.write_text(json.dumps(gateway_pi_descriptor(model_name, connection)))
    if model_name.startswith("anthropic/"):
        _write_pi_anthropic_settings(descriptor.parent)
    try:
        subprocess.run(
            [
                "docker",
                "exec",
                container_name,
                "sh",
                "-c",
                "node --experimental-import-meta-resolve --input-type=module -e "
                + shlex.quote(PI_GATEWAY_CONFIG_SCRIPT)
                + ' "$(command -v pi)" "$HOME/.pi/agent/gateway.json" "$HOME/.pi/agent/models.json"',
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or "No stderr").replace(connection.api_key, "[redacted]")
        raise RuntimeError(
            f"Pi gateway setup failed for {model_name} (exit {exc.returncode}): "
            f"{detail.strip()[-4000:]}"
        ) from None


def start_cli_container(
    agent_type: CliHarnessAgentType,
    work_dir: Path,
    docker_image: str,
    *,
    model_name: str | None,
    llm_connection: GatewayConnection | None,
    eval_timeout: int = EVAL_TIMEOUT,
    operation_timeout: int = 0,
    memory_limit_bytes: int | None = None,
    extra_env: dict[str, str] | None = None,
) -> str:
    """Create and start a harness container for a sequence of chunk runs.

    This is the container setup of ``_run_cli_agent`` without the agent loop,
    for callers that drive the session themselves with ``_run_cli_chunk``
    (multi-step rollouts). ``extra_env`` is added to the container environment
    and forwarded on every exec. Returns the container name; the caller owns
    the container and removes it with ``remove_cli_container``.
    """
    if not docker_image:
        raise ValueError("docker_image is required for CLI harnesses")
    env = os.environ.copy()
    if llm_connection is not None:
        env.update(llm_connection.environment())
        extras = json.loads(env.get("EXTRA_ENV_KEYS", "[]"))
        env["EXTRA_ENV_KEYS"] = json.dumps(
            sorted(set(extras) | set(llm_connection.environment()))
        )
    if extra_env:
        env.update(extra_env)
        extras = json.loads(env.get("EXTRA_ENV_KEYS", "[]"))
        env["EXTRA_ENV_KEYS"] = json.dumps(sorted(set(extras) | set(extra_env)))
    if agent_type == "openaicodex":
        if "CODEX_API_KEY" not in env and "OPENAI_API_KEY" in env:
            env["CODEX_API_KEY"] = env["OPENAI_API_KEY"]

    ensure_docker_image(docker_image)
    agent_dir = get_agent_workspace_dir(work_dir)
    agent_dir.mkdir(parents=True, exist_ok=True)
    if agent_type == "pi":
        _write_pi_extension(work_dir, "tool_timeout.js")
        _write_pi_extension(work_dir, "provider_events.js")
    env_flags = cli_container_env_flags(
        agent_type,
        env,
        eval_timeout=eval_timeout,
        operation_timeout=operation_timeout,
    )
    if memory_limit_bytes is None:
        memory_limit_bytes = get_memory_limit_bytes()
    container_name = f"eval-{agent_type}-{uuid.uuid4().hex[:8]}"
    _create_cli_container(
        container_name=container_name,
        agent_type=agent_type,
        work_dir=work_dir,
        agent_dir=agent_dir,
        env_flags=env_flags,
        docker_image=docker_image,
        memory_limit_bytes=memory_limit_bytes,
    )
    if (
        llm_connection is None
        and agent_type == "pi"
        and model_name
        and model_name.startswith(("anthropic/", "openrouter/", "fireworks/"))
    ):
        _write_pi_model_config(work_dir, model_name)
    _start_cli_container(container_name)
    if agent_type == "pi" and llm_connection is None:
        validate_pi_runtime(container_name)
    if llm_connection is not None and agent_type == "pi":
        if model_name is None:
            raise ValueError("A gateway Pi connection requires a model")
        configure_gateway_pi(container_name, work_dir, model_name, llm_connection)
    return container_name


def remove_cli_container(container_name: str) -> None:
    subprocess.run(
        ["docker", "rm", "-f", container_name],
        capture_output=True,
        text=True,
        timeout=60,
    )


def _run_cli_agent(
    agent_type: CliHarnessAgentType,
    cli_command: list[str],
    task_prompt: str,
    work_dir: Path,
    model_name: str | None = None,
    eval_timeout: int = EVAL_TIMEOUT,
    model_map: dict[str, str] | None = None,
    claude_code_extra_args: list[str] | None = None,
    docker_image: str = DEFAULT_DOCKER_IMAGE,
    memory_limit_bytes: int | None = None,
    system_prompt: str | None = None,
    prompt_suffix: str | None = None,
    completion: bool = False,
    benchmark: bool = False,
    operation_timeout: int = 0,
    completion_file_path: str | None = None,
    provider_retry_wait_seconds: float = DEFAULT_PROVIDER_RETRY_WAIT_SECONDS,
    llm_connection: GatewayConnection | None = None,
    writable_data: bool = False,
) -> dict:
    """``writable_data``: ``data/`` holds the caller's private copies, so the agent's
    container mounts it writable (``get_agent_workspace_mount_args``)."""
    if (
        isinstance(provider_retry_wait_seconds, bool)
        or not isinstance(provider_retry_wait_seconds, (int, float))
        or not math.isfinite(provider_retry_wait_seconds)
        or provider_retry_wait_seconds < 0
    ):
        raise ValueError("provider_retry_wait_seconds must be finite and nonnegative")
    agent_log_file = work_dir / "agent_output.log"
    if agent_log_file.exists():
        agent_log_file.unlink()
    if benchmark and prompt_suffix:
        prompt_suffix = benchmark_convention(prompt_suffix)
    enhanced_prompt = prompt_with_suffix(task_prompt, prompt_suffix)

    env = os.environ.copy()
    if llm_connection is not None:
        env.update(llm_connection.environment())
        extras = json.loads(env.get("EXTRA_ENV_KEYS", "[]"))
        env["EXTRA_ENV_KEYS"] = json.dumps(
            sorted(set(extras) | set(llm_connection.environment()))
        )
    fallback_api_keys = read_fallback_api_keys(env)
    # The container env is fixed at `docker run`; a key switch rides on `docker exec -e`.
    exec_env_flags: list[str] = []
    refusal_fallback_count = 0
    refusal_trajectory_start = 0
    refusal_events_start = 0
    terminal_refusal_detected = False

    if agent_type == "openaicodex":
        if "CODEX_API_KEY" not in env and "OPENAI_API_KEY" in env:
            env["CODEX_API_KEY"] = env["OPENAI_API_KEY"]

    if not docker_image:
        raise ValueError("docker_image is required for CLI harnesses")

    ensure_docker_image(docker_image)
    agent_dir = get_agent_workspace_dir(work_dir)
    completion_file = (
        agent_dir / completion_file_path if completion_file_path is not None else None
    )
    if agent_type == "pi":
        _write_pi_extension(work_dir, "tool_timeout.js")
        _write_pi_extension(work_dir, "provider_events.js")
    env_flags = cli_container_env_flags(
        agent_type,
        env,
        eval_timeout=eval_timeout,
        operation_timeout=operation_timeout,
    )
    if memory_limit_bytes is None:
        memory_limit_bytes = get_memory_limit_bytes()
    container_name = f"eval-{agent_type}-{uuid.uuid4().hex[:8]}"

    agent_start_time = time.time()
    agent_finished_at = agent_start_time
    timed_out = False
    agent_error: Exception | None = None
    trajectory: list[dict] = []
    trajectory_file = work_dir / "trajectory.json"
    trajectory_file.write_text(json.dumps(trajectory, indent=2))

    def _find_eval_answer_file() -> Path | None:
        return find_answer_file(agent_dir)

    oom_detected = False
    oom_restarts = 0
    provider_resumes = 0
    consecutive_provider_failures = 0
    provider_wait_seconds = 0.0
    provider_retry_stop_reason: str | None = None
    last_provider_failure: ProviderFailure | None = None

    trajectory_lock = threading.Lock()

    def persist_trajectory(*, final: bool = False):
        with trajectory_lock:
            output = (
                collect_antigravity_trajectory(work_dir, trajectory, final=final)
                if agent_type == "antigravity"
                else trajectory
            )
            trajectory_file.write_text(json.dumps(output, indent=2))

    try:
        container_state_mount = _create_cli_container(
            container_name=container_name,
            agent_type=agent_type,
            work_dir=work_dir,
            agent_dir=agent_dir,
            env_flags=env_flags,
            docker_image=docker_image,
            memory_limit_bytes=memory_limit_bytes,
            writable_data=writable_data,
        )
        # Register the custom provider into the (bind-mounted) pi state dir.
        # Written on the host so it survives container recreation on OOM.
        if (
            llm_connection is None
            and agent_type == "pi"
            and model_name
            and model_name.startswith(("anthropic/", "openrouter/", "fireworks/"))
        ):
            _write_pi_model_config(work_dir, model_name)
        _start_cli_container(container_name)
        if agent_type == "pi" and llm_connection is None:
            validate_pi_runtime(container_name)
        if llm_connection is not None and agent_type == "pi":
            if model_name is None:
                raise ValueError("A gateway Pi connection requires a model")
            configure_gateway_pi(container_name, work_dir, model_name, llm_connection)
        deadline = time.monotonic() + eval_timeout

        with open(agent_log_file, "w") as log_file:
            agent_start_time = time.time()
            prompt_text = enhanced_prompt
            resume_identifier: str | None = None
            last_return_code: int | None = None

            while True:
                remaining_timeout = deadline - time.monotonic()
                if remaining_timeout <= 0:
                    timed_out = True
                    log_file.write(
                        f"\n\nAgent timed out after {eval_timeout} seconds\n"
                    )
                    log_file.flush()
                    break

                # Only carry provider evidence from the final failed attempt.
                # A recovered rate limit must not relabel a later unrelated error.
                last_provider_failure = None
                attempt_start_index = len(trajectory)
                agent_cmd = _build_agent_command(
                    agent_type=agent_type,
                    cli_command=cli_command,
                    model_name=model_name,
                    model_map=model_map,
                    claude_code_extra_args=claude_code_extra_args,
                    resume_identifier=resume_identifier,
                    system_prompt=system_prompt,
                    prompt_text=prompt_text,
                    **({"llm_connection": llm_connection} if llm_connection else {}),
                )

                if agent_type == "grokbuild":
                    configure_grok(container_name, model_name, llm_connection)
                process = subprocess.Popen(
                    [
                        "docker",
                        "exec",
                        "-i",
                        *exec_env_flags,
                        container_name,
                        *agent_cmd,
                    ],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=str(agent_dir),
                    env=env,
                    text=True,
                    bufsize=1,
                )

                stderr_header_written = False
                stderr_lock = threading.Lock()

                def stream_stdout():
                    if process.stdout is None:
                        return
                    last_snapshot_at = time.monotonic()
                    try:
                        for line in process.stdout:
                            if agent_type != "pi":
                                log_file.write(line)
                                log_file.flush()

                            stripped = line.strip()
                            if not stripped:
                                continue
                            try:
                                event = json.loads(stripped)
                                if not isinstance(event, dict):
                                    continue
                                if (
                                    agent_type == "pi"
                                    and event.get("type") in PI_IGNORED_EVENT_TYPES
                                ):
                                    continue
                                with trajectory_lock:
                                    trajectory.append(event)
                                if (
                                    time.monotonic() - last_snapshot_at
                                    >= TRAJECTORY_SNAPSHOT_INTERVAL_SECONDS
                                ):
                                    persist_trajectory()
                                    last_snapshot_at = time.monotonic()
                            except json.JSONDecodeError:
                                print(f"Warning: Failed to parse JSON: {stripped}")
                    except ValueError:
                        pass

                def stream_stderr():
                    nonlocal stderr_header_written
                    if process.stderr is None:
                        return
                    try:
                        for line in process.stderr:
                            with stderr_lock:
                                if not stderr_header_written:
                                    log_file.write("\n\nSTDERR:\n")
                                    stderr_header_written = True
                                log_file.write(line)
                                log_file.flush()
                    except ValueError:
                        pass

                stdout_thread = threading.Thread(target=stream_stdout, daemon=True)
                stderr_thread = threading.Thread(target=stream_stderr, daemon=True)
                stdout_thread.start()
                stderr_thread.start()

                if process.stdin is not None:
                    if agent_type != "antigravity":
                        process.stdin.write(prompt_text)
                    process.stdin.close()

                timed_out_attempt = False
                try:
                    # Output files can be written before the model finishes its
                    # turn. Let print mode exit and drain its native events;
                    # only those events establish completed/failed/refused.
                    while process.poll() is None:
                        now = time.monotonic()
                        remaining_timeout = deadline - now
                        if remaining_timeout <= 0:
                            raise subprocess.TimeoutExpired(
                                process.args, remaining_timeout
                            )

                        time.sleep(min(1, remaining_timeout))
                except subprocess.TimeoutExpired:
                    timed_out_attempt = True
                    process.kill()
                    process.wait()

                stdout_thread.join()
                stderr_thread.join()
                last_return_code = process.returncode
                attempt_events = trajectory[attempt_start_index:]
                provider_failure = classify_terminal_provider_failure(
                    agent_type,
                    attempt_events,
                    include_inflight_retry=timed_out_attempt,
                )
                pi_refusal_events = (
                    _read_pi_refusal_events(work_dir) if agent_type == "pi" else None
                )
                refusal = (
                    detect_llm_refusal(
                        trajectory_data=attempt_events,
                        refusal_events_data=(pi_refusal_events or [])[
                            refusal_events_start:
                        ],
                    )
                    if (
                        agent_type == "pi"
                        or cli_termination(agent_type, attempt_events) == "refused"
                    )
                    and not timed_out_attempt
                    else None
                )
                if (
                    refusal is not None
                    and refusal.provider == "anthropic"
                    and fallback_api_keys
                ):
                    persist_trajectory()
                    identifier_key = AGENT_IDENTIFIER_KEYS.get(agent_type)
                    fallback_resume_identifier = (
                        load_trajectory_identifier(trajectory_file, identifier_key)
                        if identifier_key is not None
                        else None
                    )
                    if (
                        fallback_resume_identifier is not None
                        and is_docker_container_running(container_name)
                    ):
                        exec_env_flags = [
                            "-e",
                            f"ANTHROPIC_API_KEY={fallback_api_keys.pop(0)}",
                        ]
                        refusal_fallback_count += 1
                        refusal_trajectory_start = len(trajectory)
                        refusal_events_start = len(pi_refusal_events or [])
                        log_file.write(
                            f"\n\n[Refusal fallback {refusal_fallback_count}] "
                            f"resuming session {fallback_resume_identifier} on the "
                            "next API key\n"
                        )
                        log_file.flush()
                        resume_identifier = fallback_resume_identifier
                        prompt_text = "Continue."
                        continue
                # Refusals are a result, not a missing-output or transport retry.
                # Only the explicit Anthropic key fallback above may resume one.
                if refusal is not None:
                    terminal_refusal_detected = True
                    break
                if timed_out_attempt:
                    last_provider_failure = provider_failure
                    log_file.write(
                        f"\n\nAgent timed out after {eval_timeout} seconds\n"
                    )
                    log_file.flush()
                    timed_out = True
                    break

                if (
                    last_return_code == 0
                    and provider_failure is None
                    and (
                        completion_file.is_file()
                        if completion_file is not None
                        else (
                            _find_eval_answer_file() is not None
                            or find_finished_file(agent_dir)
                        )
                    )
                ):
                    break

                if _made_provider_progress(agent_type, attempt_events):
                    consecutive_provider_failures = 0

                if provider_failure is not None:
                    last_provider_failure = provider_failure
                    # Codex/Grok evidence informs the rollout scheduler; these
                    # adapters do not add an in-process session retry mechanism.
                    if provider_failure.retryable and agent_type in {
                        "pi",
                        "claudecode",
                    }:
                        consecutive_provider_failures += 1
                        persist_trajectory()
                        candidate_resume_identifier = load_trajectory_identifier(
                            trajectory_file,
                            AGENT_IDENTIFIER_KEYS[agent_type],
                        )
                        delay = provider_retry_delay_seconds(
                            provider_failure, consecutive_provider_failures
                        )
                        if candidate_resume_identifier is None:
                            provider_retry_stop_reason = "missing_session"
                        elif (
                            delay > provider_retry_wait_seconds - provider_wait_seconds
                        ):
                            provider_retry_stop_reason = "wait_budget_exhausted"
                        elif delay >= deadline - time.monotonic():
                            provider_retry_stop_reason = "run_deadline"
                        elif not is_docker_container_running(container_name):
                            provider_retry_stop_reason = "sandbox_stopped"
                        else:
                            provider_resumes += 1
                            resume_identifier = candidate_resume_identifier
                            retry_at = datetime.fromtimestamp(
                                time.time() + delay, tz=timezone.utc
                            )
                            retry_message = (
                                f"[Provider retry {provider_resumes}] waiting for provider "
                                f"HTTP {provider_failure.status_code}; resuming session "
                                f"{resume_identifier} at {retry_at.isoformat()} "
                                f"after {delay:.1f}s "
                                f"({provider_wait_seconds:.1f}/{provider_retry_wait_seconds:.1f}s "
                                "wait budget used)"
                            )
                            log_file.write(f"\n\n{retry_message}\n")
                            log_file.flush()
                            print(retry_message, flush=True)
                            wait_started = time.monotonic()
                            time.sleep(delay)
                            provider_wait_seconds += max(
                                delay, time.monotonic() - wait_started
                            )
                            # A cancelled/stopped sandbox must not be relaunched by
                            # provider recovery after a long cooldown.
                            if not is_docker_container_running(container_name):
                                provider_retry_stop_reason = "sandbox_stopped"
                                break
                            prompt_text = "Continue."
                            continue
                        log_file.write(
                            f"\n\nProvider recovery stopped: {provider_retry_stop_reason}\n"
                        )
                        log_file.flush()
                    # Do not bypass provider retry limits through the generic
                    # clean-exit or OOM resume paths below.
                    break

                if last_return_code == 0:
                    if (
                        agent_type == "pi"
                        and (
                            not completion_file.is_file()
                            if completion_file is not None
                            else _find_eval_answer_file() is None
                        )
                        and _pi_clean_exit_needs_resume(attempt_events)
                    ):
                        persist_trajectory()
                        resume_identifier = load_trajectory_identifier(
                            trajectory_file,
                            AGENT_IDENTIFIER_KEYS["pi"],
                        )
                        if resume_identifier is None:
                            agent_error = RuntimeError(
                                "pi compacted or hit length before emitting "
                                "a session id"
                            )
                            break

                        log_file.write(
                            "\n\nPi compacted or hit length before writing "
                            "the final answer file; resuming session "
                            f"{resume_identifier}\n"
                        )
                        log_file.flush()
                        prompt_text = "Continue."
                        continue
                    break

                container_running = is_docker_container_running(container_name)
                container_oom_killed = is_docker_container_oom_killed(container_name)
                attempt_hit_oom = (
                    last_return_code == OOM_EXIT_CODE or container_oom_killed
                )
                if not attempt_hit_oom:
                    if cli_termination(agent_type, attempt_events) == "failed":
                        break  # Native failure is not proof of a harness crash.
                    agent_error = RuntimeError(
                        f"{agent_type} exited with code {last_return_code}"
                    )
                    break

                oom_detected = True
                if oom_restarts >= MAX_OOM_RESTARTS:
                    agent_error = RuntimeError(
                        f"{agent_type} exceeded max OOM restarts ({MAX_OOM_RESTARTS})"
                    )
                    log_file.write(
                        f"\n\nExceeded max OOM restarts ({MAX_OOM_RESTARTS})\n"
                    )
                    log_file.flush()
                    break

                identifier_key = AGENT_IDENTIFIER_KEYS.get(agent_type)
                if identifier_key is None:
                    raise ValueError(
                        f"Unknown agent type for resume identifier: {agent_type}"
                    )

                persist_trajectory()
                resume_identifier = load_trajectory_identifier(
                    trajectory_file,
                    identifier_key,
                )
                if resume_identifier is None:
                    agent_error = RuntimeError(
                        f"{agent_type} hit OOM before emitting {identifier_key}"
                    )
                    break

                if container_running:
                    container_action = (
                        "The execution container stayed alive and the agent process "
                        "is being resumed in place."
                    )
                else:
                    subprocess.run(
                        ["docker", "rm", "-f", container_name],
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    container_state_mount = _create_cli_container(
                        container_name=container_name,
                        agent_type=agent_type,
                        work_dir=work_dir,
                        agent_dir=agent_dir,
                        env_flags=env_flags,
                        docker_image=docker_image,
                        memory_limit_bytes=memory_limit_bytes,
                        writable_data=writable_data,
                    )
                    _start_cli_container(container_name)
                    container_action = (
                        "The execution container was restarted before the session "
                        "was resumed."
                    )

                oom_restarts += 1
                log_file.write(
                    f"\n\n[OOM restart {oom_restarts}/{MAX_OOM_RESTARTS}]\n"
                    f"{container_action}\n"
                )
                log_file.flush()
                prompt_text = render_packaged_prompt(
                    "oom_restart.md",
                    container_action=container_action,
                    state_dir=container_state_mount,
                )

    except Exception as e:
        agent_error = e
        with open(agent_log_file, "a") as f:
            f.write(f"\nError running {agent_type}: {e}")
    finally:
        agent_finished_at = time.time()
        teardown_container(container_name)

    duration = agent_finished_at - agent_start_time
    print(
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} Agent output saved to: {agent_log_file}"
    )

    codex_sidecar_events: list[dict[str, Any]] | None = None
    pi_refusal_events: list[dict[str, Any]] | None = None
    if agent_type == "openaicodex" and trajectory:
        codex_sidecar_events = _read_codex_sidecar_events(work_dir, trajectory)
        appended_reasoning = (
            _append_codex_sidecar_reasoning(trajectory, codex_sidecar_events)
            if codex_sidecar_events is not None
            else 0
        )
        if appended_reasoning > 0:
            print(
                "Appended "
                f"{appended_reasoning} Codex reasoning item(s) from sidecar to trajectory"
            )
    elif agent_type == "pi":
        pi_refusal_events = _read_pi_refusal_events(work_dir) or []

    if trajectory:
        try:
            persist_trajectory(final=True)
        except (OSError, ValueError) as exc:
            agent_error = RuntimeError(f"Full transcript collection failed: {exc}")
        print(f"Trajectory saved to: {trajectory_file}")

    agent_answer = None
    error_details = None

    def _log_tail() -> str:
        if not agent_log_file.exists():
            return ""
        return agent_log_file.read_text()[-1000:]

    termination = cli_termination(agent_type, trajectory[refusal_trajectory_start:])
    if terminal_refusal_detected:
        termination = "refused"
    elif (
        timed_out
        or agent_error is not None
        or (agent_type in {"pi", "antigravity"} and last_return_code not in {None, 0})
    ):
        termination = "failed"

    if termination == "refused":
        error_details = {
            "error": "LLM refusal",
            "timed_out": False,
            "log_tail": _log_tail(),
        }
    elif termination == "failed" or last_provider_failure is not None:
        error_details = {
            "error": (
                "Agent timed out"
                if timed_out
                else f"Provider error: {last_provider_failure.error_code}"
                if last_provider_failure is not None
                else str(agent_error)
                if agent_error is not None
                else "Agent turn failed"
            ),
            "timed_out": timed_out,
            "log_tail": _log_tail(),
        }
    elif completion_file is None:
        # Declared outputs are read once by the caller's contract validator.
        agent_answer, error_details = read_legacy_answer(
            agent_dir,
            completion=completion,
            last_message=_extract_last_message(trajectory, agent_type),
        )

    if error_details is not None:
        error_code: HarnessErrorCode
        if timed_out or cli_budget_exhausted(
            agent_type, trajectory[refusal_trajectory_start:]
        ):
            error_code = "agent_budget_exhausted"
        elif (
            agent_error is not None
            or error_details.get("error_code") == "harness_execution_failed"
        ):
            error_code = "harness_execution_failed"
        elif termination in {"failed", "refused"} or last_provider_failure is not None:
            error_code = "agent_turn_failed"
        else:
            error_code = "output_contract_failed"
        error_details["error_code"] = error_code

    if error_details is not None and last_provider_failure is not None:
        error_details["api_error_code"] = last_provider_failure.error_code
        if last_provider_failure.status_code is not None:
            error_details["api_error_status"] = last_provider_failure.status_code
        if last_provider_failure.message is not None:
            error_details["api_error_message"] = last_provider_failure.message
        if last_provider_failure.retry_after_seconds is not None:
            error_details["retry_after_seconds"] = (
                last_provider_failure.retry_after_seconds
            )
        error_details["provider_retry_count"] = provider_resumes
        error_details["provider_retry_wait_seconds"] = provider_wait_seconds
        if provider_retry_stop_reason is not None:
            error_details["provider_retry_stop_reason"] = provider_retry_stop_reason

    structured_agent_error = None
    if error_details is not None:
        error_value = error_details.get("error")
        if isinstance(error_value, str):
            structured_agent_error = error_value

    # Termination follows the final attempt; refusal evidence covers every attempt.
    refusal_trajectory = trajectory[refusal_trajectory_start:]
    metadata = _extract_metadata(
        agent_type,
        trajectory,
        duration,
        model_name,
        timed_out,
        eval_timeout,
        error_details,
        oom_detected=oom_detected,
        oom_restarts=oom_restarts,
        memory_limit_bytes=memory_limit_bytes,
        work_dir=work_dir,
        codex_sidecar_events=codex_sidecar_events,
        refusal_events=pi_refusal_events,
        agent_error=structured_agent_error,
        refusal_trajectory=refusal_trajectory,
        termination=termination,
    )
    metadata["refusal_fallback_count"] = refusal_fallback_count
    if agent_type in {"pi", "claudecode"}:
        metadata["provider_retry_count"] = provider_resumes
        metadata["provider_retry_wait_seconds"] = provider_wait_seconds

    _write_refusal_verdict(
        work_dir,
        refusal_trajectory,
        refusal_events=(pi_refusal_events or [])[refusal_events_start:],
        agent_error=structured_agent_error,
    )

    return {"answer": agent_answer, "metadata": metadata}


@dataclass(frozen=True)
class CliChunkResult:
    session_id: str
    session_file: Path
    turns: int
    hit_turn_limit: bool


def chunk_outcome(
    agent_type: CliHarnessAgentType, events: list[dict[str, Any]], returncode: int
) -> tuple[int, bool, bool, str]:
    """``(turns, hit_turn_limit, failed, detail)`` for one chunk's event stream.

    Each CLI reports turns in its own stream: Claude Code's ``assistant`` messages
    and terminal ``result``, Codex's ``turn.completed`` / ``turn.failed``, Pi's
    ``turn_end`` with a ``stopReason``. Codex has no turn cap, so it never hits a
    turn limit; a failed turn is reported through its ``turn.failed`` error.
    """
    if agent_type == "claudecode":
        result = next(
            (event for event in reversed(events) if event.get("type") == "result"),
            {},
        )
        hit_turn_limit = result.get("subtype") == "error_max_turns"
        failed = returncode != 0 and not hit_turn_limit
        detail = result.get("result", "")
        turns = len(
            {
                event["message"]["id"]
                for event in events
                if event.get("type") == "assistant"
                and event.get("parent_tool_use_id") is None
            }
        )
        return turns, hit_turn_limit, failed, detail
    if agent_type == "openaicodex":
        turns = sum(1 for event in events if event.get("type") == "turn.completed")
        failed_turn = next(
            (event for event in reversed(events) if event.get("type") == "turn.failed"),
            None,
        )
        failed = returncode != 0 or failed_turn is not None
        error = failed_turn.get("error") if failed_turn is not None else None
        detail = error.get("message", "") if isinstance(error, dict) else ""
        return turns, False, failed, detail
    last_turn = next(
        (
            event["message"]
            for event in reversed(events)
            if event.get("type") == "turn_end"
        ),
        {},
    )
    hit_turn_limit = last_turn.get("stopReason") in ("aborted", "length")
    failed = returncode != 0 or last_turn.get("stopReason") == "error"
    detail = last_turn.get("errorMessage", "")
    turns = sum(
        1
        for event in events
        if event.get("type") == "turn_end"
        and event["message"]["stopReason"] not in ("error", "aborted")
    )
    return turns, hit_turn_limit, failed, detail


def _run_cli_chunk(
    agent_type: CliHarnessAgentType,
    cli_command: list[str],
    container_name: str,
    prompt: str,
    work_dir: Path,
    max_turns: int,
    model_name: str | None,
    system_prompt: str | None,
    resume_identifier: str | None,
    fork: bool,
    timeout: int,
    model_map: dict[str, str] | None = None,
    claude_code_extra_args: list[str] | None = None,
    parallel_tool_calls: bool = True,
    llm_connection: GatewayConnection | None = None,
) -> CliChunkResult:
    agent_cmd = _build_agent_command(
        agent_type=agent_type,
        cli_command=cli_command,
        model_name=model_name,
        model_map=model_map,
        claude_code_extra_args=claude_code_extra_args,
        resume_identifier=resume_identifier,
        system_prompt=system_prompt,
        max_turns=max_turns,
        fork=fork,
        **({"llm_connection": llm_connection} if llm_connection is not None else {}),
    )
    if agent_type == "pi":
        _write_pi_extension(work_dir, "tool_timeout.js")
        _write_pi_extension(work_dir, "provider_events.js")
        _write_pi_extension(work_dir, "max_turns.js")
        if llm_connection is None:
            validate_pi_runtime(container_name)
        if llm_connection is not None and model_name is not None:
            configure_gateway_pi(container_name, work_dir, model_name, llm_connection)
        elif model_name and model_name.startswith(
            ("anthropic/", "openrouter/", "fireworks/")
        ):
            _write_pi_model_config(work_dir, model_name)
        if not parallel_tool_calls:
            _write_pi_extension(work_dir, "single_tool_call.js")
            agent_cmd.extend(
                ["--extension", PI_SINGLE_TOOL_CALL_EXTENSION_CONTAINER_PATH]
            )
    events: list[dict[str, Any]] = []
    trajectory_file = work_dir / "trajectory.json"
    agent_log_file = work_dir / "agent_output.log"

    with open(agent_log_file, "w") as log_file:
        process = subprocess.Popen(
            ["docker", "exec", "-i", container_name, *agent_cmd],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=log_file,
            text=True,
        )

        def stream_stdout() -> None:
            if process.stdout is None:
                return
            last_snapshot_at = time.monotonic()
            for line in process.stdout:
                event = _json_object(line)
                if event is None or (
                    agent_type == "pi" and event.get("type") in PI_IGNORED_EVENT_TYPES
                ):
                    continue
                events.append(event)
                if (
                    time.monotonic() - last_snapshot_at
                    >= TRAJECTORY_SNAPSHOT_INTERVAL_SECONDS
                ):
                    trajectory_file.write_text(json.dumps(events, indent=2))
                    last_snapshot_at = time.monotonic()

        stdout_thread = threading.Thread(target=stream_stdout, daemon=True)
        stdout_thread.start()
        if process.stdin is not None:
            process.stdin.write(prompt)
            process.stdin.close()
        try:
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            subprocess.run(
                ["docker", "exec", container_name, "sh", "-c", "kill -9 -1"],
                capture_output=True,
            )
            raise RuntimeError(f"{agent_type} chunk timed out after {timeout}s")
        stdout_thread.join()
    trajectory_file.write_text(json.dumps(events, indent=2))

    turns, hit_turn_limit, failed, detail = chunk_outcome(
        agent_type, events, returncode
    )
    if failed:
        raise RuntimeError(
            f"{agent_type} chunk failed with exit code {returncode}: {detail}\n"
            f"{agent_log_file.read_text()[-1000:]}"
        )

    identifier_key = AGENT_IDENTIFIER_KEYS[agent_type]
    session_id = next(
        event[identifier_key] for event in reversed(events) if event.get(identifier_key)
    )
    return CliChunkResult(
        session_id=session_id,
        session_file=next(
            (work_dir / AGENT_STATE_DIRS[agent_type]).rglob(f"*{session_id}.jsonl")
        ),
        turns=turns,
        hit_turn_limit=hit_turn_limit,
    )


_UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
    re.IGNORECASE,
)


def _scan_grok_session_id(work_dir: Path) -> str | None:
    """Recover the grok session id from the on-disk session store.

    grok persists a session record under ``work_dir/.grok`` (bind-mounted onto
    ``/root/.grok/sessions`` in the container, see AGENT_CONTAINER_STATE_MOUNTS)
    as soon as the session is created -- well before the terminal ``end`` event,
    which is our only other source of the id. Reading it from disk means we
    still capture the session id when a run drops (timeout / OOM / crash) before
    emitting ``end``. Returns the id from the most recently modified session
    record, or ``None`` if none can be found. Never raises.
    """
    sessions_dir = work_dir / AGENT_STATE_DIRS["grokbuild"]  # <work_dir>/.grok
    if not sessions_dir.is_dir():
        return None

    candidates: list[tuple[float, str]] = []
    try:
        entries = list(sessions_dir.rglob("*"))
    except OSError:
        return None
    for entry in entries:
        try:
            mtime = entry.stat().st_mtime
        except OSError:
            continue
        # Session id is normally the file/dir name (e.g. `<uuid>.json`).
        name_match = _UUID_RE.search(entry.name)
        if name_match:
            candidates.append((mtime, name_match.group(0)))
            continue
        # Fall back to a `sessionId`/`id` field inside a JSON session record.
        if entry.is_file() and entry.suffix == ".json":
            try:
                data = json.loads(entry.read_text())
            except (OSError, ValueError):
                continue
            if isinstance(data, dict):
                sid = data.get("sessionId") or data.get("session_id") or data.get("id")
                if isinstance(sid, str) and _UUID_RE.search(sid):
                    candidates.append((mtime, sid))

    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])  # oldest -> newest
    return candidates[-1][1]


def _extract_metadata(
    agent_type: CliHarnessAgentType,
    trajectory: list[dict[str, Any]],
    duration: float,
    model_name: str | None,
    timed_out: bool,
    eval_timeout: int,
    error_details: dict[str, Any] | None,
    oom_detected: bool,
    oom_restarts: int,
    memory_limit_bytes: int,
    work_dir: Path,
    codex_sidecar_events: list[dict[str, Any]] | None = None,
    refusal_events: list[dict[str, Any]] | None = None,
    agent_error: str | None = None,
    refusal_trajectory: list[dict[str, Any]] | None = None,
    termination: HarnessTermination | None = None,
) -> dict[str, Any]:
    run_summary = build_cli_run_summary(
        agent_type=agent_type,
        trajectory=trajectory,
        duration_seconds=duration,
        model_name=model_name,
        codex_sidecar_events=codex_sidecar_events,
        refusal_events=refusal_events,
        agent_error=agent_error,
        refusal_trajectory=refusal_trajectory,
        termination=termination,
    )
    metrics = run_summary.metrics
    metadata = {
        "duration_s": round(duration, 2),
        "model": model_name,
        "memory_limit_bytes": memory_limit_bytes,
        "run_summary": run_summary.model_dump(mode="json"),
    }

    if agent_type == "claudecode":
        claude_result = next(
            (event for event in reversed(trajectory) if event.get("type") == "result"),
            None,
        )
        if claude_result is not None:
            metadata["session_id"] = claude_result.get("session_id")
            usage = claude_result.get("usage")
            if isinstance(usage, dict):
                metadata["usage"] = usage
    elif agent_type == "openaicodex":
        thread_id = None
        for event in trajectory:
            if event.get("type") == "thread.started":
                thread_id = event.get("thread_id")
        if thread_id:
            metadata["thread_id"] = thread_id
    elif agent_type == "antigravity":
        result = antigravity_result(trajectory)
        if result is not None:
            metadata["session_id"] = result.get("conversation_id")
    elif agent_type == "pi":
        session_id = None
        for event in trajectory:
            if event.get("type") == "session":
                session_id = event.get("id")
        if session_id:
            metadata["session_id"] = session_id
    elif agent_type == "grokbuild":
        session_id = None
        request_ids: list[str] = []
        for event in trajectory:
            if event.get("sessionId"):
                session_id = event.get("sessionId")
            if event.get("requestId"):
                request_ids.append(event["requestId"])
        if session_id is not None:
            metadata["session_id_source"] = "end_event"
        else:
            # The terminal `end` event never arrived (timeout / OOM / crash),
            # so recover the id from grok's on-disk session store, which is
            # written when the session is created.
            session_id = _scan_grok_session_id(work_dir)
            if session_id is not None:
                metadata["session_id_source"] = "session_store"
        if session_id:
            metadata["session_id"] = session_id
        if request_ids:
            metadata["request_ids"] = request_ids

    if metrics.total_cost_usd is not None:
        metadata["total_cost"] = metrics.total_cost_usd
    if metrics.turn_count is not None:
        metadata["n_turns"] = metrics.turn_count
    if metrics.step_count is not None:
        metadata["n_steps"] = metrics.step_count
    if "usage" not in metadata:
        canonical_usage = metrics.usage.model_dump(exclude_none=True)
        if canonical_usage:
            metadata["usage"] = canonical_usage

    metadata["timed_out"] = timed_out
    metadata["eval_timeout_seconds"] = eval_timeout
    metadata["oom_detected"] = oom_detected
    metadata["oom_restarts"] = oom_restarts
    if error_details:
        metadata["error_details"] = error_details

    return metadata
