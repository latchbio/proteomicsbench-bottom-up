"""Preserve refused responses before Mini-SWE parses required tool calls.

These adapters return the ordinary model message with no actions on refusal.
The agent records its cost and response before terminating the run.
"""

from typing import Any

from litellm.types.llms.openai import ResponsesAPIResponse
from litellm.types.utils import ModelResponse
from minisweagent.agents.default import DefaultAgent
from minisweagent.exceptions import InterruptAgentFlow
from minisweagent.models.litellm_model import LitellmModel
from minisweagent.models.litellm_response_model import LitellmResponseModel

from latch_eval_tools.llm_refusal import detect_llm_refusal


class RefusalAwareAgent(DefaultAgent):
    def execute_actions(self, message: dict) -> list[dict]:
        extra = message.get("extra")
        response = (
            extra.get("response", message) if isinstance(extra, dict) else message
        )
        if detect_llm_refusal(trajectory_data=response) is not None:
            raise InterruptAgentFlow(
                {
                    "role": "exit",
                    "content": "LLMRefusal",
                    "extra": {"exit_status": "LLMRefusal", "submission": ""},
                }
            )
        return super().execute_actions(message)


class RefusalAwareChatModel(LitellmModel):
    def _parse_actions(self, response: ModelResponse) -> list[dict[str, Any]]:
        if detect_llm_refusal(trajectory_data=response.model_dump()) is not None:
            return []
        return super()._parse_actions(response)


class RefusalAwareResponseModel(LitellmResponseModel):
    def _parse_actions(self, response: ResponsesAPIResponse) -> list[dict[str, Any]]:
        if detect_llm_refusal(trajectory_data=response.model_dump()) is not None:
            return []
        return super()._parse_actions(response)


def refusal_aware_model_config(config: dict[str, Any]) -> dict[str, Any]:
    adapters = {
        "": RefusalAwareChatModel,
        "litellm": RefusalAwareChatModel,
        "litellm_response": RefusalAwareResponseModel,
        "minisweagent.models.litellm_model.LitellmModel": RefusalAwareChatModel,
        "minisweagent.models.litellm_response_model.LitellmResponseModel": RefusalAwareResponseModel,
    }
    model_class = config.get("model_class", "")
    adapter = adapters.get(model_class) if isinstance(model_class, str) else None
    if adapter is None:
        return config
    return config | {"model_class": f"{adapter.__module__}.{adapter.__name__}"}
