import os
from pathlib import Path

from latch_eval_tools.harness._cli_runner import (
    EVAL_TIMEOUT,
    CliChunkResult,
    _run_cli_agent,
    _run_cli_chunk,
)
from latch_eval_tools.harness.llm_connection import GatewayConnection
from latch_eval_tools.harness.utils import DEFAULT_DOCKER_IMAGE, load_data_instructions

MODEL_MAP = {
    "openai/gpt-6.2-astra": "gpt-6.2-astra",
    "openai/gpt-6.2-sol": "gpt-6.2-sol",
    "openai/gpt-6.1-terra": "gpt-6.1-terra",
    "openai/gpt-6.1-sol": "gpt-6.1-sol",
    "openai/gpt-6-sol": "gpt-6-sol",
    "openai/gpt-6-luna": "gpt-6-luna",
    "openai/gpt-6-astra": "gpt-6-astra",
    "openai/gpt-5.6-terra": "gpt-5.6-terra",
    "openai/gpt-5.6-luna": "gpt-5.6-luna",
    "openai/gpt-5.6-sol": "gpt-5.6-sol",
    "openai/gpt-5.5": "gpt-5.5",
    "openai/gpt-5.4": "gpt-5.4",
    "openai/gpt-5.3-codex": "gpt-5.3-codex",
    "openai/gpt-5.2-codex": "gpt-5.2-codex",
    "openai/gpt-5.1-codex-mini": "gpt-5.1-codex-mini",
    "openai/gpt-5.1-codex-max": "gpt-5.1-codex-max",
    "openai/gpt-5.2": "gpt-5.2",
    "openai/gpt-5.1": "gpt-5.1",
    "openai/gpt-5.1-codex": "gpt-5.1-codex",
    "openai/gpt-5-codex": "gpt-5-codex",
    "openai/gpt-5-codex-mini": "gpt-5-codex-mini",
    "openai/gpt-5": "gpt-5",
    "openai/gpt-4o": "gpt-4o",
    "openai/o1": "o1",
    "openai/o1-mini": "o1-mini",
}


def run_openaicodex_task(
    task_prompt: str,
    work_dir: Path,
    model_name: str | None = None,
    eval_timeout: int = EVAL_TIMEOUT,
    docker_image: str = DEFAULT_DOCKER_IMAGE,
    memory_limit_bytes: int | None = None,
    prompt_suffix: str | None = load_data_instructions(),
    completion: bool = False,
    benchmark: bool = False,
    completion_file_path: str | None = None,
    llm_connection: GatewayConnection | None = None,
    writable_data: bool = False,
) -> dict:
    openai_key = os.environ.get("OPENAI_API_KEY")
    codex_key = os.environ.get("CODEX_API_KEY")

    if llm_connection is None and openai_key is None and codex_key is None:
        raise ValueError(
            "OPENAI_API_KEY or CODEX_API_KEY environment variable is required for OpenAI Codex"
        )

    if openai_key is not None and codex_key is None:
        os.environ["CODEX_API_KEY"] = openai_key

    return _run_cli_agent(
        llm_connection=llm_connection,
        agent_type="openaicodex",
        cli_command=["codex", "exec"],
        task_prompt=task_prompt,
        work_dir=work_dir,
        model_name=model_name,
        eval_timeout=eval_timeout,
        model_map=MODEL_MAP,
        docker_image=docker_image,
        memory_limit_bytes=memory_limit_bytes,
        prompt_suffix=prompt_suffix,
        completion=completion,
        benchmark=benchmark,
        completion_file_path=completion_file_path,
        writable_data=writable_data,
    )


def run_openaicodex_chunk(
    container_name: str,
    prompt: str,
    work_dir: Path,
    max_turns: int,
    model_name: str | None = None,
    system_prompt: str | None = None,
    resume_identifier: str | None = None,
    fork: bool = False,
    timeout: int = EVAL_TIMEOUT,
    llm_connection: GatewayConnection | None = None,
) -> CliChunkResult:
    """One Codex turn in an already running container.

    With ``resume_identifier`` the chunk continues the thread through
    ``codex exec resume <thread_id>``. Codex has no turn cap or system-prompt
    flag; both arguments are accepted for parity with the other chunk runners
    and ignored.
    """
    return _run_cli_chunk(
        agent_type="openaicodex",
        cli_command=["codex", "exec"],
        container_name=container_name,
        prompt=prompt,
        work_dir=work_dir,
        max_turns=max_turns,
        model_name=model_name,
        model_map=MODEL_MAP,
        system_prompt=system_prompt,
        resume_identifier=resume_identifier,
        fork=fork,
        timeout=timeout,
        llm_connection=llm_connection,
    )
