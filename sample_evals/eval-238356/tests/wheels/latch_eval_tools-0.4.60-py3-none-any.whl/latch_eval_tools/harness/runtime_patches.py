"""Custom Grok model configuration shared by workflow and sandbox runners."""

# grok's built-in model list lags xAI's releases; a custom model block names the slug
# directly. [telemetry]/[harness] are client-side switches that keep eval content from
# being uploaded to xAI.
def grok_custom_model_config_toml(slug: str, system_prompt_label: str) -> str:
    return f"""\
[models]
default = "{slug}"

[model."{slug}"]
api_backend = "responses"
base_url = "https://api.x.ai/v1"
context_window = 500_000
reasoning_effort = "high"
supports_reasoning_effort = true
env_key = "XAI_API_KEY"
model = "{slug}"
name = "{slug}"
description = "SpaceXAI's new frontier model"
system_prompt_label = "{system_prompt_label}"

[telemetry]
trace_upload = false

[harness]
disable_codebase_upload = true
"""


GROK_CUSTOM_MODEL_CONFIG_TOMLS = {
    "xai/grok-rc-lb": grok_custom_model_config_toml("grok-rc-lb", "Grok 4.7"),
    "xai/grok-4.7": grok_custom_model_config_toml("grok-4.7", "Grok 4.7"),
}
