"""Explicit gateway connections for CLI and Python harnesses.

The caller chooses an authorized virtual key. Provider/account selection and
capacity fallback remain gateway configuration; this module adapts wire formats.
"""

from __future__ import annotations

import json
from typing import Any

from latch_eval_tools._rubric.gateway import (
    GatewayConnection as _GatewayConnection,
    request_reasoning_headers as request_reasoning_headers,
    session_id as session_id,
    split_model as split_model,
    wire_model as wire_model,
)
from latch_eval_tools.harness.versions import PI_VERSION_PATTERN, PI_VERSION_RANGE


DEEPSEEK_V4_1_FLASH_MODELS = frozenset(
    {
        "openrouter/deepseek/deepseek-v4.1-flash",
        "openrouter/deepseek-v4p1-flash",
        "modal/deepseek-v4p1-flash",
        "modal/deepseek-ai/DeepSeek-V4.1-Flash",
    }
)


class GatewayConnection(_GatewayConnection):
    """Gateway connection with CLI harness adapters."""

    def environment(self) -> dict[str, str]:
        # Native SDK variables keep credential switching on refusal functional.
        return {
            "BIFROST_API_KEY": self.api_key,
            "ANTHROPIC_API_KEY": self.api_key,
            "ANTHROPIC_BASE_URL": self.endpoint("anthropic-messages"),
            "ANTHROPIC_CUSTOM_HEADERS": "\n".join(
                f"{k}: {v}" for k, v in self.headers.items()
            ),
            "OPENAI_API_KEY": self.api_key,
            "CODEX_API_KEY": self.api_key,
            "OPENAI_BASE_URL": self.endpoint("openai-responses"),
            "XAI_API_KEY": self.api_key,
            "GEMINI_API_KEY": self.api_key,
            "GOOGLE_GEMINI_BASE_URL": self.base_url.rstrip("/") + "/genai",
        }

    def codex_args(self) -> list[str]:
        config: dict[str, Any] = {
            "model_provider": "latch",
            "model_providers.latch.name": "Latch gateway",
            "model_providers.latch.base_url": self.endpoint("openai-responses"),
            "model_providers.latch.wire_api": "responses",
            "model_providers.latch.env_key": "CODEX_API_KEY",
            "model_providers.latch.requires_openai_auth": False,
            **{
                f'model_providers.latch.http_headers."{k}"': v
                for k, v in self.headers.items()
            },
        }
        return [
            part
            for key, value in config.items()
            for part in ("-c", f"{key}={json.dumps(value)}")
        ]

    def grok_config(self, model: str) -> str:
        provider, slug = split_model(model)
        if provider != "xai":
            raise ValueError("Grok Build requires an xAI model")
        # Partial overrides retain the CLI's built-in model metadata. These two
        # newer models need the same explicit metadata as the existing v2 setup.
        extra = (
            'context_window = 500000\nreasoning_effort = "high"\n'
            'supports_reasoning_effort = true\nsystem_prompt_label = "Grok 4.7"\n'
            if slug in {"grok-4.7", "grok-rc-lb"}
            else ""
        )
        headers = ", ".join(
            f"{json.dumps(k)} = {json.dumps(v)}" for k, v in self.headers.items()
        )
        return (
            f"[models]\ndefault = {json.dumps(slug)}\n"
            f"[model.{json.dumps(slug)}]\n"
            f"model = {json.dumps(wire_model(model))}\n"
            f"base_url = {json.dumps(self.endpoint('openai-responses'))}\n"
            'api_backend = "responses"\nenv_key = "XAI_API_KEY"\n'
            f"extra_headers = {{ {headers} }}\n{extra}"
            "[telemetry]\ntrace_upload = false\n"
            "[harness]\ndisable_codebase_upload = true\n"
        )

    def pi_descriptor(
        self, model: str, model_config: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        provider, name = split_model(model)
        # Ember uses Pi's native Fireworks Anthropic model definition. Keep
        # that protocol through the gateway so its reasoning map stays valid.
        api = (
            "anthropic-messages"
            if provider == "anthropic"
            or model == "fireworks/accounts/fireworks/models/ember-1"
            else "openai-responses"
            # Meta's Model API only carries reasoning across turns on Responses.
            if provider in {"openai", "xai", "meta"}
            else "openai-completions"
        )
        headers = self.headers
        if model in DEEPSEEK_V4_1_FLASH_MODELS:
            headers = headers | {
                "x-bf-session-affinity": "off",
                "x-bf-eh-Modal-Session-Id": self.session_id,
            }
        return {
            "sourceProvider": "google" if provider == "gemini" else provider,
            "sourceModel": name,
            "wireModel": self.wire_model(model),
            "model": model_config,
            "provider": {
                "baseUrl": self.endpoint(api),
                # Anthropic refusal retries replace this env var inside the container.
                "apiKey": "$ANTHROPIC_API_KEY"
                if api == "anthropic-messages"
                else "$BIFROST_API_KEY",
                "api": api,
                "headers": headers,
            },
        }


# Both gateway and direct-provider launches validate the installed CLI before use.
PI_RUNTIME_VALIDATION_SCRIPT = r"""
import {readFileSync, realpathSync, writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const cli = process.argv[1];
const packageUrl = import.meta.resolve(
    '@earendil-works/pi-coding-agent', pathToFileURL(realpathSync(cli)).href
);
const {version} = JSON.parse(readFileSync(new URL('../package.json', packageUrl), 'utf8'));
const supportedRange = __PI_VERSION_RANGE__;
const match = new RegExp('^(?:' + __PI_VERSION_PATTERN__ + ')$').exec(version);
if (match === null || Number(match[1]) < 3 || Number(match[1]) >= 5) throw new Error(`This runner requires a stable Pi version ${supportedRange}; found ${version}`);
const aiUrl = import.meta.resolve('@earendil-works/pi-ai', packageUrl);
const aiVersion = JSON.parse(readFileSync(new URL('../package.json', aiUrl), 'utf8')).version;
if (aiVersion !== version) throw new Error(`Pi ${version} requires pi-ai ${version}; found ${aiVersion}`);
""".replace("__PI_VERSION_RANGE__", json.dumps(PI_VERSION_RANGE)).replace(
    "__PI_VERSION_PATTERN__", json.dumps(PI_VERSION_PATTERN)
)

# Resolve metadata from the installed Pi without persisted credentials or model network I/O.
PI_GATEWAY_CONFIG_SCRIPT = (
    PI_RUNTIME_VALIDATION_SCRIPT
    + r"""
const [descriptorPath, outputPath] = process.argv.slice(2);
const descriptor = JSON.parse(readFileSync(descriptorPath, 'utf8'));
let source = descriptor.model;
if (source == null) {
    const pi = await import(packageUrl);
    const {InMemoryCredentialStore} = await import(aiUrl);
    const modelRuntime = await pi.ModelRuntime.create({
        credentials: new InMemoryCredentialStore(), modelsPath: null,
        allowModelNetwork: false, refreshOnCreate: false,
    });
    const resolved = pi.resolveCliModel({
        cliProvider: descriptor.sourceProvider,
        cliModel: descriptor.sourceModel,
        modelRuntime,
    });
    if (!resolved.model) throw new Error(resolved.error ?? 'Pi could not resolve model metadata');
    source = resolved.model;
}
const model = {...source, id: descriptor.wireModel, api: descriptor.provider.api};
delete model.provider;
delete model.baseUrl;
if (descriptor.provider.api === 'openai-completions') {
    model.compat = {...model.compat, thinkingFormat: 'openai', supportsUsageInStreaming: true};
    delete model.compat.openRouterRouting;
}
if (descriptor.provider.api === 'openai-responses') {
    // The gateway rejects configuration_update input items (400 missing
    // input[N].reasoning); send effort as top-level reasoning.effort instead.
    model.compat = {...model.compat, supportsMidConvoEffort: false};
}
writeFileSync(outputPath, JSON.stringify({providers: {latch: {...descriptor.provider, models: [model]}}}));
"""
)
