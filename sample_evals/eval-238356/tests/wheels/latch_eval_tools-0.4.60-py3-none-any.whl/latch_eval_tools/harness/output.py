"""Compatibility answer reader for harness callers without an output contract."""

import json
import stat
from pathlib import Path
from typing import Any

from latch_eval_tools.harness.utils import find_answer_file, find_finished_file


def read_legacy_answer(
    agent_dir: Path, *, completion: bool, last_message: str
) -> tuple[Any, dict[str, Any] | None]:
    answer_file = None if completion else find_answer_file(agent_dir)
    path = answer_file if answer_file is not None else find_finished_file(agent_dir)
    if path is None:
        return None, {
            "error": "Agent did not create finished.txt"
            if completion
            else "no final answer provided (either eval_answer.json or finished.txt)",
            "error_code": "output_contract_failed",
        }
    try:
        if not stat.S_ISREG(path.stat().st_mode):
            raise ValueError("answer is not a regular file")
        contents = path.read_text(encoding="utf-8")
        answer = (
            json.loads(contents)
            if answer_file is not None
            else {"last_message": last_message, "finished_file_contents": contents}
        )
    except (ValueError, FileNotFoundError, PermissionError, NotADirectoryError) as exc:
        return None, {
            "error": f"Invalid answer file {path.name}: {exc}",
            "error_code": "output_contract_failed",
        }
    except OSError as exc:
        return None, {
            "error": f"Unable to read answer file {path.name}: {exc}",
            "error_code": "harness_execution_failed",
        }
    return answer, None
