import hashlib
import json
import os
import shutil
from importlib.resources import files
from pathlib import Path

from jinja2 import DebugUndefined, Environment
from latch.ldata.path import LPath
import subprocess

DEFAULT_DOCKER_IMAGE = "public.ecr.aws/p5z7v3z8/benchmark_agent:latest"
GIBIBYTE = 1024**3
MEMORY_HEADROOM_BYTES = 2 * GIBIBYTE
MIN_MEMORY_LIMIT_BYTES = 128 * 1024**2
AGENT_WORKSPACE_DIR_NAME = "agent_workspace"
CGROUP_MEMORY_LIMIT_PATHS = (
    Path("/sys/fs/cgroup/memory.max"),
    Path("/sys/fs/cgroup/memory/memory.limit_in_bytes"),
)
PROMPT_TEMPLATE_ENVIRONMENT = Environment(
    autoescape=False,
    keep_trailing_newline=True,
    undefined=DebugUndefined,
)



def ensure_docker_image(image: str) -> None:
    result = subprocess.run(
        ["docker", "image", "inspect", image],
        capture_output=True,
    )
    if result.returncode == 0:
        return
    print(f"Pulling Docker image {image} ...")
    subprocess.run(
        ["docker", "pull", image],
        check=True,
    )
    print(f"Docker image {image} pulled successfully")


def load_trajectory_identifier(trajectory_path: Path, key: str) -> str | None:
    if not trajectory_path.exists():
        print("No trajectory.json file found")
        return None

    try:
        trajectory = json.loads(trajectory_path.read_text())
    except json.JSONDecodeError as exc:
        print(f"Failed to parse trajectory.json: {exc}")
        return None

    if not trajectory:
        print("No trajectory events found")
        return None

    if not isinstance(trajectory, list):
        print("Unexpected trajectory format in trajectory.json")
        return None

    for event in trajectory:
        if not isinstance(event, dict):
            continue
        identifier = event.get(key)
        if identifier:
            return str(identifier)

    print(f"No {key} found in trajectory.json")
    return None


def get_memory_limit_bytes(headroom_bytes: int = MEMORY_HEADROOM_BYTES) -> int:
    host_total_bytes = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    cgroup_limit_bytes: int | None = None
    for path in CGROUP_MEMORY_LIMIT_PATHS:
        try:
            raw_value = path.read_text().strip()
        except OSError:
            continue

        if not raw_value or raw_value == "max":
            continue

        try:
            limit_bytes = int(raw_value)
        except ValueError:
            continue

        if limit_bytes > 0:
            cgroup_limit_bytes = limit_bytes
            break

    memory_ceiling_bytes = host_total_bytes
    if cgroup_limit_bytes is not None:
        memory_ceiling_bytes = min(memory_ceiling_bytes, cgroup_limit_bytes)

    limit_bytes = memory_ceiling_bytes - headroom_bytes
    if limit_bytes > 0:
        return limit_bytes

    if memory_ceiling_bytes <= MIN_MEMORY_LIMIT_BYTES:
        return memory_ceiling_bytes

    return max(memory_ceiling_bytes - MIN_MEMORY_LIMIT_BYTES, MIN_MEMORY_LIMIT_BYTES)


def render_packaged_prompt(filename: str, **template_values: object) -> str:
    template = PROMPT_TEMPLATE_ENVIRONMENT.from_string(
        read_packaged_prompt(filename)
    )
    return template.render(
        **{key: str(value) for key, value in template_values.items()}
    )


def prompt_with_suffix(task_prompt: str, prompt_suffix: str | None = None) -> str:
    if prompt_suffix in (None, ""):
        return task_prompt
    return f"{task_prompt}\n{prompt_suffix}"


# Answer-protocol conventions. Legacy names are the default; the neutral
# benchmark names are used only when a run is launched with benchmark=True.
# Readers accept both so old trajectories and mixed-version deploys keep
# working regardless of which convention the prompt used.
LEGACY_COMPLETION_MARKER = "COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT"
BENCHMARK_COMPLETION_MARKER = "RUN_COMPLETE"
COMPLETION_MARKERS = frozenset(
    {LEGACY_COMPLETION_MARKER, BENCHMARK_COMPLETION_MARKER}
)

LEGACY_ANSWER_FILENAME = "eval_answer.json"
BENCHMARK_ANSWER_FILENAME = "analysis_output.json"
ANSWER_FILENAMES = (BENCHMARK_ANSWER_FILENAME, LEGACY_ANSWER_FILENAME)


def find_answer_file(agent_dir: Path) -> Path | None:
    for name in ANSWER_FILENAMES:
        candidate = agent_dir / name
        if candidate.exists():
            return candidate
    return None


def benchmark_convention(text: str) -> str:
    """Rewrite legacy answer-protocol names in prompt text to the neutral
    benchmark names."""
    return text.replace(
        LEGACY_COMPLETION_MARKER, BENCHMARK_COMPLETION_MARKER
    ).replace(LEGACY_ANSWER_FILENAME, BENCHMARK_ANSWER_FILENAME)


def _inspect_docker_container_state(
    container_name: str,
    state_field: str,
    docker_executable: str = "docker",
) -> str | None:
    result = subprocess.run(
        [
            docker_executable,
            "inspect",
            "--format",
            f"{{{{.State.{state_field}}}}}",
            container_name,
        ],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    return result.stdout.strip()


def is_docker_container_running(
    container_name: str,
    docker_executable: str = "docker",
) -> bool:
    state = _inspect_docker_container_state(
        container_name,
        "Running",
        docker_executable=docker_executable,
    )
    return state == "true"


def is_docker_container_oom_killed(
    container_name: str,
    docker_executable: str = "docker",
) -> bool:
    state = _inspect_docker_container_state(
        container_name,
        "OOMKilled",
        docker_executable=docker_executable,
    )
    return state == "true"


def get_project_root():
    """Find project root by looking for pyproject.toml."""
    current = Path(__file__).resolve()
    while current != current.parent:
        if (current / "pyproject.toml").exists():
            return current
        current = current.parent
    return Path.cwd()


def get_cache_dir(cache_name: str = ".eval_cache"):
    """Get cache directory for datasets.
    
    Args:
        cache_name: Name of cache directory (default: .eval_cache)
                   Can be customized per benchmark (e.g., .scbench, .spatialbench)
    """
    project_root = get_project_root()
    cache_dir = project_root / cache_name / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_cache_manifest(cache_name: str = ".eval_cache"):
    """Load cache manifest tracking downloaded datasets."""
    cache_dir = get_cache_dir(cache_name)
    manifest_file = cache_dir / "manifest.json"

    if manifest_file.exists():
        return json.loads(manifest_file.read_text())
    return {}


def save_cache_manifest(manifest: dict, cache_name: str = ".eval_cache"):
    """Save cache manifest."""
    cache_dir = get_cache_dir(cache_name)
    manifest_file = cache_dir / "manifest.json"
    manifest_file.write_text(json.dumps(manifest, indent=2))


def get_cache_key(uri: str) -> str:
    """Generate cache key from URI."""
    uri_hash = hashlib.sha256(uri.encode()).hexdigest()[:16]
    filename = LPath(uri).name() or Path(uri).name or "data"
    return f"{uri_hash}__{filename}"


def _files_in_cached_dataset(path: Path) -> list[Path]:
    if path.is_dir():
        return sorted(p for p in path.rglob("*") if p.is_file())
    return [path]


def download_single_dataset(uri: str, show_progress: bool = True, cache_name: str = ".eval_cache") -> Path:
    """Download a single dataset with caching.
    
    Args:
        uri: URI of dataset to download (e.g., latch://...)
        show_progress: Whether to print progress messages
        cache_name: Name of cache directory
    
    Returns:
        Path to cached file or directory.
    """
    cache_dir = get_cache_dir(cache_name)
    manifest = get_cache_manifest(cache_name)

    if uri in manifest:
        cached_file = cache_dir / manifest[uri]
        if cached_file.exists():
            if show_progress:
                print(f"Using cached: {Path(uri).name}")
            return cached_file

    remote_name = LPath(uri).name() or Path(uri).name or "data"
    cache_key = hashlib.sha256(uri.encode()).hexdigest()[:16]
    cache_rel_path = str(Path(cache_key) / remote_name)
    cached_file = cache_dir / cache_rel_path

    if show_progress:
        print(f"Downloading: {uri}")
    cached_file.parent.mkdir(parents=True, exist_ok=True)
    LPath(uri).download(dst=cached_file, cache=True)
    if show_progress:
        print(f"Cached as: {cache_rel_path}")

    manifest[uri] = cache_rel_path
    save_cache_manifest(manifest, cache_name)

    return cached_file


def get_agent_workspace_dir(work_dir: Path) -> Path:
    """Return the host directory mounted as /workspace for container agents."""
    agent_dir = work_dir / AGENT_WORKSPACE_DIR_NAME
    agent_dir.mkdir(parents=True, exist_ok=True)
    return agent_dir


def find_finished_file(agent_dir: Path) -> Path | None:
    """Locate the agent's ``finished.txt`` completion marker.

    The marker is expected at the workspace root (``/workspace/finished.txt``),
    but agents working inside a project subdirectory sometimes write it relative
    to their cwd (e.g. ``/workspace/<repo>/finished.txt``). Prefer the root, then
    fall back to the first match anywhere under the workspace so a stray-cwd write
    is still honoured. The read-only ``data`` mount is skipped to avoid treating a
    dataset file of the same name as the agent's marker. Returns ``None`` when no
    marker exists. Never raises.
    """
    root = agent_dir / "finished.txt"
    if root.exists():
        return root
    data_dir = agent_dir / "data"
    try:
        candidates = sorted(agent_dir.rglob("finished.txt"))
    except OSError:
        return None
    for candidate in candidates:
        try:
            candidate.relative_to(data_dir)
        except ValueError:
            return candidate
    return None


def get_agent_workspace_mount_args(
    agent_dir: Path, *, writable_data: bool = False
) -> list[str]:
    """Return Docker bind mounts for the agent workspace.

    The workspace stays writable for outputs, while staged input data is mounted
    read-only to prevent agent-side writes from mutating hardlinked cache files.
    ``writable_data`` is for a caller that has replaced ``data/`` with private
    copies: it stays part of the writable workspace mount.
    """
    data_dir = agent_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    if writable_data:
        return ["-v", f"{agent_dir}:/workspace"]
    return [
        "-v",
        f"{agent_dir}:/workspace",
        "-v",
        f"{data_dir}:/workspace/data:ro",
    ]


def download_data(data_node: str | list[str], work_dir: Path, cache_name: str = ".eval_cache") -> list[dict]:
    """Download data files into the workspace data directory.
    
    Args:
        data_node: Single URI or list of URIs to download
        work_dir: Working directory to stage data files in
        cache_name: Name of cache directory
    
    Returns:
        List of contextual data dicts with file info
    """
    data_nodes = data_node if isinstance(data_node, list) else ([data_node] if data_node else [])
    agent_dir = get_agent_workspace_dir(work_dir)
    data_dir = agent_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    contextual_data = []

    for node in data_nodes:
        cached_dataset = download_single_dataset(node, cache_name=cache_name)
        cached_files = _files_in_cached_dataset(cached_dataset)
        data_filename = LPath(node).name() or Path(node).name or "data"
        target_root = data_dir / data_filename
        if target_root.is_symlink() or target_root.is_file():
            target_root.unlink()
        elif target_root.is_dir():
            shutil.rmtree(target_root)

        for cached_file in cached_files:
            if cached_dataset.is_dir():
                mount_path = Path(data_filename) / cached_file.relative_to(cached_dataset)
            else:
                mount_path = Path(data_filename)

            target_file = data_dir / mount_path
            target_file.parent.mkdir(parents=True, exist_ok=True)
            if target_file.is_symlink() or target_file.is_file():
                target_file.unlink()
            elif target_file.is_dir():
                shutil.rmtree(target_file)
            target_file.hardlink_to(cached_file)
            print(f"Linked: {mount_path} -> workspace/data")

            contextual_data.append({
                "type": "File",
                "local_path": f"data/{mount_path}",
            })

    return contextual_data

def batch_download_datasets(uris: list[str], show_progress: bool = True, cache_name: str = ".eval_cache"):
    """Download multiple datasets in batch.
    
    Args:
        uris: List of URIs to download
        show_progress: Whether to print progress messages
        cache_name: Name of cache directory
    """
    if show_progress and uris:
        print(f"Preparing to download {len(uris)} unique dataset(s)...")
        print("=" * 80)

    for i, uri in enumerate(uris, 1):
        if show_progress:
            print(f"[{i}/{len(uris)}] ", end="")
        download_single_dataset(uri, show_progress=show_progress, cache_name=cache_name)

    if show_progress and uris:
        print("=" * 80)
        print(f"Downloaded/verified {len(uris)} dataset(s)")
        print()


def setup_workspace(eval_id: str, run_id: str | None = None, workspace_name: str = ".eval_workspace") -> Path:
    """Setup workspace directory for evaluation.
    
    Args:
        eval_id: ID of evaluation
        run_id: Optional run ID for organizing multiple runs
        workspace_name: Name of workspace directory (default: .eval_workspace)
                       Can be customized per benchmark (e.g., .scbench, .spatialbench)
    
    Returns:
        Path to workspace directory
    """
    project_root = get_project_root()
    if run_id:
        work_dir = project_root / workspace_name / "workspace" / run_id / eval_id
    else:
        work_dir = project_root / workspace_name / "workspace" / eval_id

    if work_dir.exists():
        import shutil
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)

    return work_dir


def cleanup_workspace(work_dir: Path, keep: bool = False):
    """Clean up workspace directory.
    
    Args:
        work_dir: Workspace directory to clean up
        keep: Whether to keep the workspace
    """
    if keep:
        print(f"Workspace preserved at: {work_dir}")
    else:
        import shutil
        shutil.rmtree(work_dir)
        print(f"Workspace deleted: {work_dir}")



def load_data_instructions() -> str:
    return read_packaged_prompt("data_instructions.md")


def read_packaged_prompt(filename: str) -> str:
    return files("latch_eval_tools").joinpath("prompts", filename).read_text(encoding="utf-8")
