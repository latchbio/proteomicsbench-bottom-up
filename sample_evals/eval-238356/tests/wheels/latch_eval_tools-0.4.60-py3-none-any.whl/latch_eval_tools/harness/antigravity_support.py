"""Resolved Antigravity CLI installation and native transcript adaptation."""

import json
import shlex
from pathlib import Path
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from latch_eval_tools.harness.antigravity_versions import AntigravityRelease

ANTIGRAVITY_ARTIFACT_DIR = "antigravity"


def antigravity_install_script(
    release: AntigravityRelease, bin_dir: str = "/usr/local/bin"
) -> str:
    return f"""set -euo pipefail
test "$(uname -m)" = x86_64
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
curl --fail --silent --show-error --location --retry 3 {shlex.quote(release.url)} -o "$tmp/cli.tar.gz"
printf '%s  %s\\n' {shlex.quote(release.sha512)} "$tmp/cli.tar.gz" | sha512sum --check --status
tar -xzf "$tmp/cli.tar.gz" -C "$tmp" antigravity
mkdir -p {shlex.quote(bin_dir)}
install -m 755 "$tmp/antigravity" {shlex.quote(bin_dir + "/agy")}
test "$({shlex.quote(bin_dir + "/agy")} --version)" = {shlex.quote(release.resolved_version)}
"""


class AntigravityUsage(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    thinking_tokens: int | None = Field(default=None, ge=0)
    cache_read_tokens: int | None = Field(default=None, ge=0)

    def canonical(self) -> dict[str, int]:
        # Output already includes thinking. Input excludes cache reads; neither
        # cache reads nor thinking should be added to another reported counter.
        return {
            "reasoning_tokens" if key == "thinking_tokens" else key: value
            for key, value in self.model_dump(exclude_none=True).items()
        }

    def trajectory(self) -> dict[str, Any]:
        # Agent-event consumers recognize additive cache reads and thinking
        # details using these API field names. Run summaries use canonical().
        usage: dict[str, Any] = {}
        if self.input_tokens is not None:
            usage["input_tokens"] = self.input_tokens
        if self.output_tokens is not None:
            usage["output_tokens"] = self.output_tokens
        if self.cache_read_tokens is not None:
            usage["cache_read_input_tokens"] = self.cache_read_tokens
        if self.thinking_tokens is not None:
            usage["output_tokens_details"] = {"thinking_tokens": self.thinking_tokens}
        return usage


class AntigravityToolCall(BaseModel):
    model_config = ConfigDict(extra="allow", strict=True)

    name: str
    args: dict[str, Any]


class AntigravityStep(AntigravityUsage):
    model_config = ConfigDict(extra="allow", strict=True)

    step_index: int = Field(ge=0)
    type: str
    status: str
    created_at: str
    content: str = ""
    tool_calls: list[AntigravityToolCall] = Field(default_factory=list)


def antigravity_result(events: list[dict[str, Any]]) -> dict[str, Any] | None:
    for event in reversed(events):
        if event.get("event") == "result" and isinstance(event.get("result"), dict):
            return event["result"]
        if event.get("event") in {"init", "step_update"}:
            return None
    return None


def antigravity_steps(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Latest snapshot per step; stream updates are cumulative, not deltas."""
    steps: dict[tuple[str, int], dict[str, Any]] = {}
    for event in events:
        step = event.get("step_update")
        if event.get("event") != "step_update" or not isinstance(step, dict):
            continue
        conversation = step.get("conversation_id")
        index = step.get("step_index")
        if isinstance(conversation, str) and type(index) is int:
            steps[conversation, index] = step
    return list(steps.values())


def antigravity_usage(events: list[dict[str, Any]]) -> dict[str, int]:
    # A resumed conversation's result is cumulative. Keep only its last result.
    results: dict[str, dict[str, Any]] = {}
    covered_steps: set[tuple[str, int]] = set()
    seen_steps: set[tuple[str, int]] = set()
    for event in events:
        for step in antigravity_steps([event]):
            seen_steps.add((step["conversation_id"], step["step_index"]))
        result = antigravity_result([event])
        if result is not None and isinstance(result.get("conversation_id"), str):
            results[result["conversation_id"]] = result
            covered_steps.update(
                key for key in seen_steps if key[0] == result["conversation_id"]
            )
    usage: dict[str, int] = {}
    for result in results.values():
        raw = result.get("usage")
        if isinstance(raw, dict):
            for key, count in AntigravityUsage.model_validate(raw).canonical().items():
                usage[key] = usage.get(key, 0) + count
    # Interrupted streams have no final envelope. Their step usage is still useful.
    for step in antigravity_steps(events):
        if (step["conversation_id"], step["step_index"]) in covered_steps:
            continue
        raw = step.get("usage")
        if isinstance(raw, dict):
            for key, count in AntigravityUsage.model_validate(raw).canonical().items():
                usage[key] = usage.get(key, 0) + count
    return usage


def normalize_antigravity_transcript(
    steps: list[AntigravityStep], conversation_id: str
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    pending_tool_id: str | None = None
    for step in steps:
        content: list[dict[str, Any]] = []
        if step.type == "PLANNER_RESPONSE":
            role = "assistant"
            if step.content:
                content.append({"type": "text", "text": step.content})
            pending_tool_id = None
            for index, call in enumerate(step.tool_calls):
                tool_id = f"agy-{conversation_id}-{step.step_index}-{index}"
                content.append(
                    {
                        "type": "tool_use",
                        "id": tool_id,
                        "name": call.name,
                        "input": call.args,
                    }
                )
                if len(step.tool_calls) == 1:
                    pending_tool_id = tool_id
        elif step.type == "GENERIC":
            role = "tool_result"
            block: dict[str, Any] = {
                "type": "tool_result",
                "content": step.content,
                "is_error": step.status in {"ERROR", "FAILED"},
            }
            # Native full transcripts have no call IDs. Only associate an
            # unambiguous single call; preserve parallel results without guessing.
            if pending_tool_id is not None:
                block["tool_use_id"] = pending_tool_id
            pending_tool_id = None
            content.append(block)
        else:
            role = "user" if step.type == "USER_INPUT" else "system"
            content.append(
                {
                    "type": "text",
                    "text": step.content
                    or json.dumps(step.model_dump(exclude_none=True)),
                }
            )
        event: dict[str, Any] = {
            "type": role,
            "timestamp": step.created_at,
            "content": content,
            "conversation_id": conversation_id,
            "step_index": step.step_index,
            "native_type": step.type,
            "native_status": step.status,
        }
        if step.type == "PLANNER_RESPONSE":
            event["usage"] = AntigravityUsage.model_validate(
                step.model_dump()
            ).trajectory()
        result.append(event)
    return result


def collect_antigravity_trajectory(
    work_dir: Path, events: list[dict[str, Any]], *, final: bool = False
) -> list[dict[str, Any]]:
    """Read full payloads from the run's isolated HOME, including after failure.

    Stream events remain authoritative for terminal status and usage. The full
    transcript supplies tool payloads omitted by stream-json. An incomplete last
    JSONL line is tolerated only during live snapshots.
    """
    conversations: list[str] = []
    for event in events:
        value = event.get("conversation_id")
        if isinstance(value, str) and value and value not in conversations:
            conversations.append(str(UUID(value)))
    artifact_dir = work_dir / ANTIGRAVITY_ARTIFACT_DIR
    artifact_dir.mkdir(exist_ok=True)
    (artifact_dir / "events.jsonl").write_text(
        "".join(json.dumps(event) + "\n" for event in events)
    )
    state_root = (work_dir / ".gemini").resolve()
    terminal = antigravity_result(events)
    require_transcript = (
        final and terminal is not None and terminal.get("status") == "SUCCESS"
    )
    if require_transcript and not conversations:
        raise ValueError("Successful Antigravity run has no conversation identifier")
    trajectory: list[dict[str, Any]] = []
    for conversation in conversations:
        source = (
            state_root
            / "antigravity-cli/brain"
            / conversation
            / ".system_generated/logs/transcript_full.jsonl"
        )
        if not source.resolve().is_relative_to(state_root):
            raise ValueError("Antigravity transcript escapes its state directory")
        if not source.is_file():
            if require_transcript:
                raise ValueError(
                    f"Missing Antigravity full transcript for {conversation}"
                )
            continue
        raw = source.read_text()
        lines = raw.splitlines()
        steps = []
        for index, line in enumerate(lines):
            try:
                steps.append(AntigravityStep.model_validate_json(line))
            except ValueError:
                if final or index != len(lines) - 1 or raw.endswith("\n"):
                    raise
        destination = artifact_dir / conversation
        destination.mkdir(exist_ok=True)
        (destination / "transcript_full.jsonl").write_text(raw)
        normalized = normalize_antigravity_transcript(steps, conversation)
        snapshots = {
            step["step_index"]: step
            for step in antigravity_steps(events)
            if step["conversation_id"] == conversation
        }
        for event in normalized:
            snapshot = snapshots.get(event["step_index"], {})
            usage = snapshot.get("usage")
            if event["type"] == "assistant" and isinstance(usage, dict):
                event["usage"] = AntigravityUsage.model_validate(usage).trajectory()
        trajectory.extend(normalized)
    # Keep native init/result metadata alongside the normalized content. This
    # preserves the session identifier for OOM resume and terminal diagnostics.
    trajectory.extend(
        {
            **event,
            "type": "system" if event["event"] == "init" else "result",
            "content": [],
        }
        for event in events
        if event.get("event") in {"init", "result"}
    )
    return trajectory
