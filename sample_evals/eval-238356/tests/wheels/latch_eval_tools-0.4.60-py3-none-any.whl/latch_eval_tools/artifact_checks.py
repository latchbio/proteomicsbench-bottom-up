"""Standard-library-only API for author-written artifact checks.

Authors import ``CheckResult`` and ``SubmissionError`` from ``artifact_checks``.
The platform executes this file as a worker; authors never need an entrypoint.
"""

from __future__ import annotations

import importlib.util
import json
import sys
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class CheckContext:
    submission_dir: Path
    reference_file: Path | None
    scratch_dir: Path
    artifacts: dict[str, Path] = field(default_factory=dict)


@dataclass(frozen=True)
class CheckResult:
    passed: bool
    message: str = ""
    metrics: dict[str, Any] = field(default_factory=dict)


class SubmissionError(ValueError):
    """An expected problem with the submitted artifact (a failed check, not a broken grader)."""


def _validated_result(value: Any) -> CheckResult:
    if not isinstance(value, CheckResult):
        raise TypeError("check must return CheckResult")
    if (
        type(value.passed) is not bool
        or not isinstance(value.message, str)
        or not isinstance(value.metrics, dict)
    ):
        raise TypeError(
            "CheckResult requires a boolean passed, string message and object metrics"
        )
    json.dumps(value.metrics, allow_nan=False)
    return value


def execute_checks(request: dict[str, Any]) -> dict[str, Any]:
    """Load one module and call only the check functions enumerated in eval.json."""
    checks = request["checks"]
    records: list[dict[str, Any]] = []
    try:
        spec = importlib.util.spec_from_file_location(
            "submitted_artifact_grader", request["script"]
        )
        if spec is None or spec.loader is None:
            raise ValueError("could not load grader script")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        import_error = None
    except BaseException as exc:  # noqa: BLE001 - author SystemExit must become a grader error too
        traceback.print_exc()
        module = None
        import_error = f"could not load grader: {type(exc).__name__}: {exc}"

    for check in checks:
        record = {"id": check["id"], "title": check["title"]}
        try:
            if import_error is not None:
                raise RuntimeError(import_error)
            function = getattr(module, check["id"], None)
            if not callable(function):
                raise TypeError(f"script does not define callable {check['id']}")
            scratch = Path(request["scratch_dir"]) / check["id"]
            scratch.mkdir(parents=True, exist_ok=True)
            reference = request["references"].get(check["id"])
            result = _validated_result(
                function(
                    CheckContext(
                        submission_dir=Path(request["submission_dir"]),
                        reference_file=Path(reference)
                        if reference is not None
                        else None,
                        scratch_dir=scratch,
                        artifacts={
                            name: Path(path)
                            for name, path in request.get("artifacts", {}).items()
                        },
                    )
                )
            )
            record.update(
                status="pass" if result.passed else "fail",
                passed=result.passed,
                message=result.message,
                metrics=result.metrics,
            )
        except SubmissionError as exc:
            record.update(status="fail", passed=False, message=str(exc), metrics={})
        except BaseException as exc:  # noqa: BLE001 - isolate errors in author functions
            traceback.print_exc()
            record.update(
                status="error",
                passed=None,
                message=f"{type(exc).__name__}: {exc}",
                metrics={},
            )
        records.append(record)

    errors = [record for record in records if record["status"] == "error"]
    passed_count = sum(record["status"] == "pass" for record in records)
    metrics: dict[str, Any] = {
        "type": "artifact",
        "checks": records,
        "input_manifest": request["input_manifest"],
        "passed_checks": passed_count,
        "total_checks": len(checks),
    }
    if errors:
        metrics.update(
            grader_system_error=True, grader_error="One or more artifact checks errored"
        )
    return {
        "passed": not errors and passed_count == len(checks),
        "score": 0.0 if errors else passed_count / len(checks),
        "raw_score": 0.0 if errors else float(passed_count),
        "score_max": float(len(checks)),
        "metrics": metrics,
        "reasoning": "\n".join(
            f"{r['title']}: {r['status']} — {r['message']}" for r in records
        ),
        "agent_answer": None,
        "field_scores": {r["id"]: float(r["status"] == "pass") for r in records},
    }


if __name__ == "__main__":
    # Both the worker and author module must see the same CheckResult class.
    sys.modules["artifact_checks"] = sys.modules[__name__]
    payload = execute_checks(json.loads(Path(sys.argv[1]).read_text()))
    Path(sys.argv[2]).write_text(json.dumps(payload, indent=2, allow_nan=False))
