"""The text of an agent-written file, for a rubric grader with `artifact`. Runs in the artifact
sandbox (agent files are untrusted input) and picks the parser from the file's bytes and name:
PDF (pypdf, from the sandbox image), Word, Jupyter notebooks, HTML, or UTF-8 text."""

import codecs
import json
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from latch_eval_tools._rubric.rubric import ARTIFACT_TEXT_MAX_CHARS

# Notebooks, HTML and Word XML are parsed whole; larger ones are refused instead.
MAX_PARSE_BYTES = 64 * 1024 * 1024
READ_CHUNK_BYTES = 1024 * 1024
WORD_NAMESPACE = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
HTML_SKIPPED_TAGS = {"script", "style"}
HTML_BLOCK_TAGS = {"br", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "p", "pre", "tr"}


class ArtifactTextUnavailable(ValueError):
    """The file has no text to judge: an unsupported or unreadable format, or no text at all."""


def extract_text(path: Path, max_chars: int = ARTIFACT_TEXT_MAX_CHARS) -> dict[str, Any]:
    """`{"text", "format", "truncated"}`: the first `max_chars` characters of the file's text."""
    with path.open("rb") as stream:
        head = stream.read(8)
    suffix = path.suffix.lower()
    if head.startswith(b"%PDF-"):
        fmt, text = "pdf", _pdf_text(path, max_chars)
    elif head.startswith(b"PK\x03\x04"):
        fmt, text = "docx", _docx_text(path)
    elif suffix == ".ipynb":
        fmt, text = "ipynb", _notebook_text(_whole_text(path))
    elif suffix in {".html", ".htm"}:
        fmt, text = "html", _html_text(_whole_text(path))
    else:
        fmt, text = "text", _utf8(path, max_chars + 1)
    if not text.strip():
        raise ArtifactTextUnavailable("it contains no text")
    return {"text": text[:max_chars], "format": fmt, "truncated": len(text) > max_chars}


def _utf8(path: Path, limit: int) -> str:
    """At most `limit` characters of a UTF-8 file, read incrementally."""
    decoder = codecs.getincrementaldecoder("utf-8-sig")()
    parts: list[str] = []
    kept = 0
    with path.open("rb") as stream:
        while kept < limit:
            chunk = stream.read(READ_CHUNK_BYTES)
            try:
                text = decoder.decode(chunk, final=not chunk)
            except UnicodeDecodeError as error:
                raise ArtifactTextUnavailable(f"it is not UTF-8 text ({error})") from error
            if "\x00" in text:
                raise ArtifactTextUnavailable("it is a binary file, not text")
            parts.append(text[: limit - kept])
            kept += len(parts[-1])
            if not chunk:
                break
    return "".join(parts)


def _whole_text(path: Path) -> str:
    if path.stat().st_size > MAX_PARSE_BYTES:
        raise ArtifactTextUnavailable("it is too large to parse")
    return _utf8(path, MAX_PARSE_BYTES)


def _pdf_text(path: Path, max_chars: int) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as error:  # the sandbox image, not the agent, is at fault
        raise RuntimeError("PDF text extraction needs pypdf in the sandbox image") from error
    pages: list[str] = []
    total = 0
    try:
        for page in PdfReader(path).pages:
            pages.append(page.extract_text() or "")
            total += len(pages[-1])
            if total > max_chars:
                break
    except Exception as error:  # noqa: BLE001 - any parser failure means an unreadable PDF
        raise ArtifactTextUnavailable(f"it is not a readable PDF ({error})") from error
    return "\n\n".join(pages)


def _docx_text(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as archive:
            document = archive.getinfo("word/document.xml")
            if document.file_size > MAX_PARSE_BYTES:
                raise ArtifactTextUnavailable("it is too large to parse")
            root = ElementTree.fromstring(archive.read(document))
    except KeyError as error:
        raise ArtifactTextUnavailable("it is a zip archive, not a Word document") from error
    except (zipfile.BadZipFile, ElementTree.ParseError) as error:
        raise ArtifactTextUnavailable(f"it is not a readable Word document ({error})") from error
    return "\n".join(
        "".join(node.text or "" for node in paragraph.iter(f"{WORD_NAMESPACE}t"))
        for paragraph in root.iter(f"{WORD_NAMESPACE}p")
    )


def _joined(value: Any) -> str:
    if isinstance(value, list):
        return "".join(item for item in value if isinstance(item, str))
    return value if isinstance(value, str) else ""


def _notebook_text(raw: str) -> str:
    """Markdown cells, code cells fenced, and the text of their outputs, in order."""
    try:
        cells = json.loads(raw)["cells"]
    except (ValueError, KeyError, TypeError) as error:
        raise ArtifactTextUnavailable(f"it is not a readable notebook ({error})") from error
    parts: list[str] = []
    for cell in cells if isinstance(cells, list) else []:
        if not isinstance(cell, dict):
            continue
        source = _joined(cell.get("source"))
        if cell.get("cell_type") != "code":
            parts.append(source)
            continue
        parts.append(f"```\n{source}\n```" if source.strip() else "")
        for output in cell.get("outputs") or []:
            if not isinstance(output, dict):
                continue
            data = output.get("data") if isinstance(output.get("data"), dict) else {}
            parts.append(
                _joined(output.get("text"))
                or _joined(data.get("text/markdown"))
                or _joined(data.get("text/plain"))
            )
    return "\n\n".join(part for part in parts if part.strip())


class _HtmlText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skipping = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in HTML_SKIPPED_TAGS:
            self.skipping += 1
        elif tag in HTML_BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in HTML_SKIPPED_TAGS:
            self.skipping = max(0, self.skipping - 1)
        elif tag in HTML_BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self.skipping:
            self.parts.append(data)


def _html_text(raw: str) -> str:
    parser = _HtmlText()
    parser.feed(raw)
    parser.close()
    lines = (line.strip() for line in "".join(parser.parts).splitlines())
    return "\n".join(line for line in lines if line)
