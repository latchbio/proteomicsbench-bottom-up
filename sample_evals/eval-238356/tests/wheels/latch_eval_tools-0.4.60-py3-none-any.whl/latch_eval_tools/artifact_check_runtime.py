"""Snapshot resolved grader files and run the standard worker in a bounded process.

The caller supplies the sandbox and read-only submission mount. This helper is
also usable locally for author testing; local execution is not an OS sandbox.
"""

from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from latch_eval_tools.artifact_runtime import MAX_RESULTS_BYTES
from latch_eval_tools.graders.artifact import (
    ArtifactGraderConfig,
    artifact_system_error_payload,
    normalize_artifact_payload,
    validate_artifact_results,
)


def run_artifact_checks(
    config: dict[str, Any],
    *,
    script: Path,
    references: dict[str, Path],
    submission_dir: Path,
    grader_output_dir: Path,
    artifacts: dict[str, Path] | None = None,
) -> dict[str, Any]:
    """One script invocation per grader, with a whole-invocation timeout."""
    grader_output_dir.mkdir(parents=True, exist_ok=True)
    parsed = ArtifactGraderConfig.model_validate(config)
    if parsed.script is None:
        raise ValueError("run_artifact_checks requires script/checks config")
    manifest: dict[str, Any] = {}

    def snapshot(source: Path, target: Path, uri: str) -> Path:
        if not source.is_file():
            raise ValueError(f"grader input is not a file: {uri}")
        digest = hashlib.sha256()
        with source.open("rb") as src, target.open("wb") as dst:
            while chunk := src.read(1024 * 1024):
                digest.update(chunk)
                dst.write(chunk)
        target.chmod(0o444)
        manifest[target.name] = {
            "reference": uri,
            "sha256": digest.hexdigest(),
            "size_bytes": target.stat().st_size,
        }
        return target.resolve()

    def error_payload(message: str, stderr: str = "") -> dict[str, Any]:
        payload = artifact_system_error_payload(message, stderr=stderr)
        payload["metrics"].update(
            input_manifest=manifest,
            checks=[
                {
                    "id": c.id,
                    "title": c.title,
                    "status": "error",
                    "passed": None,
                    "message": message,
                    "metrics": {},
                }
                for c in parsed.checks
            ],
        )
        (grader_output_dir / "results.json").write_text(
            json.dumps(payload, indent=2, allow_nan=False)
        )
        return payload

    # A fresh directory prevents an old results.json from satisfying a failed run.
    with tempfile.TemporaryDirectory(prefix="checks-", dir=grader_output_dir) as tmp:
        root = Path(tmp)
        try:
            code = snapshot(script, root / "grader.py", parsed.script)
            bound_references: dict[str, str] = {}
            for check in parsed.checks:
                if check.reference_needed:
                    source = references.get(check.id)
                    if source is None:
                        raise ValueError(f"missing reference for {check.id}")
                    assert check.reference is not None
                    bound_references[check.id] = str(
                        snapshot(
                            source,
                            root / f"reference-{check.id}{source.suffix}",
                            check.reference,
                        )
                    )
        except (OSError, ValueError) as exc:
            return error_payload(str(exc))
        request_path, result_path = root / "request.json", root / "results.json"
        request_path.write_text(
            json.dumps(
                {
                    "script": str(code),
                    "checks": [c.model_dump() for c in parsed.checks],
                    "references": bound_references,
                    "submission_dir": str(submission_dir.resolve()),
                    "artifacts": {
                        name: str(path.resolve())
                        for name, path in (artifacts or {}).items()
                    },
                    "scratch_dir": str((grader_output_dir / "scratch").resolve()),
                    "input_manifest": manifest,
                }
            )
        )
        worker = Path(__file__).with_name("artifact_checks.py")
        # -I prevents a submission or PYTHONPATH from shadowing platform modules.
        argv = [
            sys.executable,
            "-I",
            str(worker),
            str(request_path.resolve()),
            str(result_path.resolve()),
        ]
        stderr_path = grader_output_dir / "stderr.log"
        with (
            (grader_output_dir / "stdout.log").open("w") as stdout,
            stderr_path.open("w") as stderr,
        ):
            try:
                process = subprocess.Popen(
                    argv, cwd=root, stdout=stdout, stderr=stderr, start_new_session=True
                )
                try:
                    process.wait(timeout=parsed.compute.timeout_seconds)
                    error = (
                        None
                        if process.returncode == 0
                        else f"artifact checks exited with status {process.returncode}"
                    )
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                    error = f"artifact checks exceeded their {parsed.compute.timeout_seconds}s timeout"
            except OSError as exc:
                error = f"could not start artifact checks: {exc}"
        with stderr_path.open("rb") as stream:
            stream.seek(max(0, stderr_path.stat().st_size - 65536))
            stderr_text = stream.read().decode("utf-8", "replace")
        if error is not None:
            return error_payload(error, stderr_text)
        if not result_path.is_file() or result_path.stat().st_size > MAX_RESULTS_BYTES:
            return error_payload(
                "artifact checks produced missing or oversized results", stderr_text
            )
        try:
            payload = json.loads(result_path.read_text())
            problems = validate_artifact_results(payload)
            if problems:
                raise ValueError("; ".join(problems))
            # The manifest is recorded by the wrapper, not trusted to the author script.
            payload["metrics"]["input_manifest"] = manifest
            result = normalize_artifact_payload(payload)
            (grader_output_dir / "results.json").write_text(
                json.dumps(result, indent=2, allow_nan=False)
            )
            return result
        except (ValueError, OSError) as exc:
            return error_payload(f"invalid artifact check results: {exc}", stderr_text)
