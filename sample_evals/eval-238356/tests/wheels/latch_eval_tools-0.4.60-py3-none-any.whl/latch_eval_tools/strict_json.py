"""JSON decoding for submitted answers; duplicate fields are ambiguous."""

import json
import math


def reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON field: {key}")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise ValueError(f"Non-finite JSON number: {value}")


def _finite_float(text: str) -> float:
    value = float(text)
    if not math.isfinite(value):
        raise ValueError("Non-finite JSON number")
    return value


def strict_json_loads(text: str) -> object:
    return json.loads(
        text,
        object_pairs_hook=reject_duplicate_keys,
        parse_constant=_reject_constant,
        parse_float=_finite_float,
    )
