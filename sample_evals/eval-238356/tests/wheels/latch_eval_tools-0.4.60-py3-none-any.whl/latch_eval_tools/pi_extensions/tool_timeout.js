import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const FALLBACK_BASH_TIMEOUT_SECONDS = 300;
const envBashTimeout = Number(process.env.PI_BASH_DEFAULT_TIMEOUT_SECONDS);
const DEFAULT_BASH_TIMEOUT_SECONDS =
  Number.isFinite(envBashTimeout) && envBashTimeout > 0
    ? envBashTimeout
    : FALLBACK_BASH_TIMEOUT_SECONDS;
const PI_BASH_TOOL_RELATIVE_PATH =
  "@earendil-works/pi-coding-agent/dist/core/tools/bash.js";

function resolvePiBashToolPath() {
  const roots = [];
  if (process.env.NODE_PATH) {
    roots.push(...process.env.NODE_PATH.split(path.delimiter));
  }
  try {
    roots.push(execFileSync("npm", ["root", "-g"], { encoding: "utf8" }).trim());
  } catch {
  }
  roots.push("/usr/local/lib/node_modules", "/root/.local/lib/node_modules");

  for (const root of roots) {
    if (!root) continue;
    const candidate = path.join(root, PI_BASH_TOOL_RELATIVE_PATH);
    if (existsSync(candidate)) return candidate;
  }

  throw new Error(`Could not find ${PI_BASH_TOOL_RELATIVE_PATH}`);
}

const { createBashToolDefinition } = await import(
  pathToFileURL(resolvePiBashToolPath()).href
);

export default function(pi) {
  const bash = createBashToolDefinition(process.cwd());
  bash.parameters.properties.timeout.description = `Timeout in seconds (${DEFAULT_BASH_TIMEOUT_SECONDS}s default)`;

  pi.registerTool({
    ...bash,

    async execute(toolCallId, params, signal, onUpdate, ctx) {
      const requestedTimeout = params.timeout;
      const timeout =
        typeof requestedTimeout === "number" && requestedTimeout > 0
          ? requestedTimeout
          : DEFAULT_BASH_TIMEOUT_SECONDS;

      return bash.execute(toolCallId, { ...params, timeout }, signal, onUpdate, ctx);
    },
  });
}
