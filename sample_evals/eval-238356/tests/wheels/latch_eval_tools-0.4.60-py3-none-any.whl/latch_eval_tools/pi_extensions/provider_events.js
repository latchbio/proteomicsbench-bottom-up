import { appendFileSync, mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";

// Pi exposes SSE messages directly, but renders HTTP error objects as JSON after
// the status prefix. Only normalize the gateway's declared generation errors.
function googleGenerationError(error) {
  let message = error;
  const body = error.replace(/^\s*(?:400|422|502):\s*/, "");
  if (body.startsWith("{")) {
    try {
      const parsed = JSON.parse(body);
      if (parsed?.type !== "google_generation_error" || typeof parsed.message !== "string") return;
      message = parsed.message;
    } catch {
      return;
    }
  }
  return message.match(/^(?:400|422|502): google generation failed \([A-Z_]+\)(?=:|$)/)?.[0];
}

function isBeamGatewayModel(model) {
  return model?.provider === "latch" && model.api === "openai-completions" &&
    model.id === "openrouter/reflection/beam-1.0-501b-a23b";
}

// Pi replays structured reasoning, but the pinned gateway's OpenAI egress
// only carries the plain reasoning field. Beam requires that text on later turns.
function beamReasoningMessage(message) {
  if (message.role !== "assistant" || message.reasoning_content || message.reasoning ||
      !Array.isArray(message.reasoning_details)) return message;
  const reasoning = message.reasoning_details
    .filter(detail => detail?.type === "reasoning.text" && typeof detail.text === "string")
    .map(detail => detail.text).join("");
  return reasoning ? { ...message, reasoning_content: reasoning } : message;
}

export default function(pi) {
  const logPath = process.env.LATCH_REFUSAL_LOG || path.join(process.env.HOME, ".pi/refusal_events.jsonl");
  let refused = false;
  let captureError;
  let gatewayRouting;
  const record = (provider, rawReason, extras = {}) => {
    // Set before writing: capture failures must never enable provider retries.
    refused = true;
    try {
      mkdirSync(path.dirname(logPath), { recursive: true });
      appendFileSync(logPath, JSON.stringify({
        ts: new Date().toISOString(), provider, raw_reason: rawReason, ...extras,
      }) + "\n");
    } catch (error) {
      captureError = String(error);
    }
  };

  pi.on("session_start", () => {
    mkdirSync(path.dirname(logPath), { recursive: true });
    writeFileSync(path.join(path.dirname(logPath), ".provider_events_status.json"),
      JSON.stringify({ refusalCapture: "provider_stream_event", retry: "message_end" }));
  });

  // Response headers identify the provider that served this call, including
  // fallbacks and affinity hits. Keep the configured Pi provider/model intact.
  pi.on("before_provider_request", ({ payload }, ctx) => {
    gatewayRouting = undefined;
    if (!isBeamGatewayModel(ctx.model)) return;
    // OpenRouter omits tools from Baseten's Beam metadata, but explicit routing
    // supports tool calls. Our /v1/chat/completions route is Bifrost's native
    // API: unknown top-level fields pass through with the opt-in header below.
    // Nesting this under extra_params is only for the /openai integration.
    return {
      ...payload,
      messages: payload.messages.map(beamReasoningMessage),
      provider: { only: ["baseten"], allow_fallbacks: false, require_parameters: false },
    };
  });
  pi.on("before_provider_headers", ({ headers }, ctx) => {
    if (isBeamGatewayModel(ctx.model)) headers["x-bf-passthrough-extra-params"] = "true";
  });
  pi.on("after_provider_response", ({ headers }) => {
    const provider = headers["x-bifrost-routing-info-provider"];
    if (typeof provider !== "string" || !provider) return;
    gatewayRouting = { provider };
    for (const [name, header] of Object.entries({
      key: "x-bifrost-routing-info-key",
      model: "x-bifrost-resolved-model",
      isFallback: "x-bifrost-routing-info-is-fallback",
    })) {
      const value = headers[header];
      if (typeof value === "string" && value) gatewayRouting[name] = value;
    }
  });

  pi.on("provider_stream_event", (event) => {
    const data = event.data;
    if (!data || typeof data !== "object") return;
    if (event.api === "openai-completions") {
      for (const choice of data.choices ?? []) {
        if (choice.finish_reason === "content_filter") record("openai-completions", "content_filter");
      }
    } else if (event.api === "openai-responses") {
      if (data.type === "response.refusal.delta") {
        record("openai-responses", "refusal", { explanation: data.delta });
      } else if (data.type === "response.incomplete" && data.response?.incomplete_details?.reason === "content_filter") {
        record("openai-responses", "content_filter");
      }
    } else if (event.api === "anthropic-messages") {
      const reason = data.delta?.stop_reason;
      if (reason === "refusal" || reason === "sensitive") {
        record("anthropic", reason, { explanation: data.delta?.stop_details?.explanation ?? null });
      }
    } else if (event.api === "google-generative-ai" || event.api === "google-vertex") {
      if (data.promptFeedback?.blockReason) {
        record("google", String(data.promptFeedback.blockReason), { source: "promptFeedback" });
      }
      for (const candidate of data.candidates ?? []) {
        if (["SAFETY", "PROHIBITED_CONTENT", "RECITATION", "BLOCKLIST", "SPII",
          "IMAGE_SAFETY", "IMAGE_PROHIBITED_CONTENT", "IMAGE_RECITATION"].includes(candidate.finishReason)) {
          record("google", candidate.finishReason, { source: "finishReason" });
        }
      }
    }
  });

  pi.on("message_end", ({ message: originalMessage }) => {
    if (originalMessage.role !== "assistant") return;
    const message = gatewayRouting ? {
      ...originalMessage,
      diagnostics: [...(originalMessage.diagnostics ?? []), {
        type: "latch_gateway_routing", timestamp: Date.now(), details: gatewayRouting,
      }],
    } : originalMessage;
    const error = message.errorMessage ?? "";
    // SDK exceptions can arrive before any provider stream event.
    if (message.api === "anthropic-messages" &&
        ["refusals-and-fallback", "configuring a fallback model", "reduce refusals for your users"]
          .some(marker => error.includes(marker))) {
      record("anthropic", "error", { errorMessage: error });
    } else if (["google-generative-ai", "google-vertex"].includes(message.api) &&
        /prompt_?feedback|block_?reason|request blocked|response blocked|policy reason|safety|prohibited/i.test(error)) {
      record("google", "error", { errorMessage: error, source: "error" });
    }
    if (captureError) return { message: {
      ...message, stopReason: "error", errorMessage: "Pi refusal capture failed",
      diagnostics: [...(message.diagnostics ?? []), {
        type: "latch_refusal_capture_error", timestamp: Date.now(), details: { error: captureError },
      }],
    } };
    if (message.stopReason !== "error") return message === originalMessage ? undefined : { message };
    const noAnswer = Array.isArray(message.content) && message.content.every(block =>
      block && (block.type === "thinking" || (block.type === "text" && typeof block.text === "string" && !block.text.trim())));
    const generationError = message.provider === "latch" && message.api === "openai-completions"
      ? googleGenerationError(error) : undefined;
    let replacement;
    if (refused) replacement = "Provider refusal";
    // Native diagnostics can quote generated code containing "billing" or "rate
    // limit". Keep that text in diagnostics, outside Pi's retry/context heuristics.
    else if (generationError) replacement = generationError;
    else if (error.trim() === "Provider finish_reason: error" && noAnswer) {
      // Pi's native policy recognizes this wording. Keep its retry limits,
      // backoff, cancellation and context omission; never add a prompt/turn.
      replacement = "Provider returned error: Provider finish_reason: error";
    }
    if (replacement) return { message: {
      ...message, errorMessage: replacement,
      diagnostics: [...(message.diagnostics ?? []), {
        type: "latch_provider_error", timestamp: Date.now(), details: { originalErrorMessage: error },
      }],
    } };
    return message === originalMessage ? undefined : { message };
  });
}
