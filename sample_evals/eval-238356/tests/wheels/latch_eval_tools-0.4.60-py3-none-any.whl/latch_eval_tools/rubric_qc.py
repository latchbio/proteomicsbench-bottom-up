"""Compatibility alias for the shared rubric implementation."""

import sys

from latch_eval_tools._rubric import rubric_qc as _implementation

sys.modules[__name__] = _implementation
