"""Provider response adapters shared by the queue worker and Yeast rubric batches."""

import json
from typing import Any
from anthropic import transform_schema
from anthropic.types import Message
from openai import AsyncOpenAI
from openai.types.responses import Response

ANTHROPIC_OK_STOP_REASONS = frozenset({"end_turn", "stop_sequence", "tool_use"})


async def gemini_inference(
    client: AsyncOpenAI,
    common: dict[str, Any],
    *,
    model: str,
    max_tokens: int,
    system: Any,
    messages: list[Any],
    tools: Any,
    call_id: str,
    options: dict[str, Any],
) -> dict[str, Any]:
    kwargs = common | {
        "max_tokens": max_tokens,
        "messages": [{"role": "system", "content": prompt_text(system)}]
        + [
            {"role": m["role"], "content": gemini_message_content(m["content"])}
            for m in messages
        ],
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    for name in ("temperature", "top_p"):
        if name in options:
            kwargs[name] = options[name]
    thinking = options.get("thinking_config")
    if isinstance(thinking, dict) and isinstance(thinking.get("thinking_level"), str):
        kwargs["reasoning_effort"] = thinking["thinking_level"].lower()
    schema = options.get("response_json_schema")
    if isinstance(schema, dict):
        kwargs["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": "result", "schema": schema},
        }
    elif options.get("response_mime_type") == "application/json":
        kwargs["response_format"] = {"type": "json_object"}
    if tools:
        kwargs["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool.get("description", ""),
                    "parameters": tool_parameters(tool),
                },
            }
            for tool in tools
        ]
        kwargs["tool_choice"] = "required"
    text: list[str] = []
    arguments: dict[int, str] = {}
    usage: dict[str, Any] = {}
    request_id: str | None = None
    finish_reason: str | None = None
    stream = await client.chat.completions.create(**kwargs)
    async with stream:
        async for chunk in stream:
            request_id = chunk.id or request_id
            if chunk.usage is not None:
                details = chunk.usage.prompt_tokens_details
                usage = {
                    "prompt_token_count": chunk.usage.prompt_tokens,
                    "candidates_token_count": chunk.usage.completion_tokens,
                    "total_token_count": chunk.usage.total_tokens,
                    "cached_content_token_count": details.cached_tokens
                    if details is not None
                    else 0,
                }
            for choice in chunk.choices:
                if choice.index != 0:
                    continue
                finish_reason = choice.finish_reason or finish_reason
                if choice.delta.content:
                    text.append(choice.delta.content)
                for tool in choice.delta.tool_calls or []:
                    if tool.function is not None and tool.function.arguments:
                        arguments[tool.index] = (
                            arguments.get(tool.index, "") + tool.function.arguments
                        )
    output = arguments[min(arguments)] if arguments else "".join(text).strip()
    return {
        "provider": "gemini",
        "model": model,
        "results": [
            {
                "id": call_id,
                "text": output,
                "usage": usage,
                "cost_usd": None,
                "provider_request_id": request_id,
                "error": None
                if finish_reason in {"stop", "tool_calls"}
                else f"model stopped early: {finish_reason}",
                "metadata": {"stop_reason": finish_reason},
            }
        ],
    }


def gemini_message_content(value: Any) -> str | list[dict[str, Any]]:
    """Keep OpenAI-compatible PDF parts intact through the Gemini gateway route."""
    if not isinstance(value, list):
        return prompt_text(value)
    if any(
        isinstance(block, dict) and block.get("type") == "ldata_document"
        for block in value
    ):
        raise ValueError("LData documents must be resolved before provider invocation")
    if not any(
        isinstance(block, dict) and block.get("type") == "file" for block in value
    ):
        return prompt_text(value)
    blocks: list[dict[str, Any]] = []
    for block in value:
        if not isinstance(block, dict) or block.get("type") not in {"text", "file"}:
            raise ValueError("unsupported Gemini document content part")
        blocks.append(block)
    return blocks


def prompt_text(value: Any) -> str:
    """Read a neutral prompt string, tolerating pre-neutral Anthropic block lists.

    Jobs queued before this service rolls out still carry block lists; the
    tolerance can go once none are left in flight.
    """
    if isinstance(value, str):
        return value
    return "\n\n".join(
        block["text"]
        for block in value
        if isinstance(block, dict) and block.get("type") == "text"
    ).strip()


def tool_parameters(tool: dict[str, Any]) -> dict[str, Any]:
    parameters = tool.get("parameters")
    return parameters if parameters is not None else tool["input_schema"]


def anthropic_tool(tool: dict[str, Any]) -> dict[str, Any]:
    schema = tool_parameters(tool)
    result = {
        "name": tool["name"],
        "description": tool["description"],
        "input_schema": schema,
    }
    if tool.get("strict") is True:
        result["strict"] = True
        # The SDK moves unsupported length/numeric constraints into descriptions.
        # Consumers still validate the returned data against their original model.
        result["input_schema"] = transform_schema(schema)
    return result


def openai_tool(tool: dict[str, Any]) -> dict[str, Any]:
    # strict is off on purpose: the Responses API defaults it on, and strict
    # schemas must close every object and require every key, which the node
    # schemas do not do. The forced tool_choice is what guarantees a call, and
    # the node validates the returned data either way.
    return {
        "type": "function",
        "name": tool["name"],
        "description": tool["description"],
        "parameters": tool_parameters(tool),
        "strict": False,
    }


def result_payload(
    *,
    provider: str,
    model: str,
    call_id: str,
    message: Message,
    refusal_fallback: bool = False,
) -> dict[str, Any]:
    tool_input = next((b.input for b in message.content if b.type == "tool_use"), None)
    text = (
        json.dumps(tool_input)
        if tool_input is not None
        else "\n".join(b.text for b in message.content if b.type == "text").strip()
    )
    metadata: dict[str, Any] = {"stop_reason": message.stop_reason}
    if refusal_fallback:
        metadata["refusal_fallback"] = True
    return {
        "provider": provider,
        "model": model,
        "results": [
            {
                "id": call_id,
                "text": text,
                "usage": message.usage.model_dump(mode="json"),
                "cost_usd": None,
                "provider_request_id": message.id.strip() or None,
                "error": (
                    None
                    if message.stop_reason in ANTHROPIC_OK_STOP_REASONS
                    else f"model stopped early: {message.stop_reason}"
                ),
                "metadata": metadata,
            }
        ],
    }


def openai_result_payload(
    *, model: str, call_id: str, response: Response
) -> dict[str, Any]:
    function_call = next(
        (item for item in response.output if item.type == "function_call"), None
    )
    text = (
        function_call.arguments.strip()
        if function_call is not None
        else response.output_text.strip()
    )
    incomplete = response.incomplete_details
    # A reasoning model spends max_output_tokens on thinking too, so a
    # truncated answer arrives as status "incomplete" rather than an error.
    stop_reason = (
        incomplete.reason
        if incomplete is not None and incomplete.reason is not None
        else response.status
    )
    request_id = (response.id or "").strip()
    return {
        "provider": "openai",
        "model": model,
        "results": [
            {
                "id": call_id,
                "text": text,
                "usage": (
                    response.usage.model_dump(mode="json", exclude_none=True)
                    if response.usage is not None
                    else {}
                ),
                "cost_usd": None,
                "provider_request_id": request_id or None,
                "error": (
                    None
                    if response.status == "completed"
                    else f"model stopped early: {stop_reason}"
                ),
                "metadata": {"stop_reason": str(stop_reason)},
            }
        ],
    }
