"""Scoped gateway connection and wire-format helpers, without CLI harnesses."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from hashlib import sha256
from ipaddress import ip_address
from typing import Literal
from urllib.parse import urlsplit


YEAST_V2_JOB_ID_ENV = "YEAST_V2_JOB_ID"


@dataclass(frozen=True)
class GatewayRun:
    """The durable owner of a gateway call, independent of its affinity session."""

    kind: Literal["execution", "yeast-job"]
    id: int

    @property
    def headers(self) -> dict[str, str]:
        # Local Yeast jobs use UUID integers and have no corresponding Core row.
        if not 0 < self.id <= 2**63 - 1:
            return {}
        return {"x-bf-lh-latch-run": f"{self.kind}:{self.id}"}


@dataclass(frozen=True)
class GatewayConnection:
    api_key: str = field(repr=False)
    session_id: str
    base_url: str = "https://llm.latch.bio"
    # Only trusted rollout launchers construct per-run, private HTTP relays.
    is_relay: bool = False
    # The harness setting, before any CLI/model-specific wire translation.
    configured_reasoning_effort: str | None = None

    # Snapshot captured by the caller before crossing a process boundary.
    trace_headers: dict[str, str] = field(default_factory=dict)
    run: GatewayRun | None = None

    def __post_init__(self) -> None:
        if any(
            name not in {"traceparent", "tracestate"}
            or not isinstance(value, str)
            or not value
            or not value.isascii()
            or any(not c.isprintable() for c in value)
            for name, value in self.trace_headers.items()
        ):
            raise ValueError("Trace context must contain only W3C trace headers")
        object.__setattr__(self, "trace_headers", dict(self.trace_headers))
        parsed = urlsplit(self.base_url)
        private_relay = False
        if self.is_relay and self.api_key.startswith("sk-bf-relay-"):
            try:
                address = ip_address(parsed.hostname or "")
                private_relay = address.is_private and not address.is_unspecified
            except ValueError:
                pass
        if self.is_relay and (not private_relay or parsed.scheme != "http"):
            raise ValueError(
                "Relay connections require a private HTTP origin and relay token"
            )
        if (
            parsed.scheme not in {"https", "http"}
            or not parsed.netloc
            or parsed.username is not None
            or parsed.password is not None
            or parsed.path not in {"", "/"}
            or parsed.query
            or parsed.fragment
            or (
                parsed.scheme == "http"
                and parsed.hostname
                not in {"localhost", "127.0.0.1", "llm-gateway.prod.svc.cluster.local"}
                and not private_relay
            )
        ):
            raise ValueError("Gateway URL must be an HTTPS origin or local service")
        if not self.api_key.startswith("sk-bf-"):
            raise ValueError("Gateway connections require a scoped Bifrost virtual key")
        if not self.session_id or any(c in self.session_id for c in "\r\n"):
            raise ValueError("Gateway connections require a stable session ID")
        if self.configured_reasoning_effort is not None and (
            not isinstance(self.configured_reasoning_effort, str)
            or not self.configured_reasoning_effort
            or not self.configured_reasoning_effort.isascii()
            or any(
                c.isspace() or not c.isprintable()
                for c in self.configured_reasoning_effort
            )
        ):
            raise ValueError(
                "Configured reasoning effort must be a nonempty ASCII token"
            )

    @property
    def headers(self) -> dict[str, str]:
        headers = {
            **self.trace_headers,
            "x-bf-session-id": self.session_id,
            "x-bf-eh-x-session-id": self.session_id,
        }
        if self.run is not None:
            headers.update(self.run.headers)
        if self.configured_reasoning_effort is not None:
            headers["x-bf-dim-configured_reasoning_effort"] = (
                self.configured_reasoning_effort.lower()
            )
        return headers

    def wire_model(self, model: str) -> str:
        return wire_model(model)

    def endpoint(self, protocol: str) -> str:
        return self.base_url.rstrip("/") + (
            "/anthropic" if protocol == "anthropic-messages" else "/v1"
        )


def request_reasoning_headers(options: Mapping[str, object]) -> dict[str, str]:
    """Label explicit API effort; never infer an effort from a token budget.

    Used after per-call overrides and gateway protocol adaptation. CLI connections
    only expose configured_reasoning_effort because their wire mapping is external.
    """
    effort = options.get("reasoning_effort")
    for key in ("reasoning", "output_config"):
        value = options.get(key)
        if isinstance(value, dict) and "effort" in value:
            effort = value["effort"]
    if (
        isinstance(effort, str)
        and effort
        and effort.isascii()
        and all(c.isprintable() and not c.isspace() for c in effort)
    ):
        return {"x-bf-dim-reasoning_effort": effort.lower()}
    return {}


def session_id(run_identity: str) -> str:
    if not run_identity:
        raise ValueError("A gateway session needs a stable run identity")
    return "v2:" + sha256(run_identity.encode()).hexdigest()


def split_model(model: str) -> tuple[str, str]:
    provider, separator, name = model.partition("/")
    if not separator or not name:
        raise ValueError(f"Expected provider/model, received {model!r}")
    if provider == "google":
        provider = "gemini"
    if provider not in {
        "anthropic",
        "openai",
        "gemini",
        "openrouter",
        "fireworks",
        "xai",
        "mistral",
        "meta",
        "modal",
    }:
        raise ValueError(f"No gateway protocol for provider {provider!r}")
    return provider, name


def wire_model(model: str) -> str:
    """Normalize the protocol prefix; Bifrost owns model aliases and routing."""
    provider, name = split_model(model)
    logical_name = name.removeprefix("google/") if provider == "openrouter" else name
    if provider in {"gemini", "openrouter"} and logical_name in {
        "gemini-3.7-flash",
        "gemini-3.8-flash",
    }:
        # Unqualified requests let Bifrost retain provider as well as key affinity.
        return logical_name
    return f"{provider}/{name}"
