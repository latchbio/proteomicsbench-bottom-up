"""Rubric criterion wire contracts shared by queued and Yeast execution."""

from copy import deepcopy
from typing import Any
from anthropic.types import Message
from pydantic import BaseModel, ConfigDict, Field
from .rubric import GraderError


class RubricRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model: str
    system: str
    messages: list[dict[str, Any]]
    max_tokens: int = Field(gt=0)
    timeout: float = Field(gt=0, le=1800)
    output_config: dict[str, Any]
    thinking: dict[str, Any] | None = None


def rubric_inference_options(
    request: RubricRequest, model_id: str, model_params: dict[str, Any]
) -> tuple[str, str, dict[str, Any]]:
    """Adapt the rubric's criterion schema to the selected provider's wire format."""
    provider, separator, model = model_id.partition("/")
    if not separator:
        provider, model = "anthropic", model_id
    if provider == "anthropic":
        options: dict[str, Any] = {"output_config": dict(request.output_config)}
        if "reasoning_effort" in model_params:
            options["output_config"]["effort"] = model_params["reasoning_effort"]
        if request.thinking is not None:
            options["thinking"] = request.thinking
    else:
        schema = request.output_config["format"]["schema"]
        if provider == "openai":
            # The flat criterion schema has parsing defaults for historical
            # outputs, but OpenAI strict output requires every generated field.
            # Normalize only the wire copy; other providers keep their schema.
            schema = deepcopy(schema)
            schema["required"] = list(schema["properties"])
            for property_schema in schema["properties"].values():
                property_schema.pop("default", None)
            options = {
                "text": {
                    "format": {
                        "type": "json_schema",
                        "name": "rubric_criterion",
                        "schema": schema,
                        "strict": True,
                    }
                }
            }
            if "reasoning_effort" in model_params:
                options["reasoning_effort"] = model_params["reasoning_effort"]
        elif provider == "gemini":
            options = {"response_json_schema": schema}
            if "reasoning_effort" in model_params:
                options["thinking_config"] = {
                    "thinking_level": model_params["reasoning_effort"]
                }
        else:
            raise GraderError(f"Unsupported rubric judge provider {provider!r}")
    if "temperature" in model_params:
        if request.thinking is not None:
            raise GraderError(
                "Explicit temperature cannot be combined with rubric thinking"
            )
        options["temperature"] = model_params["temperature"]
    return provider, model, options


def rubric_message_from_result(
    item: dict[str, Any], *, model: str, call_id: str
) -> Message:
    """Normalize completed queue results without interpreting a failure as a verdict."""
    metadata = item.get("metadata")
    raw_stop = metadata.get("stop_reason") if isinstance(metadata, dict) else None
    stop = {
        "completed": "end_turn",
        "stop": "end_turn",
        "tool_calls": "tool_use",
        "max_output_tokens": "max_tokens",
        "length": "max_tokens",
    }.get(raw_stop, raw_stop)
    if item.get("error") and stop not in {"refusal", "max_tokens"}:
        raise GraderError(str(item["error"]))
    if stop not in {"end_turn", "stop_sequence", "tool_use", "refusal", "max_tokens"}:
        raise GraderError(f"Rubric inference returned unknown stop reason {raw_stop!r}")
    usage = item.get("usage") or {}
    return Message.model_validate(
        {
            "id": item.get("provider_request_id") or call_id,
            "type": "message",
            "role": "assistant",
            "model": model,
            "content": [{"type": "text", "text": item["text"]}],
            "stop_reason": stop,
            "stop_sequence": None,
            "usage": {
                # This synthetic Anthropic message is only a parser envelope.
                # Native usage details have incompatible provider schemas (e.g.
                # OpenAI reasoning_tokens versus Anthropic thinking_tokens).
                # Keep only common totals here; the queue retains native usage.
                "input_tokens": usage.get(
                    "input_tokens", usage.get("prompt_token_count", 0)
                ),
                "output_tokens": usage.get(
                    "output_tokens", usage.get("candidates_token_count", 0)
                ),
            },
        }
    )
