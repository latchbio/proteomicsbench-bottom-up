# Shared rubric core

This directory is the single implementation of rubric grading, QC planning,
request formatting, and native provider transport. It depends only on Pydantic
and the Anthropic and OpenAI SDKs. Its imports are relative and its initializer
does not load the grader registry or agent harnesses.

It is packaged in two ways:

- `latch-eval-tools` includes it as `latch_eval_tools._rubric`. Legacy module
  paths alias these modules, preserving class identity and monkeypatch targets.
  Existing source bundles, sandbox mounts, and published grader wheels remain
  self-contained; no additional package needs to be staged or published.
- This directory builds the standalone `latch-rubric-core` wheel, exposing the
  same files as `latch_rubric_core`. Yeast installs this wheel from the repository
  and does not install `latch-eval-tools`. The two wheels own disjoint paths.

Keep shared code here rather than copying it into either consumer. The worker
and orchestrator exchange JSON contracts, not Python objects across the two
import namespaces. Install the standalone package normally (not editable), since
the wheel build maps this source directory to its public import namespace.
