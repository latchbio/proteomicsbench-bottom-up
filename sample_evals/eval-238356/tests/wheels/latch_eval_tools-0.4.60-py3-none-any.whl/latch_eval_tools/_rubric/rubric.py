import asyncio
import random
import re
from collections.abc import Awaitable, Callable
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Literal, Optional

from anthropic import APIConnectionError, APIStatusError, AsyncAnthropic, RateLimitError
from anthropic.types import Message
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

from .base import GraderResult, get_nested_value

DEFAULT_TRUNCATION_LENGTH = 512
DEFAULT_MODEL_ID = "anthropic/claude-sonnet-5"
# A rubric with `artifact` judges the text of that declared artifact role. The artifact sandbox
# extracts at most ARTIFACT_TEXT_MAX_CHARS characters of it, which the platform hands to the
# rubric under ARTIFACT_TEXT_FIELD (never taken from the agent's own answer).
ARTIFACT_TEXT_FIELD = "artifact_text"
ARTIFACT_TEXT_MAX_CHARS = 50_000
DEFAULT_MODEL_PARAMS: dict[str, Any] = {
    "thinking": {
        "type": "adaptive",
        "display": "omitted",
    }
}
RUBRIC_GRADER_SYSTEM_PROMPT = "You are a teacher grading a test response vs a rubric."
RAW_CONTENT_DEBUG_LIMIT = 20000

# Use the native Anthropic API instead of LiteLLM because LiteLLM structured
# output could not be made reliable for this grader; output_config.format gives
# schema-constrained decoding while preserving extended thinking.
#
# Retry policy has two independent paths:
# - Parse/refusal errors: fast fixed-attempt retries (the model produced a bad
#   output; waiting longer does not help).
# - Transient API errors (429/529/5xx/timeouts/connection): full-jitter backoff
#   drawn from a budget of cooldown wall-clock time shared across all criterion
#   tasks of one rubric. The SDK's own retries are disabled (max_retries=0) so
#   this policy is the only retry layer. On budget exhaustion the grader raises
#   GraderTransientError so callers can schedule a much longer retry.
GRADER_MAX_RETRIES = 3
GRADER_MAX_ATTEMPTS = GRADER_MAX_RETRIES + 1
RETRY_BASE_DELAY_SECONDS = 0.5
RETRY_MAX_DELAY_SECONDS = 8.0
RETRY_JITTER_SECONDS = 0.5
REQUEST_TIMEOUT_SECONDS = 40.0
TRANSIENT_SLEEP_BUDGET_SECONDS = 30.0
TRANSIENT_BACKOFF_BASE_SECONDS = 2.0
TRANSIENT_BACKOFF_CAP_SECONDS = 20.0
DEFAULT_MAX_TOKENS_WITH_THINKING = 16_000
DEFAULT_MAX_TOKENS = 4_096
ANTHROPIC_PROVIDER_PREFIX = "anthropic/"


class GraderError(Exception):
    """Non-retryable grader infrastructure failure.

    Raised for failures where retrying will not help: bad requests (4xx other
    than rate limits), auth/config problems, and model outputs that repeatedly
    fail to parse. Callers should record a system error, not a score.
    """


class GraderTransientError(Exception):
    """Retryable grader infrastructure failure (rate limit / overload / 5xx / timeout).

    Raised once the shared in-process backoff budget is exhausted. Callers are
    expected to retry the whole grade much later (minutes, not seconds).
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        sleep_used_seconds: float = 0.0,
    ) -> None:
        self.status_code = status_code
        self.sleep_used_seconds = sleep_used_seconds
        super().__init__(message)


@dataclass(frozen=True)
class TransientErrorInfo:
    status_code: Optional[int]
    retry_after_seconds: Optional[float]
    rate_pressure: bool


def retry_after_seconds_from_error(exc: Exception) -> Optional[float]:
    headers = getattr(getattr(exc, "response", None), "headers", None)
    if headers is None:
        return None
    retry_after_ms = headers.get("retry-after-ms")
    if retry_after_ms is not None:
        try:
            return float(retry_after_ms) / 1000.0
        except ValueError:
            pass
    retry_after = headers.get("retry-after")
    if retry_after is not None:
        try:
            return float(retry_after)
        except ValueError:
            pass
    return None


def classify_transient_error(exc: Exception) -> Optional[TransientErrorInfo]:
    """Classify an Anthropic SDK error as transient (retryable) or not.

    Returns ``None`` for non-retryable errors (bad request, auth, etc.).
    ``rate_pressure`` marks 429/529, which additionally serialize the rubric's
    remaining criterion requests.
    """
    if isinstance(exc, RateLimitError):
        return TransientErrorInfo(
            status_code=429,
            retry_after_seconds=retry_after_seconds_from_error(exc),
            rate_pressure=True,
        )
    if isinstance(exc, APIStatusError):
        if exc.status_code >= 500 or exc.status_code in (408, 409):
            return TransientErrorInfo(
                status_code=exc.status_code,
                retry_after_seconds=retry_after_seconds_from_error(exc),
                rate_pressure=exc.status_code == 529,
            )
        return None
    if isinstance(exc, APIConnectionError):
        # Includes APITimeoutError (request timeouts) and connection failures.
        return TransientErrorInfo(
            status_code=None, retry_after_seconds=None, rate_pressure=False
        )
    return None


class TransientRetryController:
    """Coordinates transient-error backoff across the criterion tasks of one rubric.

    All criterion tasks share one cooldown window and one wall-clock sleep
    budget: overlapping failures extend the same cooldown instead of each
    charging the budget, and every task waits out the active cooldown before
    sending its next request. After the first 429/529, requests additionally
    run one at a time.
    """

    def __init__(
        self,
        sleep_budget_seconds: float = TRANSIENT_SLEEP_BUDGET_SECONDS,
        *,
        time_source: Any = None,
        sleep: Any = None,
    ) -> None:
        self.sleep_budget_seconds = sleep_budget_seconds
        self.sleep_used_seconds = 0.0
        self.serialized = False
        self._serial_lock = asyncio.Lock()
        self._cooldown_until = 0.0
        # Injectable for deterministic tests; production uses the event loop clock.
        self._time = (
            time_source
            if time_source is not None
            else (lambda: asyncio.get_running_loop().time())
        )
        self._sleep = sleep if sleep is not None else asyncio.sleep

    async def _wait_for_cooldown(self) -> None:
        while True:
            now = self._time()
            if now >= self._cooldown_until:
                return
            await self._sleep(self._cooldown_until - now)

    async def send(self, request: Any) -> Any:
        if self.serialized:
            async with self._serial_lock:
                await self._wait_for_cooldown()
                return await request()
        await self._wait_for_cooldown()
        return await request()

    async def backoff(
        self, attempt: int, info: TransientErrorInfo, cause: Exception
    ) -> None:
        """Extend the shared cooldown for a transient error and wait it out.

        Raises :class:`GraderTransientError` when extending the cooldown would
        exceed the shared sleep budget.
        """
        if info.rate_pressure:
            self.serialized = True

        delay = random.uniform(
            0.0,
            min(
                TRANSIENT_BACKOFF_CAP_SECONDS,
                TRANSIENT_BACKOFF_BASE_SECONDS * (2**attempt),
            ),
        )
        if info.retry_after_seconds is not None and info.retry_after_seconds > delay:
            delay = info.retry_after_seconds

        now = self._time()
        cooldown_start = max(self._cooldown_until, now)
        extension = (now + delay) - cooldown_start
        if extension > 0:
            remaining = self.sleep_budget_seconds - self.sleep_used_seconds
            if remaining <= 0:
                raise GraderTransientError(
                    f"rubric grader exhausted its {self.sleep_budget_seconds:.0f}s transient backoff budget "
                    f"(last error: {cause})",
                    status_code=info.status_code,
                    sleep_used_seconds=self.sleep_used_seconds,
                ) from cause
            self.sleep_used_seconds += min(extension, remaining)
            self._cooldown_until = cooldown_start + min(extension, remaining)
        await self._wait_for_cooldown()


def retry_backoff_seconds(attempt: int) -> float:
    base = min(RETRY_BASE_DELAY_SECONDS * (2**attempt), RETRY_MAX_DELAY_SECONDS)
    return base + random.uniform(0, RETRY_JITTER_SECONDS)


class RubricGraderOutputParseError(GraderError, ValueError):
    """Raised when the rubric grader model output cannot be parsed.

    Carries the untruncated raw model content and response metadata so a
    downstream failure record (which otherwise only sees a truncated pydantic
    error) contains everything needed to debug a new/unexpected output shape.
    """

    def __init__(
        self,
        message: str,
        *,
        raw_content: Any = None,
        finish_reason: Any = None,
        had_tool_calls: bool = False,
    ) -> None:
        self.raw_content = raw_content
        self.finish_reason = finish_reason
        self.had_tool_calls = had_tool_calls
        super().__init__(message)


def default_model_params() -> dict[str, Any]:
    return deepcopy(DEFAULT_MODEL_PARAMS)


class RubricCriterion(BaseModel):
    model_config = ConfigDict(extra="forbid")

    description: str = Field(min_length=1)
    score_delta: float
    steps_applied: list[int] | None = None

    @field_validator("description")
    @classmethod
    def validate_description(cls, value: str) -> str:
        stripped = value.strip()
        if stripped == "":
            raise ValueError("description must be a non-empty string")
        return stripped

    @field_validator("steps_applied")
    @classmethod
    def validate_steps_applied(cls, value: list[int] | None) -> list[int] | None:
        if value is None:
            return None
        if len(value) == 0:
            raise ValueError("steps_applied must list at least one step")
        for step in value:
            if isinstance(step, bool) or not isinstance(step, int) or step < 0:
                raise ValueError("steps_applied entries must be non-negative integers")
        return sorted(set(value))

    def applies_at(self, step: int) -> bool:
        return self.steps_applied is None or step in self.steps_applied


class RubricLengthPenaltyConfig(BaseModel):
    """Optional capped penalty on the full answer-field length, in characters."""

    model_config = ConfigDict(extra="forbid", strict=True)

    allowed_chars: int = Field(gt=0)
    ramp_percent: float = Field(gt=0.0, allow_inf_nan=False)
    max_penalty: float = Field(ge=0.0, le=1.0, allow_inf_nan=False)
    curve: Literal["linear", "power_0_5"] = "linear"


class RubricGraderConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    answer_field: str = Field(min_length=1)
    # A declared artifact role to judge instead of an answer field: shorthand for
    # `answer_field: "artifact_text.<role>"`, read up to ARTIFACT_TEXT_MAX_CHARS by default.
    artifact: str | None = Field(default=None, min_length=1)
    criteria: list[RubricCriterion] = Field(min_length=1)
    model_id: str = Field(default=DEFAULT_MODEL_ID, min_length=1)
    model_params: dict[str, Any] = Field(default_factory=default_model_params)
    truncation_length: int = Field(default=DEFAULT_TRUNCATION_LENGTH, gt=0)
    passing_reward_threshold: float = Field(default=1.0, ge=0.0, le=1.0)
    length_penalty: RubricLengthPenaltyConfig | None = None

    @model_validator(mode="before")
    @classmethod
    def artifact_answer_field(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        artifact = data.get("artifact")
        answer_field = data.get("answer_field")
        if artifact is None:
            if (
                isinstance(answer_field, str)
                and answer_field.strip().split(".")[0] == ARTIFACT_TEXT_FIELD
            ):
                raise ValueError(
                    f"answer_field {ARTIFACT_TEXT_FIELD!r} is reserved for artifact text; "
                    "set artifact instead"
                )
            return data
        if not isinstance(artifact, str):
            return data
        field = f"{ARTIFACT_TEXT_FIELD}.{artifact}"
        if answer_field is not None and answer_field != field:
            raise ValueError("set either answer_field or artifact, not both")
        return {"truncation_length": ARTIFACT_TEXT_MAX_CHARS, **data, "answer_field": field}

    @model_validator(mode="after")
    def artifact_truncation_length(self) -> "RubricGraderConfig":
        if self.artifact is not None and self.truncation_length > ARTIFACT_TEXT_MAX_CHARS:
            raise ValueError(
                f"truncation_length must be at most {ARTIFACT_TEXT_MAX_CHARS} with artifact"
            )
        return self

    @field_validator("answer_field", "model_id")
    @classmethod
    def validate_non_empty_string(cls, value: str) -> str:
        stripped = value.strip()
        if stripped == "":
            raise ValueError("must be a non-empty string")
        return stripped

    @model_validator(mode="after")
    def require_positive_max_score(self) -> "RubricGraderConfig":
        if positive_max_score(self.criteria) <= 0:
            raise ValueError(
                "criteria must include at least one positive score_delta (max_score must be > 0)"
            )
        return self


class RubricCriterionJudgment(BaseModel):
    model_config = ConfigDict(extra="forbid")

    index: int
    met: bool
    rationale: str = ""


class RubricGraderOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    judgments: list[RubricCriterionJudgment] = Field(min_length=1)


class RubricCriterionGraderOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    met: bool
    rationale: str = ""


class RubricCriterionGradeResult(BaseModel):
    model_config = ConfigDict(frozen=True)

    judgment: RubricCriterionJudgment
    attempts_used: int
    finish_reason: Any = None


class RubricScoreResult(BaseModel):
    model_config = ConfigDict(frozen=True)

    reward: float
    raw_score: float
    max_score: float
    passed: bool
    field_scores: dict[str, float]


def positive_max_score(criteria: list[RubricCriterion]) -> float:
    return sum(
        criterion.score_delta for criterion in criteria if criterion.score_delta > 0
    )


def compute_rubric_reward(
    config: RubricGraderConfig, output: RubricGraderOutput
) -> RubricScoreResult:
    max_score = positive_max_score(config.criteria)
    met_by_index = {judgment.index: judgment.met for judgment in output.judgments}
    raw_score = sum(
        criterion.score_delta
        for index, criterion in enumerate(config.criteria)
        if met_by_index.get(index) is True
    )
    reward = min(max(raw_score / max_score, 0.0), 1.0)
    field_scores = {
        f"criterion_{index}": criterion.score_delta
        if met_by_index.get(index) is True
        else 0.0
        for index, criterion in enumerate(config.criteria)
    }
    return RubricScoreResult(
        reward=reward,
        raw_score=raw_score,
        max_score=max_score,
        passed=reward >= config.passing_reward_threshold,
        field_scores=field_scores,
    )


def compute_rubric_length_penalty(
    answer_length_chars: int, config: RubricLengthPenaltyConfig | None
) -> float:
    """Ramp over ``ramp_percent`` of the penalty-free ``allowed_chars``."""
    if config is None or answer_length_chars <= config.allowed_chars:
        return 0.0
    ramp_chars = config.allowed_chars * config.ramp_percent / 100.0
    overlong_fraction = min(
        (answer_length_chars - config.allowed_chars) / ramp_chars, 1.0
    )
    if config.curve == "power_0_5":
        overlong_fraction = overlong_fraction**0.5
    return config.max_penalty * overlong_fraction


def rubric_criterion_output_config(
    model_params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return rubric_json_schema_output_config(RubricCriterionGraderOutput, model_params)


def rubric_json_schema_output_config(
    output_model: type[BaseModel],
    model_params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    output_config = {
        "format": {
            "type": "json_schema",
            "schema": output_model.model_json_schema(),
        }
    }
    configured_output_config = (model_params or {}).get("output_config")
    if isinstance(configured_output_config, dict):
        output_config.update(
            {
                key: value
                for key, value in configured_output_config.items()
                if key != "format"
            }
        )
    return output_config


def build_rubric_criterion_user_prompt(
    response: str,
    criterion: RubricCriterion,
    criterion_index: int,
) -> str:
    return f"""<response>
{response}
</response>

<criterion index="{criterion_index}">
{criterion.description}
</criterion>

Report met=true exactly when the condition stated in this criterion is true of the response. Report met=false when it is not true. The label describes whether the condition occurred, not whether the response is good overall.

Keep the rationale under 1200 characters."""


def resolve_anthropic_model_name(model_id: str) -> str:
    if model_id.startswith(ANTHROPIC_PROVIDER_PREFIX):
        return model_id[len(ANTHROPIC_PROVIDER_PREFIX) :]
    return model_id


def anthropic_message_text(message: Any) -> str:
    parts: list[str] = []
    for block in getattr(message, "content", None) or []:
        if getattr(block, "type", None) != "text":
            continue
        text = getattr(block, "text", None)
        if isinstance(text, str):
            parts.append(text)
    return "".join(parts)


@dataclass(frozen=True)
class RubricMessageExecutor:
    """Explicit execution boundary for a durable rubric request.

    The attempt is part of the identity: malformed-output retries must request
    a fresh judgment rather than repeatedly reading a cached bad response.
    """

    send: Callable[[dict[str, Any], int], Awaitable[Message]]


async def create_rubric_message(
    client: AsyncAnthropic | RubricMessageExecutor,
    config: RubricGraderConfig,
    user_prompt: str,
    output_config: dict[str, Any] | None = None,
    *,
    attempt: int = 1,
) -> Any:
    kwargs: dict[str, Any] = {
        "model": resolve_anthropic_model_name(config.model_id),
        "max_tokens": DEFAULT_MAX_TOKENS_WITH_THINKING
        if "thinking" in config.model_params
        else DEFAULT_MAX_TOKENS,
        "system": RUBRIC_GRADER_SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": user_prompt}],
        "output_config": output_config
        or rubric_criterion_output_config(config.model_params),
        "timeout": config.model_params.get("timeout", REQUEST_TIMEOUT_SECONDS),
    }
    if "thinking" in config.model_params:
        kwargs["thinking"] = config.model_params["thinking"]
    if isinstance(client, RubricMessageExecutor):
        return await client.send(kwargs, attempt)
    return await client.messages.create(**kwargs)


def parse_rubric_criterion_grader_output(value: Any) -> RubricCriterionGraderOutput:
    if isinstance(value, RubricCriterionGraderOutput):
        return value
    if isinstance(value, dict):
        return RubricCriterionGraderOutput.model_validate(value)
    if isinstance(value, str):
        return RubricCriterionGraderOutput.model_validate_json(value)
    raise ValueError(
        f"expected rubric criterion grader output object or JSON string, got {type(value).__name__}"
    )


def validate_judgment_coverage(
    config: RubricGraderConfig, output: RubricGraderOutput
) -> None:
    """Ensure the model judged exactly the rubric criteria, once each.

    Without this, a model that returns judgments for the wrong/missing indices
    would silently score criteria it never judged as unmet, masking a malformed
    grader response as a legitimate low score.
    """
    expected = set(range(len(config.criteria)))
    seen = [judgment.index for judgment in output.judgments]
    seen_set = set(seen)

    if len(seen) != len(seen_set):
        duplicates = sorted({index for index in seen if seen.count(index) > 1})
        raise ValueError(
            f"rubric grader output has duplicate judgment indices: {duplicates}"
        )

    missing = sorted(expected - seen_set)
    extra = sorted(seen_set - expected)
    if missing or extra:
        raise ValueError(
            f"rubric grader judgment indices {sorted(seen_set)} do not match rubric criteria "
            f"indices {sorted(expected)} (missing={missing}, extra={extra})"
        )


async def grade_rubric_criterion(
    client: AsyncAnthropic | RubricMessageExecutor,
    config: RubricGraderConfig,
    response: str,
    criterion: RubricCriterion,
    criterion_index: int,
    controller: TransientRetryController,
) -> RubricCriterionGradeResult:
    user_prompt = build_rubric_criterion_user_prompt(
        response, criterion, criterion_index
    )
    output_config = rubric_criterion_output_config(config.model_params)
    had_tool_calls = False
    attempts_used = 0
    parse_failures = 0
    transient_attempt = 0

    while True:
        attempts_used += 1
        try:
            message = await controller.send(
                lambda: (
                    create_rubric_message(
                        client,
                        config,
                        user_prompt,
                        output_config,
                        attempt=attempts_used,
                    )
                    if isinstance(client, RubricMessageExecutor)
                    else create_rubric_message(
                        client, config, user_prompt, output_config
                    )
                )
            )
        except (APIStatusError, APIConnectionError) as exc:
            info = classify_transient_error(exc)
            if info is None:
                raise GraderError(
                    f"rubric criterion {criterion_index} grading failed with non-retryable API error: {exc}"
                ) from exc
            await controller.backoff(transient_attempt, info, exc)
            transient_attempt += 1
            continue

        content = anthropic_message_text(message)
        finish_reason = getattr(message, "stop_reason", None)

        try:
            if finish_reason in {"refusal", "max_tokens"}:
                raise ValueError(
                    f"rubric criterion grader model stopped with stop_reason={finish_reason!r}"
                )
            candidate = parse_rubric_criterion_grader_output(content)
        except (ValidationError, ValueError) as exc:
            parse_failures += 1
            if isinstance(exc, RubricGraderOutputParseError):
                parse_error = exc
            else:
                raw_content = content if isinstance(content, str) else repr(content)
                parse_error = RubricGraderOutputParseError(
                    f"could not parse rubric criterion {criterion_index} output after {attempts_used} attempt(s): {exc}\n\n"
                    f"finish_reason={finish_reason!r} had_tool_calls={had_tool_calls}\n"
                    f"raw_content={raw_content[:RAW_CONTENT_DEBUG_LIMIT]}",
                    raw_content=content,
                    finish_reason=finish_reason,
                    had_tool_calls=had_tool_calls,
                )
            if parse_failures >= GRADER_MAX_ATTEMPTS:
                raise parse_error from exc
            await asyncio.sleep(retry_backoff_seconds(parse_failures - 1))
            continue

        return RubricCriterionGradeResult(
            judgment=RubricCriterionJudgment(
                index=criterion_index,
                met=candidate.met,
                rationale=candidate.rationale,
            ),
            attempts_used=attempts_used,
            finish_reason=finish_reason,
        )


class RubricGrader:
    async def evaluate_answer_llm(
        self,
        agent_answer: dict,
        config: dict,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        message_executor: RubricMessageExecutor | None = None,
    ) -> GraderResult:
        """Grade ``agent_answer`` against a rubric via the Anthropic Messages API.

        When ``api_key`` / ``base_url`` are ``None``, the Anthropic client uses
        its standard environment configuration.
        """
        parsed_config = RubricGraderConfig.model_validate(config)
        steps = multistep_answer_steps(agent_answer, parsed_config)
        if steps is not None:
            return await grade_multistep_rubric(
                agent_answer,
                parsed_config,
                steps,
                api_key=api_key,
                base_url=base_url,
                message_executor=message_executor,
            )
        answer, found = get_nested_value(agent_answer, parsed_config.answer_field)
        if not found:
            return GraderResult(
                passed=False,
                metrics={"answer_field": parsed_config.answer_field},
                reasoning=f"Rubric: FAIL\n\n  x Agent answer missing required field: {parsed_config.answer_field}",
                agent_answer=agent_answer,
                score=0.0,
                field_scores={},
            )

        full_response = str(answer)
        response = full_response[: parsed_config.truncation_length]
        client_kwargs: dict[str, Any] = {}
        if api_key is not None:
            client_kwargs["api_key"] = api_key
        if base_url is not None:
            client_kwargs["base_url"] = base_url
        # max_retries=0: the TransientRetryController owns the whole retry
        # policy; the SDK's hidden inner retries would multiply attempts and
        # defeat the shared backoff budget.
        client = (
            message_executor
            if message_executor is not None
            else AsyncAnthropic(max_retries=0, **client_kwargs)
        )

        controller = TransientRetryController()
        settled = await asyncio.gather(
            *(
                grade_rubric_criterion(
                    client,
                    parsed_config,
                    response,
                    criterion,
                    criterion_index,
                    controller,
                )
                for criterion_index, criterion in enumerate(parsed_config.criteria)
            ),
            return_exceptions=True,
        )
        errors = [item for item in settled if isinstance(item, BaseException)]
        if errors:
            for error in errors:
                if isinstance(error, GraderTransientError):
                    raise error
            for error in errors:
                if isinstance(error, GraderError):
                    raise error
            raise errors[0]
        criterion_results = [
            item for item in settled if isinstance(item, RubricCriterionGradeResult)
        ]
        output = RubricGraderOutput(
            judgments=[
                result.judgment
                for result in sorted(
                    criterion_results, key=lambda result: result.judgment.index
                )
            ]
        )
        validate_judgment_coverage(parsed_config, output)

        score_result = compute_rubric_reward(parsed_config, output)
        base_reward = score_result.reward
        length_penalty = compute_rubric_length_penalty(
            len(full_response), parsed_config.length_penalty
        )
        if parsed_config.length_penalty is not None:
            adjusted_reward = max(0.0, base_reward - length_penalty)
            length_penalty_applied = base_reward - adjusted_reward
            score_result = score_result.model_copy(
                update={
                    "reward": adjusted_reward,
                    "passed": adjusted_reward >= parsed_config.passing_reward_threshold,
                }
            )
        else:
            length_penalty_applied = 0.0

        criterion_parse_attempts = {
            f"criterion_{result.judgment.index}": result.attempts_used
            for result in criterion_results
        }
        finish_reasons = {
            f"criterion_{result.judgment.index}": result.finish_reason
            for result in criterion_results
        }
        metrics = {
            "answer_field": parsed_config.answer_field,
            "model_id": parsed_config.model_id,
            "model_params": parsed_config.model_params,
            "truncation_length": parsed_config.truncation_length,
            "passing_reward_threshold": parsed_config.passing_reward_threshold,
            "raw_score": score_result.raw_score,
            "max_score": score_result.max_score,
            "reward": score_result.reward,
            "parse_attempts": sum(criterion_parse_attempts.values()),
            "criterion_parse_attempts": criterion_parse_attempts,
            "finish_reason": finish_reasons,
            "grading_transport": "inference_queue"
            if message_executor is not None
            else "anthropic_api",
            "judgments": [
                judgment.model_dump(mode="json") for judgment in output.judgments
            ],
        }
        if parsed_config.length_penalty is not None:
            metrics.update(
                {
                    "answer_length_chars": len(full_response),
                    "length_penalty_config": parsed_config.length_penalty.model_dump(),
                    "length_penalty_applied": length_penalty_applied,
                    "reward_before_length_penalty": base_reward,
                }
            )
        return GraderResult(
            passed=score_result.passed,
            metrics=metrics,
            reasoning=format_rubric_reasoning(
                parsed_config,
                output,
                score_result,
                answer_length_chars=len(full_response),
                length_penalty_applied=length_penalty_applied,
            ),
            agent_answer=agent_answer,
            score=score_result.reward,
            field_scores=score_result.field_scores,
        )


_STEP_KEY_RE = re.compile(r"^step_(\d+)$")


def multistep_answer_steps(
    agent_answer: dict, config: RubricGraderConfig
) -> list[tuple[int, Any]] | None:
    """Return the ordered ``(step, answer)`` pairs of a multistep answer, or ``None``.

    A multistep answer is a dict whose keys are all ``step_<k>``; the values are
    that step's answer object (``None`` for a step that was never submitted).
    A rubric whose criteria name ``steps_applied`` against a flat answer is
    graded as step 0 only, so a single-step rollout of a multistep eval still
    scores.
    """
    if not isinstance(agent_answer, dict) or len(agent_answer) == 0:
        return None
    matches = [
        (_STEP_KEY_RE.match(str(key)), value) for key, value in agent_answer.items()
    ]
    if all(match is not None for match, _ in matches):
        return sorted((int(match.group(1)), value) for match, value in matches)  # type: ignore[union-attr]
    if any(criterion.steps_applied is not None for criterion in config.criteria):
        return [(0, agent_answer)]
    return None


class RubricStepGrade(BaseModel):
    model_config = ConfigDict(frozen=True)

    step: int
    graded: bool
    note: str = ""
    reward: float = 0.0
    raw_score: float = 0.0
    max_score: float = 0.0
    passed: bool = False
    answer_length_chars: int = 0
    length_penalty_applied: float = 0.0
    judgments: list[RubricCriterionJudgment] = Field(default_factory=list)
    criterion_parse_attempts: dict[str, int] = Field(default_factory=dict)
    finish_reasons: dict[str, Any] = Field(default_factory=dict)


def _rubric_client(
    api_key: str | None,
    base_url: str | None,
    message_executor: RubricMessageExecutor | None,
) -> AsyncAnthropic | RubricMessageExecutor:
    if message_executor is not None:
        return message_executor
    client_kwargs: dict[str, Any] = {}
    if api_key is not None:
        client_kwargs["api_key"] = api_key
    if base_url is not None:
        client_kwargs["base_url"] = base_url
    return AsyncAnthropic(max_retries=0, **client_kwargs)


async def grade_rubric_step(
    client: AsyncAnthropic | RubricMessageExecutor,
    config: RubricGraderConfig,
    step: int,
    step_answer: Any,
    controller: TransientRetryController,
) -> RubricStepGrade:
    """Grade one step of a multistep answer against the criteria that apply at it.

    Mirrors the single-step scoring: met deltas over positive deltas, clamped
    to [0, 1], passing at the rubric threshold. A step with no positive
    criterion is not graded; a step with no recorded answer scores 0 without a
    judge call.
    """
    applicable = [
        (index, criterion)
        for index, criterion in enumerate(config.criteria)
        if criterion.applies_at(step)
    ]
    max_score = sum(c.score_delta for _, c in applicable if c.score_delta > 0)
    if max_score <= 0:
        return RubricStepGrade(
            step=step, graded=False, note="no positive criterion applies"
        )
    if isinstance(step_answer, dict):
        answer, found = get_nested_value(step_answer, config.answer_field)
    else:
        answer, found = None, False
    if not found or answer is None or str(answer).strip() == "":
        return RubricStepGrade(
            step=step,
            graded=True,
            note="no recorded answer",
            max_score=max_score,
            passed=0.0 >= config.passing_reward_threshold,
        )
    full_response = str(answer)
    response = full_response[: config.truncation_length]
    settled = await asyncio.gather(
        *(
            grade_rubric_criterion(
                client, config, response, criterion, index, controller
            )
            for index, criterion in applicable
        ),
        return_exceptions=True,
    )
    errors = [item for item in settled if isinstance(item, BaseException)]
    if errors:
        for error in errors:
            if isinstance(error, GraderTransientError):
                raise error
        for error in errors:
            if isinstance(error, GraderError):
                raise error
        raise errors[0]
    results = sorted(
        (item for item in settled if isinstance(item, RubricCriterionGradeResult)),
        key=lambda result: result.judgment.index,
    )
    met_by_index = {result.judgment.index: result.judgment.met for result in results}
    raw_score = sum(c.score_delta for i, c in applicable if met_by_index.get(i) is True)
    reward = min(max(raw_score / max_score, 0.0), 1.0)
    length_penalty_applied = 0.0
    if config.length_penalty is not None:
        penalty = compute_rubric_length_penalty(
            len(full_response), config.length_penalty
        )
        adjusted = max(0.0, reward - penalty)
        length_penalty_applied = reward - adjusted
        reward = adjusted
    return RubricStepGrade(
        step=step,
        graded=True,
        reward=reward,
        raw_score=raw_score,
        max_score=max_score,
        passed=reward >= config.passing_reward_threshold,
        answer_length_chars=len(full_response),
        length_penalty_applied=length_penalty_applied,
        judgments=[result.judgment for result in results],
        criterion_parse_attempts={
            f"criterion_{r.judgment.index}": r.attempts_used for r in results
        },
        finish_reasons={
            f"criterion_{r.judgment.index}": r.finish_reason for r in results
        },
    )


async def grade_multistep_rubric(
    agent_answer: dict,
    config: RubricGraderConfig,
    steps: list[tuple[int, Any]],
    *,
    api_key: str | None = None,
    base_url: str | None = None,
    message_executor: RubricMessageExecutor | None = None,
) -> GraderResult:
    """Grade a ``step_<k>``-keyed answer: every step scored on its own, mean reward.

    The reward is the mean over graded steps (a step with no applicable
    positive criterion is skipped, as in Harbor's ``mean`` strategy) and the
    rubric passes only when every graded step passes.
    """
    client = _rubric_client(api_key, base_url, message_executor)
    controller = TransientRetryController()
    # Every step is queued in one pass. Under the queued transport a step whose
    # criteria are still pending raises GradingPending, so awaiting the steps in
    # order enqueued step 0 alone and aborted the grade before the rest of the
    # loop ran: one judge round trip per step instead of one for the answer. The
    # shared controller still serializes every criterion once a step hits rate
    # pressure, so widening the fan-out cannot outrun the backoff.
    settled = await asyncio.gather(
        *(
            grade_rubric_step(client, config, step, step_answer, controller)
            for step, step_answer in steps
        ),
        return_exceptions=True,
    )
    errors = [item for item in settled if isinstance(item, BaseException)]
    if errors:
        for error in errors:
            if isinstance(error, GraderTransientError):
                raise error
        for error in errors:
            if isinstance(error, GraderError):
                raise error
        raise errors[0]
    grades = [item for item in settled if isinstance(item, RubricStepGrade)]
    graded = [grade for grade in grades if grade.graded]
    if not graded:
        return GraderResult(
            passed=False,
            metrics={"answer_field": config.answer_field, "multistep": {"steps": {}}},
            reasoning="Rubric: FAIL\n\n  x No step has a criterion that applies to it",
            agent_answer=agent_answer,
            score=0.0,
            field_scores={},
        )
    reward = sum(grade.reward for grade in graded) / len(graded)
    passed = all(grade.passed for grade in graded)
    field_scores: dict[str, float] = {}
    judgments: list[dict[str, Any]] = []
    for grade in graded:
        met = {judgment.index: judgment.met for judgment in grade.judgments}
        for index, criterion in enumerate(config.criteria):
            if criterion.applies_at(grade.step):
                field_scores[f"step_{grade.step}.criterion_{index}"] = (
                    criterion.score_delta if met.get(index) is True else 0.0
                )
        judgments.extend(
            {"step": grade.step, **judgment.model_dump(mode="json")}
            for judgment in grade.judgments
        )
    metrics = {
        "answer_field": config.answer_field,
        "model_id": config.model_id,
        "model_params": config.model_params,
        "truncation_length": config.truncation_length,
        "passing_reward_threshold": config.passing_reward_threshold,
        "reward": reward,
        "parse_attempts": sum(
            sum(grade.criterion_parse_attempts.values()) for grade in graded
        ),
        "grading_transport": "inference_queue"
        if message_executor is not None
        else "anthropic_api",
        "judgments": judgments,
        "multistep": {
            "strategy": "mean",
            "steps": {
                f"step_{grade.step}": grade.model_dump(mode="json", exclude={"step"})
                for grade in grades
            },
        },
    }
    return GraderResult(
        passed=passed,
        metrics=metrics,
        reasoning=format_multistep_rubric_reasoning(config, grades, reward, passed),
        agent_answer=agent_answer,
        score=reward,
        field_scores=field_scores,
    )


def format_multistep_rubric_reasoning(
    config: RubricGraderConfig,
    grades: list[RubricStepGrade],
    reward: float,
    passed: bool,
) -> str:
    lines = [
        f"Rubric: {'PASS' if passed else 'FAIL'}",
        f"  reward: {reward:.4f} (mean over graded steps; every graded step must pass)",
    ]
    for grade in grades:
        if not grade.graded:
            lines.append(f"  step {grade.step}: not graded ({grade.note})")
            continue
        verdict = "PASS" if grade.passed else "FAIL"
        lines.append(
            f"  step {grade.step}: {verdict} reward={grade.reward:.4f} "
            f"(raw_score={grade.raw_score}, max_score={grade.max_score})"
        )
        if grade.note:
            lines.append(f"      {grade.note}")
        by_index = {judgment.index: judgment for judgment in grade.judgments}
        for index, criterion in enumerate(config.criteria):
            if not criterion.applies_at(grade.step):
                continue
            judgment = by_index.get(index)
            marker = "+" if judgment is not None and judgment.met else "x"
            lines.append(
                f"    {marker} [{index}] {criterion.description} (delta={criterion.score_delta})"
            )
            if judgment is not None and judgment.rationale:
                lines.append(f"        rationale: {judgment.rationale}")
    return "\n".join(lines)


def format_rubric_reasoning(
    config: RubricGraderConfig,
    output: RubricGraderOutput,
    score_result: RubricScoreResult,
    *,
    answer_length_chars: int | None = None,
    length_penalty_applied: float = 0.0,
) -> str:
    verdict = "PASS" if score_result.passed else "FAIL"
    lines = [
        f"Rubric: {verdict}",
        f"  reward: {score_result.reward:.4f} (raw_score={score_result.raw_score}, max_score={score_result.max_score})",
    ]
    if config.length_penalty is not None:
        lines.append(
            f"  length penalty: {length_penalty_applied:.4f} "
            f"(answer_length_chars={answer_length_chars})"
        )
    judgments_by_index = {judgment.index: judgment for judgment in output.judgments}
    for index, criterion in enumerate(config.criteria):
        judgment = judgments_by_index.get(index)
        met = judgment.met if judgment is not None else False
        marker = "+" if met else "x"
        rationale = "" if judgment is None else judgment.rationale
        lines.append(
            f"  {marker} [{index}] {criterion.description} (delta={criterion.score_delta})"
        )
        if rationale:
            lines.append(f"      rationale: {rationale}")
    return "\n".join(lines)
