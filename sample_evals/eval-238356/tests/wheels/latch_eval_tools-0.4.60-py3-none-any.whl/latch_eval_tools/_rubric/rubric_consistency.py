"""Repeat rubric judgments for one rollout during eval review QC."""

from __future__ import annotations

import re
from dataclasses import dataclass
from html import escape
from typing import Annotated, Any, Literal, Self

from .base import get_nested_value
from .rubric import RubricGraderConfig, multistep_answer_steps
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    field_validator,
    model_serializer,
    model_validator,
)


RUBRIC_CONSISTENCY_CHECK_KEY = "rubric_consistency"
RUBRIC_CONSISTENCY_DISPLAY_NAME = "Rubric Grader Consistency"
RUBRIC_CONSISTENCY_VERSION = 3
DEFAULT_RUBRIC_CONSISTENCY_REPETITIONS = 10  # Per judge, per captured answer.
MAX_RUBRIC_CONSISTENCY_REPETITIONS = 100
# Admit the entire default panel at once. Larger custom panels keep a bounded
# durable window across polls; inference workers cap actual provider concurrency.
# This is execution policy, so changing it preserves config hashes and queued work.
MAX_PENDING_REPETITIONS_PER_JUDGE = 10
# Historical results used three runs. Increasing the execution default must not
# make those persisted results unreadable.
MIN_HISTORICAL_RUBRIC_CONSISTENCY_RUNS = 3


class RubricConsistencyJudge(BaseModel):
    """Judge settings recorded with rubric-consistency evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    model_id: Literal[
        "anthropic/claude-opus-5-5",
        "anthropic/claude-sonnet-5-5",
        "anthropic/claude-haiku-5-5",
        "gemini/gemini-3.8-flash",
        "openai/gpt-6.1-terra",
    ]
    temperature: float | None = Field(
        default=None,
        ge=0,
        le=1,
        allow_inf_nan=False,
        description="Historical evidence only; omit when configuring a run profile.",
    )
    reasoning_effort: Literal["medium", "high"] | None = Field(
        default=None,
        description="Omit to use this judge's platform-default effort.",
    )

    @model_validator(mode="after")
    def supported_settings(self) -> Self:
        # Claude and Terra cannot accept sampling overrides in these modes.
        # Retain Gemini's field for reading historical temperature=0 evidence;
        # the current panel omits it because Gemini 3.8 ignores this parameter.
        if not self.model_id.startswith("gemini/") and self.temperature is not None:
            raise ValueError(
                "Claude and Terra use provider-default sampling; omit temperature"
            )
        return self


# Sampling is provider-controlled for all three models, as in the production
# panel. Gemini 3.8 deprecated temperature; sending 0 does not pin sampling.
# https://ai.google.dev/gemini-api/docs/whats-new-gemini-3.8
DEFAULT_RUBRIC_CONSISTENCY_JUDGES = (
    RubricConsistencyJudge(
        model_id="anthropic/claude-sonnet-5-5", reasoning_effort="medium"
    ),
    RubricConsistencyJudge(
        model_id="gemini/gemini-3.8-flash", reasoning_effort="medium"
    ),
    RubricConsistencyJudge(model_id="openai/gpt-6.1-terra", reasoning_effort="medium"),
)


class RubricConsistencySettings(BaseModel):
    """Profile inputs resolved to an explicit, bounded inference policy."""

    repetitions: int = Field(
        default=DEFAULT_RUBRIC_CONSISTENCY_REPETITIONS,
        strict=True,
        ge=MIN_HISTORICAL_RUBRIC_CONSISTENCY_RUNS,
        le=MAX_RUBRIC_CONSISTENCY_REPETITIONS,
        description="Grader repetitions per judge for each captured rollout answer.",
    )
    judges: list[RubricConsistencyJudge] = Field(
        default_factory=lambda: list(DEFAULT_RUBRIC_CONSISTENCY_JUDGES),
        min_length=1,
        max_length=len(DEFAULT_RUBRIC_CONSISTENCY_JUDGES),
        description=(
            "Judges to run and their reasoning efforts. Omit the list to use the "
            "platform panel; omit an effort to use that judge's platform default."
        ),
        json_schema_extra={
            "default": [
                judge.model_dump(mode="json", exclude={"temperature"})
                for judge in DEFAULT_RUBRIC_CONSISTENCY_JUDGES
            ]
        },
    )

    @field_validator("judges")
    @classmethod
    def resolve_judges(
        cls, judges: list[RubricConsistencyJudge]
    ) -> list[RubricConsistencyJudge]:
        if len({judge.model_id for judge in judges}) != len(judges):
            raise ValueError("rubric consistency judges must use distinct models")
        defaults = {
            judge.model_id: judge.reasoning_effort
            for judge in DEFAULT_RUBRIC_CONSISTENCY_JUDGES
        }
        resolved: list[RubricConsistencyJudge] = []
        for judge in judges:
            if judge.temperature is not None:
                raise ValueError(
                    "rubric consistency uses provider-default sampling; omit temperature"
                )
            # Judges outside the default panel use the panel's effort.
            resolved.append(
                judge.model_copy(
                    update={
                        "reasoning_effort": defaults.get(judge.model_id, "medium")
                    }
                )
                if judge.reasoning_effort is None
                else judge
            )
        return resolved

    @property
    def total_repetitions(self) -> int:
        return self.repetitions * len(self.judges)


class RubricCriterionJudgment(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    index: int = Field(ge=0)
    met: bool
    rationale: str = ""
    # Set only for multistep answers, where a criterion is judged once per step.
    step: int | None = Field(default=None, ge=0)

    @field_validator("rationale", mode="before")
    @classmethod
    def normalize_rationale(cls, value: Any) -> str:
        return value if isinstance(value, str) else ""

    @model_serializer(mode="wrap")
    def omit_missing_step(self, handler: SerializerFunctionWrapHandler) -> Any:
        data = handler(self)
        if self.step is None:
            data.pop("step", None)
        return data

    @property
    def key(self) -> tuple[int, int]:
        return (-1 if self.step is None else self.step, self.index)

    @property
    def label(self) -> str:
        return "" if self.step is None else f"step_{self.step}"


class RubricConsistencyRun(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    judge_model: str | None = None
    iteration: int | None = Field(default=None, ge=1)
    temperature: float | None = None
    passed: bool
    score: float = Field(allow_inf_nan=False)
    judgments: list[RubricCriterionJudgment]

    @model_validator(mode="after")
    def validate_unique_indices(self) -> Self:
        if len({item.key for item in self.judgments}) != len(self.judgments):
            raise ValueError("rubric QC criterion judgments contain duplicate indices")
        return self

    @classmethod
    def from_grader_result(
        cls, result: dict[str, Any], *, expected: set[tuple[int, int]]
    ) -> Self:
        metrics = result.get("metrics")
        if not isinstance(metrics, dict):
            raise ValueError("rubric QC grader result is missing a metrics object")
        errors = [
            f"{key}: {metrics[key]}"
            for key in ("grader_error", "configuration_error")
            if metrics.get(key) is not None
        ]
        if errors or metrics.get("grader_system_error") is True:
            detail = (
                "; ".join(errors)
                or "grader_system_error=true (no error detail returned)"
            )
            raise ValueError(f"rubric QC received a failed grader result: {detail}")
        judgments = metrics.get("judgments")
        if judgments is None and not expected:
            judgments = []
        run = cls.model_validate(
            {
                "passed": result.get("passed"),
                "score": result.get("score"),
                "judgments": judgments,
            }
        )
        if {item.key for item in run.judgments} != expected:
            raise ValueError("rubric QC criterion judgment coverage is incomplete")
        run.judgments.sort(key=lambda item: item.key)
        return run


class RubricCriterionDisagreement(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    index: int = Field(ge=0)
    description: str = ""
    step: int | None = None
    failure_types: list[Literal["within_model", "between_models"]] = Field(
        default_factory=list
    )


class RubricGraderConsistency(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)

    path: str
    answer_field: str
    runs: list[RubricConsistencyRun] = Field(
        min_length=MIN_HISTORICAL_RUBRIC_CONSISTENCY_RUNS
    )
    differing_criterion_indices: list[Annotated[int, Field(ge=0)]]
    # Version 1 evidence predates the criterion descriptions.
    differing_criteria: list[RubricCriterionDisagreement] = Field(default_factory=list)
    outcome_changed: bool

    @property
    def inconsistent(self) -> bool:
        return bool(self.differing_criterion_indices) or self.outcome_changed

    @property
    def difference_description(self) -> str:
        if self.differing_criterion_indices:
            return f"{self.path} criteria {_criterion_list(self.differing_criterion_indices)}"
        return f"{self.path} score/pass"

    @classmethod
    def from_runs(
        cls,
        *,
        path: str,
        answer_field: str,
        criteria: list[Any],
        runs: list[RubricConsistencyRun],
    ) -> Self:
        decisions: dict[tuple[int, int], set[bool]] = {}
        for run in runs:
            for judgment in run.judgments:
                decisions.setdefault(judgment.key, set()).add(judgment.met)
        indices = sorted(
            {key[1] for key, values in decisions.items() if len(values) > 1}
        )
        return cls(
            path=path,
            answer_field=answer_field,
            runs=runs,
            differing_criterion_indices=indices,
            differing_criteria=[
                RubricCriterionDisagreement(
                    index=index,
                    step=None if step == -1 else step,
                    description=criteria[index].get("description", "")
                    if isinstance(criteria[index], dict)
                    else "",
                    failure_types=criterion_failure_types(runs, (step, index)),
                )
                for (step, index), values in sorted(decisions.items())
                if len(values) > 1
            ],
            outcome_changed=len({(run.passed, run.score) for run in runs}) > 1,
        )

    def synthesis_payload(self, *, include_path: bool) -> dict[str, Any]:
        """Keep only divergent judgments and use one-based numbers for the reviewer."""
        payload: dict[str, Any] = {
            "differing_criterion_numbers": [
                i + 1 for i in self.differing_criterion_indices
            ],
            "differing_criteria": [
                {"criterion_number": item.index + 1, "description": item.description}
                for item in self.differing_criteria
            ],
            "outcome_changed": self.outcome_changed,
            "runs": [
                {
                    "passed": run.passed,
                    "score": run.score,
                    "judgments": [
                        {
                            "criterion_number": item.index + 1,
                            **({} if item.step is None else {"step": item.label}),
                            "met": item.met,
                            "rationale": item.rationale,
                        }
                        for item in run.judgments
                        if item.index in self.differing_criterion_indices
                    ],
                }
                for run in self.runs
            ],
        }
        if include_path:
            payload["path"] = self.path
        return payload


def criterion_failure_types(
    runs: list[RubricConsistencyRun], key: tuple[int, int]
) -> list[Literal["within_model", "between_models"]]:
    decisions: dict[str | None, set[bool]] = {}
    for run in runs:
        for judgment in run.judgments:
            if judgment.key == key:
                decisions.setdefault(run.judge_model, set()).add(judgment.met)
    failures: list[Literal["within_model", "between_models"]] = []
    if any(len(values) > 1 for values in decisions.values()):
        failures.append("within_model")
    # Cross-model disagreement is present whenever two different judges recorded
    # opposing decisions, including when one of those judges also varies internally.
    if any(
        left_model != right_model and any(a != b for a in left for b in right)
        for left_model, left in decisions.items()
        for right_model, right in decisions.items()
    ):
        failures.append("between_models")
    return failures


class RubricConsistencyEvidence(BaseModel):
    """Persisted QC evidence, shared by cache reuse, checks, and synthesis."""

    model_config = ConfigDict(extra="ignore", strict=True)

    version: int
    repetitions: int = Field(ge=MIN_HISTORICAL_RUBRIC_CONSISTENCY_RUNS)
    status: Literal["CONSISTENT", "INCONSISTENT"]
    graders: list[RubricGraderConsistency]
    judges: list[RubricConsistencyJudge] | None = None
    rollout_execution_id: int | None = None
    answer_hash: str | None = None
    rubric_specs_hash: str | None = None

    def matches_cache(
        self,
        *,
        repetitions: int,
        rollout_execution_id: int | None,
        answer_hash: str,
        rubric_specs_hash: str,
        grader_paths: list[str],
        judges: list[RubricConsistencyJudge] | None = None,
    ) -> bool:
        return (
            self.version == RUBRIC_CONSISTENCY_VERSION
            and self.repetitions == repetitions
            and self.judges == judges
            and self.rollout_execution_id == rollout_execution_id
            and self.answer_hash == answer_hash
            and self.rubric_specs_hash == rubric_specs_hash
            and [grader.path for grader in self.graders] == grader_paths
            and all(len(grader.runs) == repetitions for grader in self.graders)
            and (
                judges is None
                or all(
                    sorted(
                        (run.judge_model, run.iteration)
                        for run in grader.runs
                        if run.judge_model is not None and run.iteration is not None
                    )
                    == sorted(
                        (judge.model_id, iteration)
                        for judge in judges
                        for iteration in range(1, repetitions // len(judges) + 1)
                    )
                    for grader in self.graders
                )
            )
        )

    def synthesis_payload(self, *, include_paths: bool) -> dict[str, Any]:
        return {
            "status": self.status,
            "repetitions": self.repetitions,
            "graders": [
                grader.synthesis_payload(include_path=include_paths)
                for grader in self.graders
            ],
        }


@dataclass(frozen=True)
class RolloutRubricConsistency:
    rollout: str
    evidence: RubricConsistencyEvidence

    @classmethod
    def from_review(cls, review: dict[str, Any], *, position: int) -> Self | None:
        evidence = review.get("rubric_consistency")
        if not isinstance(evidence, dict):
            return None
        rollout = review.get("slot") or review.get("review_key")
        if not isinstance(rollout, str) or not rollout:
            rollout = f"rollout_{position}"
        return cls(rollout, RubricConsistencyEvidence.model_validate(evidence))


def rubric_grader_specs(eval_json: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    """Find rubric leaves in either grader shape, including composite children."""
    found: list[tuple[str, dict[str, Any]]] = []

    def visit(path: str, spec: Any) -> None:
        if not isinstance(spec, dict):
            return
        if spec.get("type") == "rubric":
            found.append((path, spec))
            return
        if spec.get("type") not in {"all_of", "average_of", "composite"}:
            return
        config = spec.get("config")
        children = config.get("children") if isinstance(config, dict) else None
        if isinstance(children, list):
            for index, child in enumerate(children):
                visit(f"{path}.config.children[{index}]", child)

    graders = eval_json.get("graders")
    if isinstance(graders, list):
        for index, spec in enumerate(graders):
            visit(f"graders[{index}]", spec)
    else:
        visit("grader", eval_json.get("grader"))
    return found


def _expected_judgment_keys(
    answer: dict[str, Any], config: dict[str, Any]
) -> set[tuple[int, int]]:
    """The (step, criterion) judgments the rubric grader must return for this answer.

    Mirrors the grader: a flat answer judges every criterion once (step -1) when the
    field is present; a step-keyed answer judges, per step, the criteria that apply
    at it, skipping steps with no positive criterion or no recorded answer.
    """
    parsed = RubricGraderConfig.model_validate(config)
    steps = multistep_answer_steps(answer, parsed)
    if steps is None:
        _value, found = get_nested_value(answer, parsed.answer_field)
        return (
            {(-1, index) for index in range(len(parsed.criteria))} if found else set()
        )
    expected: set[tuple[int, int]] = set()
    for step, step_answer in steps:
        applicable = [
            index
            for index, criterion in enumerate(parsed.criteria)
            if criterion.applies_at(step)
        ]
        if not any(parsed.criteria[index].score_delta > 0 for index in applicable):
            continue
        if not isinstance(step_answer, dict):
            continue
        value, found = get_nested_value(step_answer, parsed.answer_field)
        if not found or value is None or str(value).strip() == "":
            continue
        expected.update((step, index) for index in applicable)
    return expected


def rubric_consistency_check(evidence: RubricConsistencyEvidence) -> dict[str, str]:
    inconsistent = evidence.status == "INCONSISTENT"
    differences = [
        grader.difference_description
        for grader in evidence.graders
        if grader.differing_criterion_indices
    ]
    differences.extend(
        grader.difference_description
        for grader in evidence.graders
        if grader.outcome_changed and not grader.differing_criterion_indices
    )
    finding = (
        _rubric_disagreement_lead([evidence])
        if inconsistent
        else (
            f"All criterion decisions agreed across {evidence.repetitions} grader runs "
            "on the same captured answer."
        )
    )
    detail = (
        "; ".join(differences) if differences else "All criterion judgments agreed."
    )
    return {
        "check_key": RUBRIC_CONSISTENCY_CHECK_KEY,
        "display_name": RUBRIC_CONSISTENCY_DISPLAY_NAME,
        "status": "FAIL" if inconsistent else "PASS",
        "severity": "error" if inconsistent else "none",
        "finding": finding,
        "evidence": f"{evidence.repetitions} grader runs on the same captured answer: {detail}",
        "detailed_analysis": rubric_consistency_analysis(evidence),
    }


def _literal_markdown(value: str, *, blockquote: bool = False) -> str:
    """Escape recorded text, optionally displaying it as a multiline quotation."""
    text = re.sub(r"([\\`*_\[\]{}()!#$|~+.-])", r"\\\1", escape(value, quote=False))
    return "\n".join(f"> {line}" for line in text.splitlines()) if blockquote else text


def rubric_consistency_analysis(evidence: RubricConsistencyEvidence) -> str:
    """Build expanded QC evidence: criterion text, every decision, and every rationale."""
    sections = [
        f"{evidence.repetitions} grader runs evaluated the same captured answer "
        "with the same rubric configuration."
    ]
    for grader in evidence.graders:
        descriptions = {
            item.index: item.description for item in grader.differing_criteria
        }
        for index in grader.differing_criterion_indices:
            label = f"Criterion {index + 1}"
            if len(evidence.graders) > 1:
                label += f" ({grader.path})"
            sections.append(f"### {_literal_markdown(label)}")
            description = descriptions.get(index, "")
            if description:
                sections.append(_literal_markdown(description, blockquote=True))
            judgments = [
                (number, judgment)
                for number, run in enumerate(grader.runs, start=1)
                for judgment in run.judgments
                if judgment.index == index
            ]
            decisions = " · ".join(
                f"{_run_label(number, judgment)}: {'Met' if judgment.met else 'Not met'}"
                for number, judgment in judgments
            )
            sections.append(f"**Grader decisions:** {decisions}")
            for met in (True, False):
                sections.append(
                    f"**{'Met' if met else 'Not met'} — recorded rationales**"
                )
                for number, judgment in judgments:
                    if judgment.met != met:
                        continue
                    sections.append(f"**{_run_label(number, judgment)}**")
                    sections.append(
                        _literal_markdown(judgment.rationale, blockquote=True)
                        if judgment.rationale.strip()
                        else "Rationale not recorded."
                    )
        if grader.outcome_changed:
            sections.append(
                f"### Score and pass decisions ({_literal_markdown(grader.path)})"
            )
            sections.append(
                "\n".join(
                    f"- Grader run {number}: score {run.score:g}; "
                    f"{'passed' if run.passed else 'did not pass'}."
                    for number, run in enumerate(grader.runs, start=1)
                )
            )
    if evidence.status == "CONSISTENT":
        sections.append(
            "All recorded criterion decisions agreed. Agreement shows repeatability, "
            "not correctness."
        )
    return "\n\n".join(sections)


def _run_label(number: int, judgment: RubricCriterionJudgment) -> str:
    if judgment.step is None:
        return f"Grader run {number}"
    return f"Grader run {number}, {judgment.label}"


def _criterion_list(indices: list[int]) -> str:
    numbers = [str(index + 1) for index in sorted(set(indices))]
    return _readable_list(numbers)


def _readable_list(items: list[str]) -> str:
    if len(items) == 1:
        return items[0]
    if len(items) == 2:
        return " and ".join(items)
    return f"{', '.join(items[:-1])}, and {items[-1]}"


def _rubric_disagreement_lead(evidence: list[RubricConsistencyEvidence]) -> str:
    indices_by_path: dict[str, set[int]] = {}
    outcome_only_paths: set[str] = set()
    for consistency in evidence:
        for grader in consistency.graders:
            indices_by_path.setdefault(grader.path, set()).update(
                grader.differing_criterion_indices
            )
            if grader.outcome_changed and not grader.differing_criterion_indices:
                outcome_only_paths.add(grader.path)
    active_paths = [path for path, indices in indices_by_path.items() if indices]
    repetitions = {item.repetitions for item in evidence}
    answer = "answer was" if len(evidence) == 1 else "answers were"
    comparison = (
        f"when the same captured {answer} graded {next(iter(repetitions))} times"
        if len(repetitions) == 1
        else "across repeated grader runs on the same captured answers"
    )
    if active_paths:
        criterion_count = sum(len(indices) for indices in indices_by_path.values())
        noun = "Criterion" if criterion_count == 1 else "Criteria"
        groups = []
        for path in sorted(active_paths):
            label = _criterion_list(list(indices_by_path[path]))
            if len(indices_by_path) > 1:
                label += f" ({path})"
            groups.append(label)
        return (
            f"{noun} {_readable_list(groups)} received inconsistent judgments "
            f"{comparison}."
        )
    if outcome_only_paths:
        return f"Rubric scores or pass decisions differed {comparison}."
    return f"Rubric judgments differed {comparison}."


def _criterion_summary_bullets(
    reviews: list[RolloutRubricConsistency],
    synthesis: str,
    *,
    include_paths: bool,
) -> list[str]:
    """Summarize each disagreement and affected rollouts, falling back to recorded reasons."""
    affected: dict[tuple[str, int], list[tuple[str, RubricGraderConsistency]]] = {}
    for review in reviews:
        rollout = re.sub(r"^rollout_(\d+)\Z", r"Agent rollout \1", review.rollout)
        if not rollout.lower().startswith("agent rollout "):
            rollout = f"Agent rollout {rollout}"
        for grader in review.evidence.graders:
            for index in grader.differing_criterion_indices:
                affected.setdefault((grader.path, index), []).append((rollout, grader))

    # Only attribute a synthesis bullet when its criterion and optional path are unambiguous.
    explanations: dict[tuple[str, int], str] = {}
    for line in synthesis.strip().splitlines():
        match = re.match(r"^- Criterion (\d+)(?: \(([^)]+)\))?:\s*(.*)$", line)
        if match is None:
            continue
        number, path, explanation = match.groups()
        candidates = [
            key
            for key in affected
            if key[1] == int(number) - 1 and (path is None or key[0] == path)
        ]
        if len(candidates) == 1 and explanation.strip():
            explanations[candidates[0]] = explanation.strip()

    bullets = []
    for path, index in sorted(affected, key=lambda key: (key[1], key[0])):
        label = f"Criterion {index + 1}"
        if include_paths:
            label += f" ({path})"
        instances = affected[(path, index)]
        if (explanation := explanations.get((path, index))) is not None:
            detail = f"Review synthesis: {explanation}"
        else:
            # The preview quotes one run per decision; expanded evidence contains all runs.
            rollout, grader = instances[0]
            reasons: dict[bool, str] = {}
            for number, run in enumerate(grader.runs, start=1):
                for judgment in run.judgments:
                    if judgment.index != index or judgment.met in reasons:
                        continue
                    decision = "Met" if judgment.met else "Not met"
                    rationale = (
                        f"“{_literal_markdown(' '.join(judgment.rationale.split()))}”"
                        if judgment.rationale.strip()
                        else "Rationale not recorded."
                    )
                    run_label = _run_label(number, judgment).lower()
                    reasons[judgment.met] = (
                        f"{decision} — {rollout}, {run_label}: {rationale}"
                    )
            detail = "Recorded rationales: " + " ".join(
                reasons[met] for met in (True, False) if met in reasons
            )
        labels = _readable_list(sorted({rollout for rollout, _ in instances}))
        bullets.append(f"- {_literal_markdown(label)}: {detail} Affected: {labels}.")
    return bullets


def enforce_rubric_consistency_verdict(
    notes: dict[str, Any], rollout_reviews: list[dict[str, Any]]
) -> dict[str, Any]:
    """Keep a synthesis model from overlooking a deterministic disagreement."""
    present = []
    for position, review in enumerate(rollout_reviews, start=1):
        consistency = RolloutRubricConsistency.from_review(review, position=position)
        if consistency is not None:
            present.append(consistency)
    if not present:
        return notes
    failed = [review for review in present if review.evidence.status == "INCONSISTENT"]
    adjusted = dict(notes)
    check_summaries = [
        dict(item) if isinstance(item, dict) else item
        for item in adjusted.get("check_summaries", [])
    ]
    rubric_summary = next(
        (
            item
            for item in check_summaries
            if isinstance(item, dict)
            and item.get("check_key") == RUBRIC_CONSISTENCY_CHECK_KEY
        ),
        None,
    )
    if rubric_summary is None:
        rubric_summary = {"check_key": RUBRIC_CONSISTENCY_CHECK_KEY}
        check_summaries.append(rubric_summary)
    rubric_summary["display_name"] = RUBRIC_CONSISTENCY_DISPLAY_NAME
    if not failed:
        repetitions = sorted({review.evidence.repetitions for review in present})
        rubric_summary["summary"] = (
            "All criterion decisions agreed across "
            f"{_readable_list([str(count) for count in repetitions])} grader runs "
            "per captured answer. Agreement shows repeatability, not correctness."
        )
        adjusted["check_summaries"] = check_summaries
        return adjusted

    if adjusted.get("verdict") in {None, "PASS", "APPROVE"}:
        adjusted["verdict"] = "NEEDS_REVIEW"
    lead = _rubric_disagreement_lead([review.evidence for review in failed])
    summary = adjusted.get("summary", "")
    if "rubric" not in summary.lower() or "inconsisten" not in summary.lower():
        adjusted["summary"] = f"{lead} {summary}".strip()
    follow_ups = [
        dict(item) if isinstance(item, dict) else item
        for item in adjusted.get("follow_ups", [])
    ]
    rubric_follow_ups = [
        item
        for item in follow_ups
        if isinstance(item, dict)
        and RUBRIC_CONSISTENCY_CHECK_KEY in item.get("related_checks", [])
    ]
    for item in rubric_follow_ups:
        item["severity"] = "BLOCKING"
    existing_summary = rubric_summary.get("summary")
    paths = {grader.path for review in present for grader in review.evidence.graders}
    bullets = _criterion_summary_bullets(
        failed,
        existing_summary if isinstance(existing_summary, str) else "",
        include_paths=len(paths) > 1,
    )
    rubric_summary["summary"] = lead
    if bullets:
        rubric_summary["summary"] = f"{lead}\n\n{'\n'.join(bullets)}"
    if not rubric_follow_ups:
        follow_ups.append(
            {
                "title": "Resolve inconsistent rubric judgments",
                "severity": "BLOCKING",
                "description": rubric_summary["summary"],
                "related_checks": [RUBRIC_CONSISTENCY_CHECK_KEY],
            }
        )
    adjusted["follow_ups"] = follow_ups
    adjusted["check_summaries"] = check_summaries
    return adjusted
