"""Individual native provider calls for the native Yeast grading queue.

Credentials are domain-routed scoped gateway keys resolved by Yeast; neither keys nor
headers are persisted. The caller checkpoints each successful criterion.
"""

import asyncio
import random
from typing import Any

import anthropic
import openai

from .gateway import GatewayConnection, GatewayRun
from .inference_wire import (
    gemini_inference,
    openai_result_payload,
    result_payload,
)
from .rubric import (
    anthropic_message_text,
    parse_rubric_criterion_grader_output,
)
from .rubric_wire import (
    RubricRequest,
    rubric_inference_options,
    rubric_message_from_result,
)


class CriterionClient:
    def __init__(
        self,
        model: str,
        session_id: str,
        *,
        api_key: str,
        base_url: str,
        run: GatewayRun | None = None,
    ):
        self.model = model
        self.provider = model.split("/", 1)[0]
        base = base_url.rstrip("/")
        suffix = "/anthropic" if self.provider == "anthropic" else "/v1"
        if not base.endswith(suffix):
            raise ValueError("Rubric QC requires the domain-routed gateway endpoint")
        self.connection = GatewayConnection(
            api_key=api_key,
            base_url=base[: -len(suffix)],
            session_id=session_id,
            run=run,
        )
        self.client = (
            anthropic.AsyncAnthropic
            if self.provider == "anthropic"
            else openai.AsyncOpenAI
        )(api_key=self.connection.api_key, base_url=base, max_retries=0)

    async def close(self):
        await self.client.close()

    async def call(self, job: dict[str, Any]) -> dict[str, Any]:
        request = RubricRequest.model_validate(job["request"])
        provider, model, options = rubric_inference_options(
            request, job["model"], job["model_params"]
        )
        if provider != self.provider or job["model"] != self.model:
            raise ValueError("a rubric batch must use one domain-routed model")
        common = {
            "model": self.connection.wire_model(job["model"]),
            "extra_headers": self.connection.headers,
            "timeout": request.timeout,
        }
        async with asyncio.timeout(request.timeout):
            if provider == "anthropic":
                kwargs = (
                    common
                    | {
                        "max_tokens": request.max_tokens,
                        "system": [
                            {
                                "type": "text",
                                "text": request.system,
                                "cache_control": {"type": "ephemeral"},
                            }
                        ],
                        "messages": request.messages,
                    }
                    | options
                )
                async with self.client.messages.stream(**kwargs) as stream:
                    response = await stream.get_final_message()
                body = result_payload(
                    provider=provider, model=model, call_id=job["id"], message=response
                )
            elif provider == "gemini":
                body = await gemini_inference(
                    self.client,
                    common,
                    model=model,
                    max_tokens=request.max_tokens,
                    system=request.system,
                    messages=request.messages,
                    tools=None,
                    call_id=job["id"],
                    options=options,
                )
            else:
                kwargs = (
                    common
                    | {
                        "max_output_tokens": request.max_tokens,
                        "instructions": request.system,
                        "input": request.messages,
                    }
                    | options
                )
                effort = kwargs.pop("reasoning_effort", None)
                if effort is not None:
                    kwargs["reasoning"] = {"effort": effort}
                async with self.client.responses.stream(**kwargs) as stream:
                    response = await stream.get_final_response()
                body = openai_result_payload(
                    model=model, call_id=job["id"], response=response
                )
        item = body["results"][0]
        response = rubric_message_from_result(item, model=model, call_id=job["id"])
        if response.stop_reason in {"refusal", "max_tokens"}:
            raise ValueError(f"criterion model stopped with {response.stop_reason}")
        judgment = parse_rubric_criterion_grader_output(
            anthropic_message_text(response)
        )
        return {
            "judgment": judgment.model_dump(mode="json"),
            "usage": item["usage"],
            "provider_request_id": item.get("provider_request_id"),
        }


_TRANSIENT_STREAM_ERRORS = frozenset(
    {
        "RESOURCE_EXHAUSTED",
        "UNAVAILABLE",
        "DEADLINE_EXCEEDED",
        "INTERNAL",
        "rate_limit_exceeded",
        "rate_limit_error",
        "too_many_requests",
        "provider_rate_limited",
        "server_error",
        "provider_server_error",
        "api_error",
        "overloaded_error",
        "timeout_error",
        "provider_connection_failed",
    }
)


def _retryable_status(status: int) -> bool:
    return status in {408, 409, 429} or 500 <= status < 600


def _retryable_stream_error(detail: object) -> bool:
    if not isinstance(detail, dict):
        return False
    code = detail.get("code")
    kind = detail.get("type")
    # Bifrost encodes Vertex's upstream HTTP status as a decimal string.
    if isinstance(code, str) and len(code) == 3 and code.isdecimal():
        code = int(code)
    if isinstance(code, int):
        if not _retryable_status(code):
            return False
        if kind is None:
            return True
    elif code is not None:
        # A named provider code is more specific than its error type.
        kind = code
    return isinstance(kind, str) and kind in _TRANSIENT_STREAM_ERRORS


def retry_delay(error: Exception, attempt: int) -> float | None:
    if isinstance(error, (anthropic.APIStatusError, openai.APIStatusError)):
        if isinstance(error, anthropic.APIStatusError) and error.status_code == 200:
            # Anthropic preserves the stream's HTTP 200 and the full SSE envelope.
            if not isinstance(error.body, dict) or not _retryable_stream_error(
                error.body.get("error")
            ):
                return None
        elif not _retryable_status(error.status_code):
            return None
        hint = error.response.headers.get("retry-after")
        try:
            hinted = max(0, min(300, float(hint))) if hint else 0
        except (ValueError, OverflowError):
            hinted = 0
        return max(hinted, random.uniform(1, min(60, 2 ** (attempt + 1))))
    # OpenAI raises the base APIError with the inner SSE error as its body.
    if isinstance(
        error, (anthropic.APIConnectionError, openai.APIConnectionError, TimeoutError)
    ) or (type(error) is openai.APIError and _retryable_stream_error(error.body)):
        return random.uniform(1, min(60, 2 ** (attempt + 1)))
    # Schema/refusal/truncation gets a bounded fresh-output retry, never a false verdict.
    if isinstance(error, ValueError):
        return 1
    return None
