"""Shared rubric implementation; standalone distribution: latch-rubric-core."""
