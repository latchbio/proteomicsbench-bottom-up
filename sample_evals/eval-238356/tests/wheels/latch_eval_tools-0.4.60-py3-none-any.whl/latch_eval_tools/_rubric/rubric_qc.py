"""Pure planning and validation for rubric QC on Yeast.

Use the actual grader as both the request planner and scorer. No second implementation of
truncation, multistep applicability, penalty scoring or prompt construction lives here.
"""

import hashlib
import json
from collections import defaultdict, deque
from copy import deepcopy
from typing import Any

from anthropic.types import Message
from pydantic import BaseModel, ConfigDict, Field
from .rubric import RubricGrader, RubricGraderConfig, RubricMessageExecutor
from .base import grader_result_payload
from .rubric_consistency import (
    RUBRIC_CONSISTENCY_VERSION,
    RubricConsistencySettings,
    RubricConsistencyEvidence,
    RubricConsistencyRun,
    RubricGraderConsistency,
    _expected_judgment_keys,
    rubric_grader_specs,
)


def fingerprint(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value, sort_keys=True, ensure_ascii=False, separators=(",", ":")
        ).encode()
    ).hexdigest()


def message(value: dict[str, Any]) -> Message:
    return Message.model_validate(
        {
            "id": "saved-rubric-judgment",
            "type": "message",
            "role": "assistant",
            "model": "saved",
            "content": [{"type": "text", "text": json.dumps(value)}],
            "stop_reason": "end_turn",
            "stop_sequence": None,
            "usage": {"input_tokens": 0, "output_tokens": 0},
        }
    )


class Inputs(BaseModel):
    model_config = ConfigDict(extra="forbid")
    request_id: int
    eval_version_id: int
    eval_id: int
    problem_id: int
    compute_node_id: int
    config_hash: str
    workspace_id: int
    domain_id: int
    eval_json: dict[str, Any]
    config: dict[str, Any]
    rollouts: list[dict[str, Any]]
    rollouts_folder: str
    prior_reviews: list[dict[str, Any]] = Field(default_factory=list)
    fp_fn_only: bool = False


def cached_evidence(
    inputs: Inputs, record: dict[str, Any]
) -> RubricConsistencyEvidence | None:
    settings = RubricConsistencySettings.model_validate(inputs.config)
    specs = rubric_grader_specs(inputs.eval_json)
    prior = next(
        (
            r
            for r in inputs.prior_reviews
            if r.get("review_key") == record["review_key"]
        ),
        {},
    )
    try:
        evidence = RubricConsistencyEvidence.model_validate(
            prior.get("rubric_consistency")
        )
    except ValueError:
        return None
    if not evidence.matches_cache(
        repetitions=settings.total_repetitions,
        judges=settings.judges,
        rollout_execution_id=record.get("execution_id"),
        answer_hash=fingerprint(record["agent_answer"]),
        rubric_specs_hash=fingerprint(specs),
        grader_paths=[path for path, _ in specs],
    ):
        return None
    # A hash and run count are insufficient: truncated judgments or stale summary
    # fields must never turn a partial pipeline result into a completed check.
    for grader, (path, spec) in zip(evidence.graders, specs):
        expected = _expected_judgment_keys(record["agent_answer"], spec["config"])
        if any(
            {judgment.key for judgment in run.judgments} != expected
            for run in grader.runs
        ):
            return None
        rebuilt = RubricGraderConsistency.from_runs(
            path=path,
            answer_field=RubricGraderConfig.model_validate(spec["config"]).answer_field,
            criteria=spec["config"]["criteria"],
            runs=grader.runs,
        )
        if rebuilt != grader:
            return None
    status = (
        "INCONSISTENT"
        if any(g.inconsistent for g in evidence.graders)
        else "CONSISTENT"
    )
    if evidence.status != status:
        return None
    return evidence


def validate_sources(inputs: Inputs) -> None:
    keys = [r["review_key"] for r in inputs.rollouts]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate rollout review keys")
    if inputs.fp_fn_only:
        for record in inputs.rollouts:
            if cached_evidence(inputs, record) is None:
                raise ValueError(
                    "Saved consistency evidence does not match the answer, rubric or judge panel; run Rubric Consistency first"
                )


async def plan(inputs: Inputs) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Frozen grading runs and individual criterion jobs; each repetition gets distinct IDs."""
    validate_sources(inputs)
    settings = RubricConsistencySettings.model_validate(inputs.config)
    runs, jobs = [], []
    for record in inputs.rollouts:
        if cached_evidence(inputs, record) is not None:
            continue
        for path, spec in rubric_grader_specs(inputs.eval_json):
            for judge in settings.judges:
                config = deepcopy(spec["config"])
                config["model_id"] = judge.model_id
                config["model_params"] = {
                    "timeout": 300,
                    "reasoning_effort": judge.reasoning_effort,
                    **(
                        {"thinking": {"type": "adaptive"}}
                        if judge.model_id.startswith("anthropic/")
                        else {}
                    ),
                }
                requests = []

                async def capture(request, attempt):
                    requests.append(request)
                    return message({"met": False, "rationale": "Planning only"})

                await RubricGrader().evaluate_answer_llm(
                    record["agent_answer"],
                    config,
                    message_executor=RubricMessageExecutor(capture),
                )
                for iteration in range(1, settings.repetitions + 1):
                    key = fingerprint(
                        [record["review_key"], path, judge.model_id, iteration]
                    )
                    run = {
                        "key": key,
                        "review_key": record["review_key"],
                        "path": path,
                        "judge_model": judge.model_id,
                        "iteration": iteration,
                        "config": config,
                        "job_ids": [],
                    }
                    for index, request in enumerate(requests):
                        job_id = fingerprint([key, index, request])
                        jobs.append(
                            {
                                "id": job_id,
                                "model": judge.model_id,
                                "model_params": config["model_params"],
                                "request": request,
                            }
                        )
                        run["job_ids"].append(job_id)
                    runs.append(run)
    return runs, jobs


async def evidence_from_results(
    inputs: Inputs,
    runs: list[dict[str, Any]],
    jobs: list[dict[str, Any]],
    results: dict[str, Any],
) -> dict[str, Any]:
    """Replay validated criterion responses through the canonical scorer, without an API call."""
    expected = {job["id"] for job in jobs}
    if set(results) != expected:
        raise ValueError(
            "rubric pipeline criterion job coverage is incomplete or unexpected"
        )
    job_by_id = {j["id"]: j for j in jobs}
    settings = RubricConsistencySettings.model_validate(inputs.config)
    specs = rubric_grader_specs(inputs.eval_json)
    evidence = {}
    for record in inputs.rollouts:
        cached = cached_evidence(inputs, record)
        if cached is not None:
            evidence[record["review_key"]] = cached.model_dump(mode="json")
            continue
        graders = []
        for path, spec in specs:
            grades = []
            for run in runs:
                if run["review_key"] != record["review_key"] or run["path"] != path:
                    continue
                responses = defaultdict(deque)
                for job_id in run["job_ids"]:
                    responses[fingerprint(job_by_id[job_id]["request"])].append(
                        results[job_id]["judgment"]
                    )

                async def replay(request, attempt):
                    values = responses[fingerprint(request)]
                    if not values:
                        raise ValueError(
                            "rubric response does not match planned prompt"
                        )
                    return message(values.popleft())

                result = await RubricGrader().evaluate_answer_llm(
                    record["agent_answer"],
                    run["config"],
                    message_executor=RubricMessageExecutor(replay),
                )
                if any(responses.values()):
                    raise ValueError("unused rubric responses")
                grade = RubricConsistencyRun.from_grader_result(
                    grader_result_payload(result),
                    expected=_expected_judgment_keys(
                        record["agent_answer"], spec["config"]
                    ),
                )
                grade.judge_model, grade.iteration = (
                    run["judge_model"],
                    run["iteration"],
                )
                grades.append(grade)
            graders.append(
                RubricGraderConsistency.from_runs(
                    path=path,
                    answer_field=RubricGraderConfig.model_validate(spec["config"]).answer_field,
                    criteria=spec["config"]["criteria"],
                    runs=grades,
                )
            )
        evidence[record["review_key"]] = RubricConsistencyEvidence(
            version=RUBRIC_CONSISTENCY_VERSION,
            repetitions=settings.total_repetitions,
            judges=settings.judges,
            graders=graders,
            status="INCONSISTENT"
            if any(g.inconsistent for g in graders)
            else "CONSISTENT",
            rollout_execution_id=record.get("execution_id"),
            answer_hash=fingerprint(record["agent_answer"]),
            rubric_specs_hash=fingerprint(specs),
        ).model_dump(mode="json")
    return evidence
