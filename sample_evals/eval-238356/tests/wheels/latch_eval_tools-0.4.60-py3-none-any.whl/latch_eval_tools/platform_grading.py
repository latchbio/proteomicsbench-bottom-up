"""The eval platform's grading semantics over the graders in this package.

How an eval's `grader` / `graders[]` / `scoring` block turns grader verdicts into one pass/fail
and score: strict `all_of` and partial-credit `average_of` composites with gate / additive /
hard-fail roles, weighted top-level points, threshold pass rules, and the fail-closed handling
of misconfigured or system-failed graders. The orchestrator's compute nodes grade with this
module; a Yeast flow that grades inside a sandbox (the `rollouts_flow`) runs the very same code,
so a verdict means the same thing wherever it was produced.

LLM graders need a provider key for the grader's model. Callers supply an `ApiKeyResolver`: the
orchestrator resolves keys through the eval's domain routes, a sandbox reads the keys the host
exported into its environment (`EnvApiKeyResolver`).

Artifact graders need a sandbox to run their package in. Callers that have one supply an
`ArtifactRunner` (the Yeast rollouts flow runs every package ahead of time and passes
`PrecomputedArtifactResults`); callers that do not pass nothing, and every artifact grader fails
closed as a configuration error.
"""

import asyncio
import json
import math
import os
import traceback
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, replace
from typing import Any, Optional, Protocol

from pydantic import BaseModel, ConfigDict

from latch_eval_tools._rubric.base import grader_result_payload as grader_result_payload
from latch_eval_tools._rubric.rubric import ARTIFACT_TEXT_FIELD
from latch_eval_tools.graders.artifact import is_roles_only_artifact_config

from latch_eval_tools.graders.confidence import (
    CONFIDENCE_REWARD,
    confidence_bundle_error,
    contains_confidence_grader,
    unavailable_confidence_result,
)

from latch_eval_tools.graders import (
    ARTIFACT_GRADER_TYPE,
    ARTIFACT_NEEDS_SANDBOX_MESSAGE,
    GRADER_REGISTRY,
    LLM_GRADER_REGISTRY,
    SANDBOX_GRADER_REGISTRY,
    ArtifactGraderConfig,
    ArtifactGraderSpec,
    GraderError,
    GraderResult,
    GraderTransientError,
    RubricGraderConfig,
    artifact_spec_key,
    artifact_system_error_payload,
    evaluate_composite_predicate_leaf,
    normalize_artifact_payload,
    normalize_score,
    validate_artifact_results,
)
from latch_eval_tools.graders.composite import _child_points, _rescale_to_points


class ApiKeyResolver(Protocol):
    """Where an LLM grader's provider key comes from."""

    async def api_key(self, model_id: str, *, refusal_fallback: bool = False) -> str: ...

    async def fallback_api_key(self, model_id: str) -> str: ...


@dataclass(frozen=True)
class LlmGraderExecutor:
    """Execute an LLM leaf without changing composite/scoring semantics."""

    evaluate: Callable[
        [str, dict[str, Any], dict[str, Any], str, bool, tuple[int, ...]],
        Awaitable[GraderResult],
    ]
    path: tuple[int, ...] = ()

    def child(self, index: int) -> "LlmGraderExecutor":
        return replace(self, path=(*self.path, index))


PROVIDER_ENV_VARS: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "google": "GEMINI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "xai": "XAI_API_KEY",
    "fireworks": "FIREWORKS_API_KEY",
    "mistral": "MISTRAL_API_KEY",
}
FALLBACK_API_KEYS_ENV = "ANTHROPIC_API_KEY_FALLBACKS"


class EnvApiKeyResolver:
    """Keys from the process environment, by the model id's provider prefix
    (`anthropic/claude-sonnet-4-6` -> `ANTHROPIC_API_KEY`). The refusal fallback is the first entry
    of the JSON list in `ANTHROPIC_API_KEY_FALLBACKS`, the variable the CLI harnesses also read."""

    def __init__(self, env: dict[str, str] | None = None) -> None:
        self.env = env if env is not None else dict(os.environ)

    def _var_for(self, model_id: str) -> str:
        provider, _, _ = model_id.partition("/")
        try:
            return PROVIDER_ENV_VARS[provider]
        except KeyError:
            raise GraderError(
                f"no API key environment variable is known for provider {provider!r} (model {model_id!r})"
            ) from None

    async def api_key(self, model_id: str, *, refusal_fallback: bool = False) -> str:
        var = self._var_for(model_id)
        value = self.env.get(var)
        if not value:
            raise GraderError(f"{var} is not set; cannot run the LLM grader for {model_id!r}")
        return value

    async def fallback_api_key(self, model_id: str) -> str:
        raw = self.env.get(FALLBACK_API_KEYS_ENV)
        if raw:
            try:
                fallbacks = json.loads(raw)
            except json.JSONDecodeError:
                fallbacks = []
            if isinstance(fallbacks, list) and fallbacks and isinstance(fallbacks[0], str):
                return fallbacks[0]
        raise GraderError(
            f"no refusal fallback key available for {model_id!r} ({FALLBACK_API_KEYS_ENV} unset)"
        )


class ArtifactRunner(Protocol):
    """Where an artifact grader's package gets executed. Returns the package's `results.json` as a
    dict (validated by the caller) or an `artifact_system_error_payload`."""

    # By role, what the sandbox extracted for rubric graders with `artifact`: status `ready` with
    # the `text`, `unavailable` (the rubric fails), or `error`, with a `message`.
    texts: dict[str, dict[str, Any]]

    async def run(
        self, spec: ArtifactGraderSpec, agent_answer: dict[str, Any]
    ) -> dict[str, Any]: ...


class PrecomputedArtifactResults:
    """`ArtifactRunner` over results produced ahead of time, keyed by `ArtifactGraderSpec.key`.
    The rollouts flow runs every package in its own sandbox first, then grades with this runner so
    composition with the eval's other graders happens in one place."""

    def __init__(
        self,
        results: dict[str, dict[str, Any]],
        texts: Optional[dict[str, dict[str, Any]]] = None,
    ) -> None:
        self.results = dict(results)
        self.texts = dict(texts or {})

    async def run(
        self, spec: ArtifactGraderSpec, agent_answer: dict[str, Any]
    ) -> dict[str, Any]:
        result = self.results.get(spec.key)
        if result is None:
            return artifact_system_error_payload(
                f"no artifact result was produced for grader {spec.key[:12]} ({spec.config.package})",
                agent_answer=agent_answer,
            )
        return result


COMPOSITE_GRADER_TYPES = {"all_of", "average_of", "composite"}


def _classify_all_of_child(child: object) -> tuple[str, str | None]:
    """Classify a strict-AND child as required, hard-fail, or invalid."""

    if not isinstance(child, dict):
        return "invalid", "all_of child must be an object"

    if "predicate" in child and "type" not in child:
        role = child.get("role")
        if role == "gate":
            return "required", None
        if role == "hard_fail":
            return "hard_fail", None
        if role == "additive":
            return (
                "invalid",
                "role 'additive' is invalid inside strict all_of; use a "
                "top-level graders[] entry or average_of for partial credit",
            )
        return (
            "invalid",
            f"bare predicate child role must be one of gate/hard_fail, got {role!r}",
        )

    if "role" in child:
        return (
            "invalid",
            "typed all_of children do not accept an outer role; every typed "
            "child is required",
        )

    child_type = child.get("type")
    child_config = child.get("config")
    if child_type is not None and not isinstance(child_config, dict):
        return "invalid", "typed all_of child config must be an object"

    if child_type != "predicate_leaf":
        return "required", None

    role = child_config.get("role") if isinstance(child_config, dict) else None
    if role == "gate":
        return "required", None
    if role == "hard_fail":
        return "hard_fail", None
    if role == "additive":
        return (
            "invalid",
            "role 'additive' is invalid inside strict all_of; use a "
            "top-level graders[] entry or average_of for partial credit",
        )
    return (
        "invalid",
        f"predicate_leaf config role must be one of gate/hard_fail, got {role!r}",
    )


def _classify_average_of_child(child: object) -> tuple[str, str | None]:
    """Classify a partial-credit child as scoring, hard-fail, or invalid."""

    if not isinstance(child, dict):
        return "invalid", "average_of child must be an object"

    if "predicate" in child and "type" not in child:
        role = child.get("role")
        if isinstance(role, str) and role in {"gate", "additive"}:
            return "scoring", None
        if role == "hard_fail":
            return "hard_fail", None
        return (
            "invalid",
            "bare predicate child role must be one of gate/additive/hard_fail, "
            f"got {role!r}",
        )

    if "role" in child:
        return (
            "invalid",
            "typed average_of children do not accept an outer role; every "
            "typed child is a scoring component",
        )

    child_type = child.get("type")
    child_config = child.get("config")
    if child_type is not None and not isinstance(child_config, dict):
        return "invalid", "typed average_of child config must be an object"

    if child_type != "predicate_leaf":
        return "scoring", None

    role = child_config.get("role") if isinstance(child_config, dict) else None
    if isinstance(role, str) and role in {"gate", "additive"}:
        return "scoring", None
    if role == "hard_fail":
        return "hard_fail", None
    return (
        "invalid",
        "predicate_leaf config role must be one of gate/additive/hard_fail, "
        f"got {role!r}",
    )


def _all_of_child_label(child: object, index: int) -> str:
    if not isinstance(child, dict):
        return f"children[{index}]"
    if "predicate" in child and "type" not in child:
        return str(child.get("name") or f"children[{index}]")
    child_type = child.get("type")
    child_config = child.get("config")
    if child_type == "predicate_leaf" and isinstance(child_config, dict):
        return str(child_config.get("name") or f"children[{index}].predicate_leaf")
    return str(child.get("name") or f"children[{index}].{child_type or 'unknown'}")


def _duplicate_child_labels(children: list[Any]) -> list[str]:
    seen: set[str] = set()
    duplicates: list[str] = []
    for index, child in enumerate(children):
        label = _all_of_child_label(child, index)
        if label in seen and label not in duplicates:
            duplicates.append(label)
        seen.add(label)
    return duplicates


class GradingResult(BaseModel):
    model_config = ConfigDict(frozen=True)

    passed: Optional[bool] = None
    score: Optional[float] = None
    grader_result: Optional[dict[str, Any]] = None
    grader_results: Optional[list[Optional[dict[str, Any]]]] = None
    grader_system_error: bool = False

    @property
    def has_platform_grader_outcome(self) -> bool:
        return self.grader_result is not None or self.grader_results is not None


def failed_grader_result_payload(
    agent_answer: dict[str, Any], exc: Exception
) -> dict[str, Any]:
    return {
        "passed": False,
        "metrics": {
            "grader_system_error": True,
            "grader_error": str(exc),
        },
        "reasoning": f"Grader failed unexpectedly: {exc}\n\n{traceback.format_exc()}",
        "agent_answer": agent_answer,
        "score": 0.0,
        "raw_score": 0.0,
        "score_max": 1.0,
        "field_scores": {},
    }


def configuration_error_grader_result_payload(
    agent_answer: dict[str, Any], message: str
) -> dict[str, Any]:
    return {
        "passed": False,
        "metrics": {"configuration_error": message},
        "reasoning": f"Grader configuration error: {message}",
        "agent_answer": agent_answer,
        "score": 0.0,
        "raw_score": 0.0,
        "score_max": 1.0,
        "field_scores": {},
    }


def _is_top_level_hard_fail(grader_spec: object) -> bool:
    if not isinstance(grader_spec, dict):
        return False
    grader_config = grader_spec.get("config")
    if grader_spec.get("type") == ARTIFACT_GRADER_TYPE:
        # Declares deliverables for rubric graders: a missing required one vetoes the eval, and
        # finding them all is not worth points.
        return is_roles_only_artifact_config(grader_config)
    if grader_spec.get("type") != "predicate_leaf":
        return False
    return isinstance(grader_config, dict) and grader_config.get("role") == "hard_fail"


def _payload_score_parts(result: dict[str, Any]) -> tuple[float, float] | None:
    raw_score = result.get("raw_score")
    raw_score_max = result.get("score_max")
    if (
        isinstance(raw_score, bool)
        or not isinstance(raw_score, int | float)
        or isinstance(raw_score_max, bool)
        or not isinstance(raw_score_max, int | float)
    ):
        return None

    score = float(raw_score)
    score_max = float(raw_score_max)
    if not math.isfinite(score) or not math.isfinite(score_max) or score_max < 0.0:
        return None
    return score, score_max


def _top_level_points(grader_spec: object) -> tuple[float, str | None]:
    """Point value a top-level grader contributes to the eval's bundle.

    Unset means one point, which reproduces the historical unweighted mean.
    A graph eval uses it to make the terminal rubric outweigh its upstream
    calls.
    """

    if not isinstance(grader_spec, dict) or "points" not in grader_spec:
        return 1.0, None

    points = grader_spec["points"]
    if (
        isinstance(points, bool)
        or not isinstance(points, int | float)
        or not math.isfinite(points)
        or float(points) <= 0.0
    ):
        return 1.0, "grader 'points' must be a finite number greater than zero"
    if _is_top_level_hard_fail(grader_spec):
        return 1.0, "'points' is invalid on a hard_fail grader; vetoes do not score"
    return float(points), None


def _is_required_grader(grader_spec: object) -> bool:
    """``required: true`` keeps a grader mandatory under a threshold rule."""

    return isinstance(grader_spec, dict) and grader_spec.get("required") is True


def _evaluate_top_level_pass_rule(
    scoring: object,
    scoring_entries: list[tuple[int, bool, bool]],
    awarded_points: float,
) -> tuple[str, bool, list[int], str | None]:
    """Apply the eval's ``scoring`` block to the per-grader verdicts.

    Returns ``(pass_rule, scoring_ok, required_failed, configuration_error)``.
    The default rule is ``all``, i.e. the historical every-grader-must-pass
    behavior, so an eval without a ``scoring`` block is unaffected.
    """

    passed_flags = [passed for _, passed, _ in scoring_entries]
    if scoring is None:
        return "all", all(passed_flags) if passed_flags else False, [], None
    if not isinstance(scoring, dict):
        return "all", False, [], "scoring must be an object"

    unknown = sorted(
        set(scoring) - {"pass_rule", "min_passing_graders", "score_threshold"}
    )
    if unknown:
        return "all", False, [], f"unknown scoring fields: {unknown}"

    pass_rule = scoring.get("pass_rule", "all")
    if pass_rule == "all":
        for field in ("min_passing_graders", "score_threshold"):
            if field in scoring:
                return (
                    "all",
                    False,
                    [],
                    f"{field} is only valid with its matching scoring pass_rule",
                )
        return "all", all(passed_flags) if passed_flags else False, [], None

    # Under a threshold rule, graders are no longer implicitly mandatory, so
    # anything that must still hold - the terminal call - says so explicitly.
    required_failed = [
        idx for idx, passed, required in scoring_entries if required and not passed
    ]

    if pass_rule == "min_passing":
        if "score_threshold" in scoring:
            return (
                pass_rule,
                False,
                required_failed,
                "score_threshold is invalid with pass_rule='min_passing'",
            )
        minimum = scoring.get("min_passing_graders")
        if (
            isinstance(minimum, bool)
            or not isinstance(minimum, int)
            or minimum < 0
            or minimum > len(scoring_entries)
        ):
            return (
                pass_rule,
                False,
                required_failed,
                "min_passing_graders must be an integer between 0 and the "
                "number of scoring graders",
            )
        return (
            pass_rule,
            sum(passed_flags) >= minimum and not required_failed,
            required_failed,
            None,
        )

    if pass_rule == "score_threshold":
        if "min_passing_graders" in scoring:
            return (
                pass_rule,
                False,
                required_failed,
                "min_passing_graders is invalid with pass_rule='score_threshold'",
            )
        threshold = scoring.get("score_threshold")
        if (
            isinstance(threshold, bool)
            or not isinstance(threshold, int | float)
            or not math.isfinite(threshold)
            or float(threshold) < 0.0
        ):
            return (
                pass_rule,
                False,
                required_failed,
                "score_threshold must be a finite non-negative number",
            )
        return (
            pass_rule,
            awarded_points >= float(threshold) and not required_failed,
            required_failed,
            None,
        )

    return (
        str(pass_rule),
        False,
        [],
        "scoring pass_rule must be one of all/min_passing/score_threshold",
    )


def _normalized_payload_score(result: dict[str, Any]) -> float:
    score_parts = _payload_score_parts(result)
    if score_parts is None:
        return 0.0
    return normalize_score(*score_parts)


def _metrics_have_grader_error(metrics: object) -> bool:
    return isinstance(metrics, dict) and (
        metrics.get("grader_system_error") is True
        or metrics.get("grader_error") is not None
    )


def run_single_grader(
    grader_spec: Any, agent_answer: dict[str, Any]
) -> Optional[dict[str, Any]]:
    if not isinstance(grader_spec, dict):
        return None

    grader_type = grader_spec.get("type")
    grader_config = grader_spec.get("config", {})
    if not isinstance(grader_type, str):
        return None
    if grader_type in SANDBOX_GRADER_REGISTRY:
        # No sandbox on the synchronous path: the placeholder grader validates the config and
        # fails closed with the message that says where artifact graders do run.
        if not isinstance(grader_config, dict):
            return configuration_error_grader_result_payload(
                agent_answer, "grader config must be an object"
            )
        return grader_result_payload(
            SANDBOX_GRADER_REGISTRY[grader_type]().evaluate_answer(agent_answer, grader_config)
        )
    if grader_type not in GRADER_REGISTRY:
        return None
    if not isinstance(grader_config, dict):
        return configuration_error_grader_result_payload(
            agent_answer, "grader config must be an object"
        )

    grader = GRADER_REGISTRY[grader_type]()
    try:
        return grader_result_payload(
            grader.evaluate_answer(agent_answer, grader_config)
        )
    except Exception as exc:
        return failed_grader_result_payload(agent_answer, exc)


async def _evaluate_artifact_grader(
    artifacts: Optional[ArtifactRunner],
    grader_spec: dict[str, Any],
    grader_config: dict[str, Any],
    agent_answer: dict[str, Any],
) -> dict[str, Any]:
    """One artifact grader through the caller's runner. An invalid config or no runner is a
    configuration error (the eval, or where it is being graded, is wrong); a runner failure or an
    invalid `results.json` is a grader system error (the package is wrong)."""
    try:
        config = ArtifactGraderConfig.model_validate(grader_config)
    except ValueError as exc:
        return configuration_error_grader_result_payload(agent_answer, str(exc))
    if artifacts is None:
        return configuration_error_grader_result_payload(
            agent_answer, ARTIFACT_NEEDS_SANDBOX_MESSAGE
        )
    spec = ArtifactGraderSpec(key=artifact_spec_key(grader_spec), config=config)
    try:
        payload = await artifacts.run(spec, agent_answer)
    except Exception as exc:  # noqa: BLE001 - a broken runner is a grader failure, not a verdict
        return artifact_system_error_payload(
            f"artifact runner failed: {exc}", agent_answer=agent_answer
        )
    problems = validate_artifact_results(payload)
    if problems:
        return artifact_system_error_payload(
            "artifact grader returned an invalid result: " + "; ".join(problems),
            agent_answer=agent_answer,
        )
    normalized = normalize_artifact_payload(payload)
    if normalized.get("agent_answer") is None:
        normalized["agent_answer"] = agent_answer or None
    return normalized


async def _evaluate_artifact_rubric(
    keys: ApiKeyResolver | LlmGraderExecutor,
    artifacts: Optional[ArtifactRunner],
    grader_config: dict[str, Any],
    agent_answer: dict[str, Any],
    *,
    refusal_fallback: bool,
) -> dict[str, Any]:
    """A rubric grader with `artifact`, judged only over the text the artifact sandbox extracted
    for that role, never over anything in the agent's answer."""
    try:
        config = RubricGraderConfig.model_validate(grader_config)
    except ValueError as exc:
        return configuration_error_grader_result_payload(agent_answer, str(exc))
    if artifacts is None:
        return configuration_error_grader_result_payload(
            agent_answer,
            "rubric graders with artifact judge files, which only sandbox-backed grading reads",
        )
    role = str(config.artifact)
    extracted = artifacts.texts.get(role) or {
        "status": "error",
        "message": f"no text was extracted for artifact {role!r}",
    }
    provenance = {key: value for key, value in extracted.items() if key != "text"}
    if extracted.get("status") == "unavailable":
        return {
            "passed": False,
            "metrics": {"answer_field": config.answer_field, "artifact": provenance},
            "reasoning": f"Rubric: FAIL\n\n  x {extracted.get('message')}",
            "agent_answer": agent_answer,
            "score": 0.0,
            "raw_score": 0.0,
            "score_max": 1.0,
            "field_scores": {},
        }
    text = extracted.get("text")
    if extracted.get("status") != "ready" or not isinstance(text, str):
        message = str(extracted.get("message") or f"artifact {role!r} has no text")
        return {
            **failed_grader_result_payload(agent_answer, RuntimeError(message)),
            "reasoning": f"Grader failed: {message}",
        }
    try:
        result = await _evaluate_llm_grader(
            keys,
            "rubric",
            grader_config,
            {ARTIFACT_TEXT_FIELD: {role: text}},
            config.model_id,
            refusal_fallback=refusal_fallback,
        )
    except (GraderTransientError, GraderError):
        raise
    except Exception as exc:
        return failed_grader_result_payload(agent_answer, exc)
    payload = grader_result_payload(result)
    payload["metrics"]["artifact"] = provenance
    # The judged text is stored once, with the rollout's answer, not in every grader result.
    payload["agent_answer"] = agent_answer
    return payload


def llm_grader_model_id(grader_type: str, grader_config: dict[str, Any]) -> str:
    if grader_type == "rubric":
        return RubricGraderConfig.model_validate(grader_config).model_id
    raise ValueError(f"Unknown LLM grader type: {grader_type}")


def composite_config_contains_llm_grader(config: dict[str, Any]) -> bool:
    children = config.get("children")
    if not isinstance(children, list):
        return False

    for child in children:
        if not isinstance(child, dict):
            continue
        child_type = child.get("type")
        if child_type in LLM_GRADER_REGISTRY:
            return True
        if child_type in COMPOSITE_GRADER_TYPES:
            child_config = child.get("config", {})
            if isinstance(child_config, dict) and composite_config_contains_llm_grader(
                child_config
            ):
                return True

    return False


def eval_json_contains_llm_grader(eval_json: dict[str, Any]) -> bool:
    graders = eval_json.get("graders")
    grader_specs = graders if isinstance(graders, list) else [eval_json.get("grader")]

    for grader_spec in grader_specs:
        if not isinstance(grader_spec, dict):
            continue
        grader_type = grader_spec.get("type")
        if grader_type in LLM_GRADER_REGISTRY:
            return True
        if grader_type in COMPOSITE_GRADER_TYPES:
            grader_config = grader_spec.get("config", {})
            if isinstance(grader_config, dict) and composite_config_contains_llm_grader(
                grader_config
            ):
                return True

    return False


async def _evaluate_composite_children_async(
    keys: ApiKeyResolver | LlmGraderExecutor,
    children: list[Any],
    agent_answer: dict[str, Any],
    classify_child: Callable[[object], tuple[str, str | None]],
    *,
    refusal_fallback: bool = False,
    artifacts: Optional[ArtifactRunner] = None,
) -> tuple[list[Optional[dict[str, Any]]], list[str], list[str]]:
    child_results: list[Optional[dict[str, Any]]] = []
    child_labels: list[str] = []
    child_kinds: list[str] = []
    for idx, child in enumerate(children):
        label = _all_of_child_label(child, idx)
        child_kind, role_error = classify_child(child)
        if role_error is not None:
            child_result = configuration_error_grader_result_payload(
                agent_answer, role_error
            )
        elif isinstance(child, dict) and "predicate" in child and "type" not in child:
            child_result = grader_result_payload(
                await asyncio.to_thread(
                    evaluate_composite_predicate_leaf, agent_answer, child
                )
            )
        else:
            grader_spec = child
            child_type = child.get("type") if isinstance(child, dict) else None
            child_config = child.get("config") if isinstance(child, dict) else None
            if child_type == "predicate_leaf":
                if isinstance(child_config, dict):
                    child_result = grader_result_payload(
                        await asyncio.to_thread(
                            evaluate_composite_predicate_leaf,
                            agent_answer,
                            child_config,
                        )
                    )
                else:
                    child_result = configuration_error_grader_result_payload(
                        agent_answer, "predicate_leaf config must be an object"
                    )
            else:
                child_result = await run_single_grader_async(
                    keys.child(idx) if isinstance(keys, LlmGraderExecutor) else keys,
                    grader_spec,
                    agent_answer,
                    refusal_fallback=refusal_fallback,
                    artifacts=artifacts,
                )

        child_labels.append(label)
        child_kinds.append(child_kind)
        child_results.append(child_result)

    return child_results, child_labels, child_kinds


async def run_all_of_grader_async(
    keys: ApiKeyResolver | LlmGraderExecutor,
    grader_config: dict[str, Any],
    agent_answer: dict[str, Any],
    *,
    refusal_fallback: bool = False,
    artifacts: Optional[ArtifactRunner] = None,
) -> dict[str, Any]:
    """Grade composites with async children using the shared all_of semantics."""
    children = grader_config.get("children")
    if not isinstance(children, list):
        return configuration_error_grader_result_payload(
            agent_answer,
            "all_of/composite grader config must contain a children list",
        )
    duplicate_labels = _duplicate_child_labels(children)
    if duplicate_labels:
        return configuration_error_grader_result_payload(
            agent_answer,
            f"all_of/composite child labels must be unique: {duplicate_labels}",
        )

    child_results, child_labels, child_kinds = await _evaluate_composite_children_async(
        keys,
        children,
        agent_answer,
        _classify_all_of_child,
        refusal_fallback=refusal_fallback,
        artifacts=artifacts,
    )

    child_metrics = [
        result.get("metrics") if isinstance(result, dict) else None
        for result in child_results
    ]
    child_score_parts = [
        _payload_score_parts(result) if isinstance(result, dict) else None
        for result in child_results
    ]
    child_payload_errors = [
        isinstance(result, dict)
        and (
            not isinstance(result.get("passed"), bool)
            or not isinstance(result.get("metrics"), dict)
            or child_score_parts[idx] is None
        )
        for idx, result in enumerate(child_results)
    ]
    child_configuration_errors = [
        child_payload_errors[idx]
        or (
            isinstance(metrics, dict) and metrics.get("configuration_error") is not None
        )
        for idx, metrics in enumerate(child_metrics)
    ]
    child_system_errors = [
        _metrics_have_grader_error(metrics) for metrics in child_metrics
    ]
    misconfigured_children = [
        child_labels[idx]
        for idx, result in enumerate(child_results)
        if result is None or child_configuration_errors[idx]
    ]

    hard_fail_triggered: list[Any] = []
    unavailable_hard_fails: list[Any] = []
    for idx, result in enumerate(child_results):
        if not isinstance(result, dict):
            if child_kinds[idx] == "hard_fail":
                unavailable_hard_fails.append(child_labels[idx])
            continue

        metrics = child_metrics[idx]
        if not isinstance(metrics, dict):
            metrics = {}
        nested_triggered = metrics.get("hard_fail_triggered")
        if isinstance(nested_triggered, list) and nested_triggered:
            hard_fail_triggered.append(
                {"child": child_labels[idx], "children": nested_triggered}
            )
        nested_unavailable = metrics.get("hard_fail_unavailable")
        if isinstance(nested_unavailable, list) and nested_unavailable:
            unavailable_hard_fails.append(
                {"child": child_labels[idx], "children": nested_unavailable}
            )

        if child_kinds[idx] == "hard_fail":
            if child_configuration_errors[idx] or child_system_errors[idx]:
                unavailable_hard_fails.append(child_labels[idx])
            elif result.get("passed") is not True:
                hard_fail_triggered.append(child_labels[idx])

    scoring_result_indices = [
        idx
        for idx, result in enumerate(child_results)
        if (
            isinstance(result, dict)
            and child_kinds[idx] == "required"
            and not child_configuration_errors[idx]
        )
    ]
    scoring_results = [
        child_results[idx]
        for idx in scoring_result_indices
        if isinstance(child_results[idx], dict)
    ]
    scoring_passed = sum(
        1
        for idx, result in zip(scoring_result_indices, scoring_results)
        if not child_system_errors[idx] and result.get("passed") is True
    )
    scoring_total_score = 0.0
    score_denominator = 0.0
    for idx, result in zip(scoring_result_indices, scoring_results):
        score_parts = _payload_score_parts(result)
        if score_parts is not None:
            raw_score, raw_score_max = score_parts
            if not child_system_errors[idx]:
                scoring_total_score += raw_score
            score_denominator += raw_score_max

    failed_children = [
        child_labels[idx]
        for idx, result in zip(scoring_result_indices, scoring_results)
        if not child_system_errors[idx] and result.get("passed") is not True
    ]

    pass_rule = grader_config.get("pass_rule", "all")
    pass_rule_configuration_error: str | None = None
    if pass_rule != "all":
        pass_rule_configuration_error = (
            "strict all_of only supports pass_rule='all'; use top-level "
            "graders[] or average_of for partial credit"
        )
    elif "min_passing_children" in grader_config or "score_threshold" in grader_config:
        pass_rule_configuration_error = (
            "min_passing_children and score_threshold are invalid for strict all_of"
        )

    no_positive_children = len(scoring_results) == 0
    blocked = (
        bool(failed_children)
        or bool(hard_fail_triggered)
        or bool(unavailable_hard_fails)
        or bool(misconfigured_children)
        or any(child_system_errors)
        or no_positive_children
        or pass_rule_configuration_error is not None
    )
    passed = not blocked

    metrics: dict[str, Any] = {
        "type": "all_of",
        "pass_rule": pass_rule,
        "scoring_count": len(scoring_results),
        "scoring_passed": scoring_passed,
        "scoring_total_score": scoring_total_score,
        "score_denominator": score_denominator,
        "failed_children": failed_children,
        "hard_fail_triggered": hard_fail_triggered,
    }
    if unavailable_hard_fails:
        metrics["hard_fail_unavailable"] = unavailable_hard_fails
    if any(child_system_errors):
        metrics["grader_system_error"] = True
    if misconfigured_children:
        metrics["configuration_error"] = (
            "all_of contains child graders that could not be configured"
        )
        metrics["misconfigured_children"] = misconfigured_children
    elif no_positive_children:
        metrics["configuration_error"] = "all_of has no positive required children"
    elif pass_rule_configuration_error is not None:
        metrics["configuration_error"] = pass_rule_configuration_error

    field_scores: dict[str, Any] = {}
    reasoning_parts: list[str] = []
    for idx, result in enumerate(child_results):
        if not isinstance(result, dict):
            continue
        label = child_labels[idx]
        result_metrics = result.get("metrics")
        if isinstance(result_metrics, dict):
            for key, value in result_metrics.items():
                metrics[f"{label}.{key}"] = value
        result_field_scores = result.get("field_scores")
        if child_kinds[idx] == "required" and isinstance(result_field_scores, dict):
            for key, value in result_field_scores.items():
                field_scores[f"{label}.{key}"] = value
        reasoning = result.get("reasoning")
        if isinstance(reasoning, str) and reasoning.strip() != "":
            reasoning_parts.append(f"[{label}] {reasoning}")

    score = 1.0 if passed else 0.0

    return grader_result_payload(
        GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning="\n\n".join(reasoning_parts),
            agent_answer=agent_answer,
            score=score,
            field_scores=field_scores,
        )
    )


async def run_average_of_grader_async(
    keys: ApiKeyResolver | LlmGraderExecutor,
    grader_config: dict[str, Any],
    agent_answer: dict[str, Any],
    *,
    refusal_fallback: bool = False,
    artifacts: Optional[ArtifactRunner] = None,
) -> dict[str, Any]:
    """Grade an explicit partial-credit group, including async children."""

    children = grader_config.get("children")
    if not isinstance(children, list):
        return configuration_error_grader_result_payload(
            agent_answer,
            "average_of grader config must contain a children list",
        )
    duplicate_labels = _duplicate_child_labels(children)
    if duplicate_labels:
        return configuration_error_grader_result_payload(
            agent_answer,
            f"average_of child labels must be unique: {duplicate_labels}",
        )

    child_results, child_labels, child_kinds = await _evaluate_composite_children_async(
        keys,
        children,
        agent_answer,
        _classify_average_of_child,
        refusal_fallback=refusal_fallback,
        artifacts=artifacts,
    )
    child_metrics = [
        result.get("metrics") if isinstance(result, dict) else None
        for result in child_results
    ]
    child_score_parts = [
        _payload_score_parts(result) if isinstance(result, dict) else None
        for result in child_results
    ]
    child_payload_errors = [
        isinstance(result, dict)
        and (
            not isinstance(result.get("passed"), bool)
            or not isinstance(result.get("metrics"), dict)
            or child_score_parts[idx] is None
            or (
                child_kinds[idx] == "scoring"
                and child_score_parts[idx] is not None
                and child_score_parts[idx][1] <= 0.0
            )
        )
        for idx, result in enumerate(child_results)
    ]
    child_configuration_errors = [
        child_payload_errors[idx]
        or (
            isinstance(metrics, dict) and metrics.get("configuration_error") is not None
        )
        for idx, metrics in enumerate(child_metrics)
    ]
    child_system_errors = [
        _metrics_have_grader_error(metrics) for metrics in child_metrics
    ]
    misconfigured_children = [
        child_labels[idx]
        for idx, result in enumerate(child_results)
        if result is None or child_configuration_errors[idx]
    ]

    hard_fail_triggered: list[Any] = []
    unavailable_hard_fails: list[Any] = []
    for idx, result in enumerate(child_results):
        if not isinstance(result, dict):
            if child_kinds[idx] == "hard_fail":
                unavailable_hard_fails.append(child_labels[idx])
            continue

        metrics = child_metrics[idx]
        if not isinstance(metrics, dict):
            metrics = {}
        nested_triggered = metrics.get("hard_fail_triggered")
        if isinstance(nested_triggered, list) and nested_triggered:
            hard_fail_triggered.append(
                {"child": child_labels[idx], "children": nested_triggered}
            )
        nested_unavailable = metrics.get("hard_fail_unavailable")
        if isinstance(nested_unavailable, list) and nested_unavailable:
            unavailable_hard_fails.append(
                {"child": child_labels[idx], "children": nested_unavailable}
            )

        if child_kinds[idx] == "hard_fail":
            if child_configuration_errors[idx] or child_system_errors[idx]:
                unavailable_hard_fails.append(child_labels[idx])
            elif result.get("passed") is not True:
                hard_fail_triggered.append(child_labels[idx])

    scoring_result_indices = [
        idx
        for idx, result in enumerate(child_results)
        if (
            isinstance(result, dict)
            and child_kinds[idx] == "scoring"
            and not child_configuration_errors[idx]
        )
    ]
    scoring_results = [
        child_results[idx]
        for idx in scoring_result_indices
        if isinstance(child_results[idx], dict)
    ]
    scoring_passed = sum(
        1
        for idx, result in zip(scoring_result_indices, scoring_results)
        if not child_system_errors[idx] and result.get("passed") is True
    )
    scoring_total_score = 0.0
    score_denominator = 0.0
    for idx, result in zip(scoring_result_indices, scoring_results):
        score_parts = _payload_score_parts(result)
        if score_parts is None:
            continue
        raw_score, raw_score_max = score_parts
        # Honour an explicit per-child weight, exactly as the synchronous
        # AverageOfGrader does. Without this the two implementations disagree:
        # the sync path weights children and this one silently does not, so an
        # eval scores differently depending on which entry point graded it.
        points, points_error = _child_points(children[idx])
        if points_error is not None:
            if child_labels[idx] not in misconfigured_children:
                misconfigured_children.append(child_labels[idx])
            continue
        if points is not None and raw_score_max > 0.0:
            raw_score, raw_score_max = _rescale_to_points(
                raw_score, raw_score_max, points
            )
        if not child_system_errors[idx]:
            scoring_total_score += raw_score
        score_denominator += raw_score_max

    failed_children = [
        child_labels[idx]
        for idx, result in zip(scoring_result_indices, scoring_results)
        if not child_system_errors[idx] and result.get("passed") is not True
    ]

    pass_rule = grader_config.get("pass_rule", "all")
    pass_rule_configuration_error: str | None = None
    if pass_rule == "all":
        if (
            "min_passing_children" in grader_config
            or "score_threshold" in grader_config
        ):
            scoring_rule_passed = False
            pass_rule_configuration_error = (
                "min_passing_children and score_threshold are only valid with "
                "their matching average_of pass_rule"
            )
        else:
            scoring_rule_passed = scoring_passed == len(scoring_results)
    elif pass_rule == "min_passing":
        min_passing = grader_config.get("min_passing_children")
        if "score_threshold" in grader_config:
            scoring_rule_passed = False
            pass_rule_configuration_error = (
                "score_threshold is invalid with pass_rule='min_passing'"
            )
        elif (
            isinstance(min_passing, bool)
            or not isinstance(min_passing, int)
            or min_passing < 0
            or min_passing > len(scoring_results)
        ):
            scoring_rule_passed = False
            pass_rule_configuration_error = (
                "min_passing_children must be an int between 0 and the "
                f"number of scoring children ({len(scoring_results)})"
            )
        else:
            scoring_rule_passed = scoring_passed >= min_passing
    elif pass_rule == "score_threshold":
        score_threshold = grader_config.get("score_threshold")
        if "min_passing_children" in grader_config:
            scoring_rule_passed = False
            pass_rule_configuration_error = (
                "min_passing_children is invalid with pass_rule='score_threshold'"
            )
        elif (
            isinstance(score_threshold, bool)
            or not isinstance(score_threshold, int | float)
            or not math.isfinite(float(score_threshold))
            or score_threshold < 0
        ):
            scoring_rule_passed = False
            pass_rule_configuration_error = (
                "score_threshold must be a finite non-negative number when "
                "pass_rule='score_threshold'"
            )
        else:
            scoring_rule_passed = scoring_total_score >= float(score_threshold)
    else:
        scoring_rule_passed = False
        pass_rule_configuration_error = (
            "pass_rule must be one of all/min_passing/score_threshold, "
            f"got {pass_rule!r}"
        )

    no_positive_children = len(scoring_results) == 0
    invalid_score_values = (
        not math.isfinite(scoring_total_score)
        or not math.isfinite(score_denominator)
        or score_denominator <= 0.0
    )
    blocked = (
        bool(hard_fail_triggered)
        or bool(unavailable_hard_fails)
        or bool(misconfigured_children)
        or any(child_system_errors)
        or no_positive_children
        or invalid_score_values
        or pass_rule_configuration_error is not None
    )
    passed = scoring_rule_passed and not blocked

    metrics: dict[str, Any] = {
        "type": "average_of",
        "pass_rule": pass_rule,
        "scoring_count": len(scoring_results),
        "scoring_passed": scoring_passed,
        "scoring_total_score": scoring_total_score,
        "score_denominator": score_denominator,
        "failed_children": failed_children,
        "hard_fail_triggered": hard_fail_triggered,
    }
    if unavailable_hard_fails:
        metrics["hard_fail_unavailable"] = unavailable_hard_fails
    if any(child_system_errors):
        metrics["grader_system_error"] = True
    if misconfigured_children:
        metrics["configuration_error"] = (
            "average_of contains child graders that could not be configured"
        )
        metrics["misconfigured_children"] = misconfigured_children
    elif no_positive_children:
        metrics["configuration_error"] = "average_of has no positive scoring children"
    elif invalid_score_values:
        metrics["configuration_error"] = (
            "average_of scoring children must provide a positive finite "
            "score denominator and finite total score"
        )
    elif pass_rule_configuration_error is not None:
        metrics["configuration_error"] = pass_rule_configuration_error

    field_scores: dict[str, Any] = {}
    reasoning_parts: list[str] = []
    for idx, result in enumerate(child_results):
        if not isinstance(result, dict):
            continue
        label = child_labels[idx]
        result_metrics = result.get("metrics")
        if isinstance(result_metrics, dict):
            for key, value in result_metrics.items():
                metrics[f"{label}.{key}"] = value
        result_field_scores = result.get("field_scores")
        if child_kinds[idx] == "scoring" and isinstance(result_field_scores, dict):
            for key, value in result_field_scores.items():
                field_scores[f"{label}.{key}"] = value
        reasoning = result.get("reasoning")
        if isinstance(reasoning, str) and reasoning.strip() != "":
            reasoning_parts.append(f"[{label}] {reasoning}")

    score = 0.0 if blocked else normalize_score(scoring_total_score, score_denominator)
    return grader_result_payload(
        GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning="\n\n".join(reasoning_parts),
            agent_answer=agent_answer,
            score=score,
            field_scores=field_scores,
        )
    )


LLM_GRADER_REFUSAL_MARKER = "stopped with stop_reason='refusal'"


async def _evaluate_llm_grader(
    keys: ApiKeyResolver | LlmGraderExecutor,
    grader_type: str,
    grader_config: dict[str, Any],
    agent_answer: dict[str, Any],
    model_id: str,
    *,
    refusal_fallback: bool,
) -> GraderResult:
    if isinstance(keys, LlmGraderExecutor):
        return await keys.evaluate(
            grader_type, grader_config, agent_answer, model_id, refusal_fallback, keys.path
        )
    grader = LLM_GRADER_REGISTRY[grader_type]()
    api_key = await keys.api_key(model_id, refusal_fallback=refusal_fallback)
    try:
        return await grader.evaluate_answer_llm(
            agent_answer, grader_config, api_key=api_key
        )
    except Exception as exc:
        if not refusal_fallback or LLM_GRADER_REFUSAL_MARKER not in str(exc):
            raise
    api_key = await keys.fallback_api_key(model_id)
    return await grader.evaluate_answer_llm(
        agent_answer, grader_config, api_key=api_key
    )


async def run_single_grader_async(
    keys: ApiKeyResolver | LlmGraderExecutor,
    grader_spec: Any,
    agent_answer: dict[str, Any],
    *,
    refusal_fallback: bool = False,
    artifacts: Optional[ArtifactRunner] = None,
) -> Optional[dict[str, Any]]:
    if not isinstance(grader_spec, dict):
        return None

    grader_type = grader_spec.get("type")
    grader_config = grader_spec.get("config", {})
    if not isinstance(grader_type, str):
        return None
    if not isinstance(grader_config, dict):
        return configuration_error_grader_result_payload(
            agent_answer, "grader config must be an object"
        )

    if grader_type == ARTIFACT_GRADER_TYPE:
        return await _evaluate_artifact_grader(
            artifacts, grader_spec, grader_config, agent_answer
        )

    if grader_type in COMPOSITE_GRADER_TYPES:
        try:
            if grader_type == "average_of":
                return await run_average_of_grader_async(
                    keys,
                    grader_config,
                    agent_answer,
                    refusal_fallback=refusal_fallback,
                    artifacts=artifacts,
                )
            return await run_all_of_grader_async(
                keys,
                grader_config,
                agent_answer,
                refusal_fallback=refusal_fallback,
                artifacts=artifacts,
            )
        except (GraderTransientError, GraderError):
            # Grader infrastructure failures (not the agent's fault) propagate
            # so callers can retry later or record a system error with no score.
            raise
        except Exception as exc:
            return failed_grader_result_payload(agent_answer, exc)

    if grader_type in GRADER_REGISTRY:
        return await asyncio.to_thread(run_single_grader, grader_spec, agent_answer)

    if grader_type not in LLM_GRADER_REGISTRY:
        return None

    if grader_type == "rubric" and "artifact" in grader_config:
        return await _evaluate_artifact_rubric(
            keys,
            artifacts,
            grader_config,
            agent_answer,
            refusal_fallback=refusal_fallback,
        )

    try:
        model_id = llm_grader_model_id(grader_type, grader_config)
    except Exception as exc:
        return configuration_error_grader_result_payload(agent_answer, str(exc))

    try:
        return grader_result_payload(
            await _evaluate_llm_grader(
                keys,
                grader_type,
                grader_config,
                agent_answer,
                model_id,
                refusal_fallback=refusal_fallback,
            )
        )
    except (GraderTransientError, GraderError):
        raise
    except Exception as exc:
        return failed_grader_result_payload(agent_answer, exc)


def aggregate_grader_results(
    agent_answer: dict[str, Any],
    grader_specs: list[Any],
    grader_results: list[Optional[dict[str, Any]]],
    *,
    scoring: object = None,
) -> dict[str, Any]:
    """Aggregate aligned grader slots, treating hard-fail leaves as vetoes."""
    if contains_confidence_grader(grader_specs):
        error = confidence_bundle_error(grader_specs, scoring)
        result = grader_results[0] if len(grader_results) == 1 else None
        if error is None and (
            not isinstance(result, dict)
            or result.get("reward_type") != CONFIDENCE_REWARD
        ):
            error = "Missing or incompatible confidence grader result"
        if error is not None:
            return grader_result_payload(
                unavailable_confidence_result(
                    agent_answer, error, configuration_error=True
                )
            )
        return {
            **result,
            "metrics": {
                **result["metrics"], "num_graders": 1, "num_scoring_graders": 1
            },
        }
    single_grader = len(grader_specs) == 1
    metrics: dict[str, Any] = {}
    field_scores: dict[str, Any] = {}
    reasoning_parts: list[str] = []
    misconfigurations: list[dict[str, Any]] = []
    normalized_scores: list[float] = []
    score_weights: list[float] = []
    pass_flags: list[bool] = []
    # (grader index, passed, required) for every non-veto grader.
    scoring_entries: list[tuple[int, bool, bool]] = []
    hard_fail_triggered: list[dict[str, Any]] = []
    hard_fail_unavailable: list[dict[str, Any]] = []
    any_misconfigured = False
    any_system_error = False

    for idx, grader_spec in enumerate(grader_specs):
        result = grader_results[idx] if idx < len(grader_results) else None
        grader_type = grader_spec.get("type") if isinstance(grader_spec, dict) else None
        is_hard_fail = _is_top_level_hard_fail(grader_spec)
        points, points_error = _top_level_points(grader_spec)
        if points_error is not None:
            any_misconfigured = True
            misconfigurations.append(
                {"index": idx, "type": grader_type, "error": points_error}
            )
            reasoning_parts.append(f"[graders[{idx}]] {points_error}")
            if is_hard_fail:
                hard_fail_unavailable.append(
                    {"index": idx, "type": grader_type, "error": points_error}
                )
            else:
                normalized_scores.append(0.0)
                score_weights.append(points)
            continue
        prefix = "" if single_grader else f"graders[{idx}]."
        if not isinstance(result, dict):
            any_misconfigured = True
            if is_hard_fail:
                hard_fail_unavailable.append({"index": idx, "type": grader_type})
            else:
                normalized_scores.append(0.0)
                score_weights.append(points)
            misconfigurations.append({"index": idx, "type": grader_type})
            reasoning_parts.append(f"[graders[{idx}]] Grader could not be configured")
            continue

        result_metrics = result.get("metrics")
        score_parts = _payload_score_parts(result)
        result_passed = result.get("passed")
        malformed_result = (
            not isinstance(result_metrics, dict)
            or score_parts is None
            or not isinstance(result_passed, bool)
        )
        if not isinstance(result_metrics, dict):
            result_metrics = {}

        if isinstance(result_metrics, dict):
            for key, value in result_metrics.items():
                metrics[f"{prefix}{key}"] = value
        result_field_scores = result.get("field_scores")
        if isinstance(result_field_scores, dict):
            for key, value in result_field_scores.items():
                field_scores[f"{prefix}{key}"] = value
        reasoning = result.get("reasoning")
        if isinstance(reasoning, str) and reasoning.strip() != "":
            reasoning_parts.append(
                reasoning if single_grader else f"[graders[{idx}]] {reasoning}"
            )

        nested_triggered = result_metrics.get("hard_fail_triggered")
        if isinstance(nested_triggered, list) and nested_triggered:
            hard_fail_triggered.append(
                {
                    "index": idx,
                    "type": grader_type,
                    "children": nested_triggered,
                }
            )
        nested_unavailable = result_metrics.get("hard_fail_unavailable")
        if isinstance(nested_unavailable, list) and nested_unavailable:
            hard_fail_unavailable.append(
                {
                    "index": idx,
                    "type": grader_type,
                    "children": nested_unavailable,
                }
            )

        configuration_error = result_metrics.get("configuration_error")
        if malformed_result or configuration_error is not None:
            any_misconfigured = True
            error = (
                "Malformed grader result"
                if malformed_result
                else str(configuration_error)
            )
            misconfigurations.append(
                {"index": idx, "type": grader_type, "error": error}
            )
            if is_hard_fail:
                hard_fail_unavailable.append(
                    {"index": idx, "type": grader_type, "error": error}
                )
            else:
                normalized_scores.append(0.0)
                score_weights.append(points)
            continue

        result_system_error = result_metrics.get("grader_system_error") is True
        if result_system_error:
            any_system_error = True

        if is_hard_fail:
            if result_system_error:
                hard_fail_unavailable.append(
                    {"index": idx, "type": grader_type, "system_error": True}
                )
            elif result_passed is False:
                grader_config = (
                    grader_spec.get("config") if isinstance(grader_spec, dict) else None
                )
                name = (
                    grader_config.get("name")
                    if isinstance(grader_config, dict)
                    else None
                )
                hard_fail_triggered.append(
                    {
                        "index": idx,
                        "type": grader_type,
                        "name": name if isinstance(name, str) else None,
                    }
                )
        else:
            normalized_scores.append(
                0.0 if result_system_error else _normalized_payload_score(result)
            )
            score_weights.append(points)
        pass_flags.append(result_passed)
        if not is_hard_fail:
            scoring_entries.append(
                (idx, result_passed, _is_required_grader(grader_spec))
            )

    if not normalized_scores:
        any_misconfigured = True
        misconfigurations.append(
            {"error": "At least one scoring grader must be configured"}
        )

    total_points = sum(score_weights)
    awarded_points = sum(
        score * weight for score, weight in zip(normalized_scores, score_weights)
    )
    aggregate_score = awarded_points / total_points if total_points > 0.0 else 0.0
    if hard_fail_triggered or hard_fail_unavailable:
        aggregate_score = 0.0
        awarded_points = 0.0

    pass_rule, scoring_ok, required_failed, pass_rule_error = (
        _evaluate_top_level_pass_rule(scoring, scoring_entries, awarded_points)
    )
    if pass_rule_error is not None:
        any_misconfigured = True
        misconfigurations.append({"error": pass_rule_error})

    aggregate_passed: bool | None
    if hard_fail_triggered:
        aggregate_passed = False
    elif any_misconfigured or any_system_error or hard_fail_unavailable:
        aggregate_passed = None
    else:
        aggregate_passed = scoring_ok

    metrics["num_graders"] = len(grader_specs)
    metrics["num_scoring_graders"] = len(normalized_scores)
    if pass_rule != "all":
        metrics["pass_rule"] = pass_rule
        if required_failed:
            metrics["required_graders_failed"] = required_failed
    if any(weight != 1.0 for weight in score_weights):
        # Only surfaced for weighted bundles so unweighted metrics payloads
        # (and their downstream consumers) stay byte-identical.
        metrics["awarded_points"] = awarded_points
        metrics["total_points"] = total_points
    if hard_fail_triggered:
        metrics["hard_fail_triggered"] = hard_fail_triggered
    if hard_fail_unavailable:
        metrics["hard_fail_unavailable"] = hard_fail_unavailable
    if misconfigurations:
        metrics["grader_misconfigurations"] = misconfigurations
    if any_system_error:
        metrics["grader_system_error"] = True

    return {
        "passed": aggregate_passed,
        "metrics": metrics,
        "reasoning": "\n\n".join(reasoning_parts),
        "agent_answer": agent_answer,
        "score": aggregate_score,
        "raw_score": aggregate_score,
        "score_max": 1.0,
        "field_scores": field_scores,
    }


def _single_grader_result_payload(
    grader_result: Optional[dict[str, Any]],
    aggregate_result: dict[str, Any],
) -> dict[str, Any]:
    """Expose aggregate status without discarding the leaf's diagnostics."""
    if aggregate_result.get("reward_type") == CONFIDENCE_REWARD:
        # In particular, a rejected bundle must not retain the leaf's valid /
        # finite state while replacing only its numeric score with null.
        return aggregate_result
    if not isinstance(grader_result, dict):
        return aggregate_result

    result = dict(grader_result)
    result["passed"] = aggregate_result["passed"]
    result["score"] = aggregate_result["score"]

    aggregate_metrics = aggregate_result.get("metrics")
    grader_metrics = grader_result.get("metrics")
    if isinstance(aggregate_metrics, dict) and isinstance(grader_metrics, dict):
        # Preserve grader-specific values on collisions (for example an
        # all_of's child-level hard_fail_triggered list), while adding the
        # aggregate diagnostics that explain a fail-closed top-level result.
        result["metrics"] = {**aggregate_metrics, **grader_metrics}
    return result


def _aggregate_has_grader_system_error(aggregate_result: dict[str, Any]) -> bool:
    metrics = aggregate_result.get("metrics")
    return isinstance(metrics, dict) and metrics.get("grader_system_error") is True


def grade_agent_answer(
    eval_json: dict[str, Any], agent_answer: Optional[dict[str, Any]]
) -> GradingResult:
    if agent_answer is None:
        return GradingResult()

    graders = eval_json.get("graders")
    if isinstance(graders, list):
        grader_results = [
            run_single_grader(grader_spec, agent_answer) for grader_spec in graders
        ]
        grader_result = aggregate_grader_results(
            agent_answer, graders, grader_results, scoring=eval_json.get("scoring")
        )
        aggregate_passed = grader_result["passed"]
        return GradingResult(
            passed=(aggregate_passed if isinstance(aggregate_passed, bool) else None),
            score=grader_result["score"],
            grader_result=grader_result,
            grader_results=grader_results,
            grader_system_error=_aggregate_has_grader_system_error(grader_result),
        )

    grader_spec = eval_json.get("grader")
    if grader_spec is None:
        return GradingResult()
    grader_result = run_single_grader(grader_spec, agent_answer)
    aggregate_result = aggregate_grader_results(
        agent_answer, [grader_spec], [grader_result],
        scoring=eval_json.get("scoring") if contains_confidence_grader(grader_spec) else None,
    )
    aggregate_passed = aggregate_result["passed"]

    return GradingResult(
        passed=aggregate_passed if isinstance(aggregate_passed, bool) else None,
        score=aggregate_result["score"],
        grader_result=_single_grader_result_payload(grader_result, aggregate_result),
        grader_system_error=_aggregate_has_grader_system_error(aggregate_result),
    )


async def async_grade_agent_answer(
    keys: ApiKeyResolver | LlmGraderExecutor,
    eval_json: dict[str, Any],
    agent_answer: Optional[dict[str, Any]],
    *,
    refusal_fallback: bool = False,
    artifacts: Optional[ArtifactRunner] = None,
) -> GradingResult:
    if agent_answer is None:
        return GradingResult()

    graders = eval_json.get("graders")
    if isinstance(graders, list):
        grader_results = [
            await run_single_grader_async(
                keys.child(index) if isinstance(keys, LlmGraderExecutor) else keys,
                grader_spec,
                agent_answer,
                refusal_fallback=refusal_fallback,
                artifacts=artifacts,
            )
            for index, grader_spec in enumerate(graders)
        ]
        grader_result = aggregate_grader_results(
            agent_answer, graders, grader_results, scoring=eval_json.get("scoring")
        )
        aggregate_passed = grader_result["passed"]
        return GradingResult(
            passed=(aggregate_passed if isinstance(aggregate_passed, bool) else None),
            score=grader_result["score"],
            grader_result=grader_result,
            grader_results=grader_results,
            grader_system_error=_aggregate_has_grader_system_error(grader_result),
        )

    grader_spec = eval_json.get("grader")
    if grader_spec is None:
        return GradingResult()
    grader_result = await run_single_grader_async(
        keys,
        grader_spec,
        agent_answer,
        refusal_fallback=refusal_fallback,
        artifacts=artifacts,
    )
    aggregate_result = aggregate_grader_results(
        agent_answer, [grader_spec], [grader_result],
        scoring=eval_json.get("scoring") if contains_confidence_grader(grader_spec) else None,
    )
    aggregate_passed = aggregate_result["passed"]

    return GradingResult(
        passed=aggregate_passed if isinstance(aggregate_passed, bool) else None,
        score=aggregate_result["score"],
        grader_result=_single_grader_result_payload(grader_result, aggregate_result),
        grader_system_error=_aggregate_has_grader_system_error(aggregate_result),
    )
