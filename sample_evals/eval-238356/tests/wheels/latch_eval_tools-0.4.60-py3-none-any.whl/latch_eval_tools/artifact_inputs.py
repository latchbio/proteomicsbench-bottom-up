"""Stage Decisions-selected files at the input paths declared by an artifact grader.

The eval declares the package's input contract. No package identities or inferred
filenames participate in input selection; Decisions supplies the verified source files.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from latch_eval_tools.artifact_resolution import (
    file_digest,
    submission_file,
    verified_bindings,
)
from latch_eval_tools.graders.artifact import is_artifact_grader_path


def _relative_path(relative: str) -> Path:
    if not is_artifact_grader_path(relative):
        raise ValueError("grader_path must be a normalized relative file path")
    return Path(relative)


def _copy_verified(source: Path, destination: Path, digest: str) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as incoming, destination.open("xb") as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    if file_digest(destination) != digest:
        raise ValueError("artifact input changed while being copied")


def stage_artifact_inputs(
    grader_paths: dict[str, str],
    *,
    rollout_output_dir: Path,
    artifact_map_path: Path,
    destination: Path,
) -> dict[str, Any]:
    """Copy selected inputs into an empty private directory and record their provenance.

    The caller handles missing required roles before execution. Missing optional roles
    produce no file. Preserve the standard answer context unless an artifact role owns
    its path; other submission inputs must be declared as artifact roles. The caller
    retains the trajectory argument and package working directory/reference assets.
    """
    if not isinstance(grader_paths, dict) or not grader_paths:
        raise ValueError("grader_paths must declare every artifact role")
    if rollout_output_dir.is_symlink() or not rollout_output_dir.is_dir():
        raise ValueError("artifact submission directory is missing or unsafe")
    if (
        destination.is_symlink()
        or not destination.is_dir()
        or any(destination.iterdir())
        or destination.resolve().is_relative_to(rollout_output_dir.resolve())
    ):
        raise ValueError(
            "artifact destination must be empty and outside the submission"
        )

    paths = [_relative_path(relative) for relative in grader_paths.values()]
    for index, path in enumerate(paths):
        if any(
            path == other or path in other.parents or other in path.parents
            for other in paths[:index]
        ):
            raise ValueError("grader_path destinations collide")
        if Path("eval_answer.json") in path.parents:
            raise ValueError(
                "grader_path conflicts with the eval_answer.json context file"
            )

    resolution = json.loads(artifact_map_path.read_text(encoding="utf-8"))
    bindings = resolution.get("bindings") if isinstance(resolution, dict) else None
    if not isinstance(bindings, dict) or set(bindings) != set(grader_paths):
        raise ValueError("artifact roles do not match the declared grader_paths")
    if any(
        not isinstance(binding, dict)
        or binding.get("status") not in {"resolved", "missing"}
        for binding in bindings.values()
    ):
        raise ValueError("artifact inputs must be resolved or optional and missing")
    selected = verified_bindings(rollout_output_dir, resolution)

    # A declared role owns its destination even when its optional input is missing.
    # Never substitute the original answer for a Decisions-selected answer artifact.
    answer = None
    if "eval_answer.json" not in grader_paths.values():
        candidate = rollout_output_dir / "eval_answer.json"
        if candidate.is_symlink():
            raise ValueError("artifact context paths cannot contain symlinks")
        if candidate.exists():
            answer = submission_file(rollout_output_dir, "eval_answer.json")

    audit: dict[str, Any] = {"artifacts": {}, "passthrough": []}
    for role, relative in grader_paths.items():
        binding = bindings[role]
        if binding["status"] == "missing":
            continue
        _copy_verified(Path(selected[role]), destination / relative, binding["sha256"])
        audit["artifacts"][role] = {
            "source_path": binding["path"],
            "grader_path": relative,
            "sha256": binding["sha256"],
        }
    if answer is not None:
        _copy_verified(answer, destination / "eval_answer.json", file_digest(answer))
        audit["passthrough"].append("eval_answer.json")
    return audit
