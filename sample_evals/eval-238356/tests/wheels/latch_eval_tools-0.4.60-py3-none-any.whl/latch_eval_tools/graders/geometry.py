from __future__ import annotations

import importlib
import math
from dataclasses import dataclass
from fractions import Fraction
from itertools import pairwise
from typing import Any, cast

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_bipartite_matching
from shapely import constrained_delaunay_triangles, unary_union
from shapely.errors import GEOSException
from shapely.geometry import Point, Polygon
from shapely.geometry.base import BaseGeometry
from shapely.validation import explain_validity

from .number_contract import is_finite_number

trimesh = importlib.import_module("trimesh")

# some def constants, maybe change
_VOL_PLAN_TOL = 1e-6
_VOL_MIN_RING_STEP = 0.0
_VOL_SAMPLES_PER_RING = 64
_MAX_PATH_POINTS = 1024
_MAX_PATH_LIST_COUNT = 128
_MAX_PATH_LIST_POINTS = 4096
_MAX_PATH_LIST_WORK = 10_000_000
_MAX_PATH_INTERSECTION_CHECKS = 3_000_000
_MAX_PATH_DISTANCE_EVALUATIONS = 75_000_000
_PATH_DISTANCE_BATCH_SIZE = 262_144
_PATH_MIN_RELATIVE_SCALE = 1e-150
_MAX_LOCATION_LIST_COUNT = 4096
_MAX_POLYGON_LIST_COUNT = 256
_MAX_POLYGON_POINTS = 4096
_MAX_VOLUME_POINTS = 8192
_MAX_VOLUME_LIST_COUNT = 64
_MAX_VOLUME_LIST_POINTS = 32768
_MATCHING_STRATEGIES = ("greedy", "optimal")
_SCORING_MODES = ("binary", "continuous")
# Dense assignment is cubic; above this many candidate cells fall back to a
# sparse maximum-cardinality matching without the quality tie-break.
_MAX_OPTIMAL_ASSIGNMENT_CELLS = 1_000_000
_RADIUS_REL_TOL = 1e-9
_RADIUS_ABS_TOL = 1e-12
_VOLUME_IOU_EXACT_TOL = 1e-6
_RING_CLOSURE_REL_TOL = 1e-9


class GeometryBackendError(RuntimeError):
    pass


@dataclass
class LFrame:
    origin: np.ndarray
    axis: np.ndarray
    axis_u: np.ndarray
    axis_v: np.ndarray


@dataclass
class PreppedRing:
    vertices_3d: np.ndarray
    vertices_2d: np.ndarray
    depth: float
    max_plan_err: float
    polygon_2d: Polygon


@dataclass
class _RingParameterCluster:
    parameter: float
    ring_values: dict[int, float]


def normalize_coords(loc: object, err_label: str) -> list[float]:
    if not isinstance(loc, list):
        raise ValueError(f"{err_label} must be an array")

    if len(loc) < 2:
        raise ValueError(f"{err_label} coordinate needs to have more than one axis")

    normed: list[float] = []

    for index, coordinate in enumerate(loc):
        if not is_finite_number(coordinate):
            raise ValueError(f"{err_label}[{index}] must be a finite number")

        try:
            parsed = float(coordinate)
            int_is_ex = not isinstance(coordinate, int) or int(parsed) == coordinate
        except (OverflowError, TypeError, ValueError):
            raise ValueError(
                f"{err_label}[{index}] cannot be represented as a float"
            ) from None

        if not int_is_ex:
            raise ValueError(
                f"{err_label}[{index}] cannot be represented exactly as a float"
            )

        normed.append(parsed)
    return normed


def normalize_coords_list(locs: object, err_label: str) -> list[list[float]]:

    if not isinstance(locs, list):
        raise ValueError(f"{err_label} location list has to be a list")

    normed_cords: list[list[float]] = []

    for i, v in enumerate(locs):
        cname = f"{err_label}[{i}]"
        cor = normalize_coords(v, cname)

        normed_cords.append(cor)

    return normed_cords


def normalize_path_coords(path: object, err_label: str) -> list[list[float]]:
    points = normalize_coords_list(path, err_label)
    if len(points) < 2:
        raise ValueError(f"{err_label} must contain at least two points")
    if len(points) > _MAX_PATH_POINTS:
        raise ValueError(f"{err_label} must contain at most {_MAX_PATH_POINTS} points")

    dimension = len(points[0])
    if dimension not in (2, 3, 4):
        raise ValueError(
            f"{err_label} points must have exactly two, three, or four coordinates"
        )
    if any(len(point) != dimension for point in points[1:]):
        raise ValueError(f"{err_label} points must have matching dimensions")
    if not any(start != end for start, end in pairwise(points)):
        raise ValueError(f"{err_label} must have positive length")

    return points


def normalize_path_list(paths: object, err_label: str) -> list[list[list[float]]]:
    if not isinstance(paths, list):
        raise ValueError(f"{err_label} must be a list of paths")
    if len(paths) > _MAX_PATH_LIST_COUNT:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_PATH_LIST_COUNT} paths"
        )

    normalized = [
        normalize_path_coords(path, f"{err_label}[{index}]")
        for index, path in enumerate(paths)
    ]
    if sum(len(path) for path in normalized) > _MAX_PATH_LIST_POINTS:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_PATH_LIST_POINTS} total points"
        )
    return normalized


def normalize_path_component_scales(
    component_scales: object, dimension: int, err_label: str = "component_scales"
) -> list[float]:
    if component_scales is None:
        return [1.0] * dimension

    scales = normalize_coords(component_scales, err_label)
    if len(scales) != dimension:
        raise ValueError(f"{err_label} must contain exactly {dimension} values")
    if any(scale <= 0 for scale in scales):
        raise ValueError(f"{err_label} values must be positive")
    maximum = max(scales)
    if min(scale / maximum for scale in scales) < _PATH_MIN_RELATIVE_SCALE:
        raise ValueError(f"{err_label} exceed supported numeric precision")
    return scales


def _point_to_segment_distances(
    points: np.ndarray, starts: np.ndarray, segments: np.ndarray
) -> np.ndarray:
    lengths_squared = np.einsum("ij,ij->i", segments, segments)
    offsets = points[:, np.newaxis, :] - starts[np.newaxis, :, :]
    projections = np.einsum("pij,ij->pi", offsets, segments)
    parameters = np.divide(
        projections,
        lengths_squared,
        out=np.zeros_like(projections),
        where=lengths_squared > 0,
    )
    parameters = np.clip(parameters, 0.0, 1.0)
    closest = starts + parameters[:, :, np.newaxis] * segments
    return np.linalg.norm(points[:, np.newaxis, :] - closest, axis=2)


def _distance_piece(
    source_start: np.ndarray,
    source_delta: np.ndarray,
    target_start: np.ndarray,
    target_delta: np.ndarray,
    zone: int,
) -> tuple[float, float, float]:
    if zone < 0:
        offset = source_start - target_start
        return (
            np.dot(source_delta, source_delta).item(),
            (2 * np.dot(offset, source_delta)).item(),
            np.dot(offset, offset).item(),
        )
    if zone > 0:
        offset = source_start - (target_start + target_delta)
        return (
            np.dot(source_delta, source_delta).item(),
            (2 * np.dot(offset, source_delta)).item(),
            np.dot(offset, offset).item(),
        )

    offset = source_start - target_start
    target_length_squared = np.dot(target_delta, target_delta).item()
    offset_projection = np.dot(offset, target_delta).item()
    delta_projection = np.dot(source_delta, target_delta).item()
    return (
        (
            np.dot(source_delta, source_delta)
            - (delta_projection * delta_projection / target_length_squared)
        ).item(),
        (
            2
            * (
                np.dot(offset, source_delta)
                - (offset_projection * delta_projection / target_length_squared)
            )
        ).item(),
        (
            np.dot(offset, offset)
            - (offset_projection * offset_projection / target_length_squared)
        ).item(),
    )


def _target_distance_pieces(
    source_start: np.ndarray,
    source_delta: np.ndarray,
    target_start: np.ndarray,
    target_end: np.ndarray,
) -> list[tuple[float, float, float, float, float]]:
    target_delta = target_end - target_start
    target_length_squared = np.dot(target_delta, target_delta).item()
    if target_length_squared == 0:
        a, b, c = _distance_piece(
            source_start,
            source_delta,
            target_start,
            target_delta,
            -1,
        )
        return [(0.0, 1.0, a, b, c)]

    offset = source_start - target_start
    alpha = np.dot(offset, target_delta).item() / target_length_squared
    beta = np.dot(source_delta, target_delta).item() / target_length_squared
    cuts = [0.0, 1.0]
    if beta != 0:
        cuts.extend(
            cut for cut in (-alpha / beta, (1.0 - alpha) / beta) if 0.0 < cut < 1.0
        )
    cuts = sorted(set(cuts))

    pieces = []
    for lower, upper in pairwise(cuts):
        projection = alpha + beta * ((lower + upper) / 2)
        zone = -1 if projection < 0 else 1 if projection > 1 else 0
        pieces.append(
            (
                lower,
                upper,
                *_distance_piece(
                    source_start,
                    source_delta,
                    target_start,
                    target_delta,
                    zone,
                ),
            )
        )
    return pieces


def _quadratic_intersections(
    first: tuple[float, float, float, float, float],
    second: tuple[float, float, float, float, float],
) -> list[float]:
    lower = max(first[0], second[0])
    upper = min(first[1], second[1])
    if lower > upper:
        return []

    a = first[2] - second[2]
    b = first[3] - second[3]
    c = first[4] - second[4]
    coefficient_scale = max(abs(a), abs(b), abs(c))
    if coefficient_scale == 0:
        return []
    a /= coefficient_scale
    b /= coefficient_scale
    c /= coefficient_scale
    tolerance = np.finfo(float).eps * 64
    if abs(a) <= tolerance:
        if abs(b) <= tolerance:
            return []
        roots = [-c / b]
    else:
        discriminant = (b * b) - (4 * a * c)
        if discriminant < -tolerance:
            return []
        root = math.sqrt(max(0.0, discriminant))
        q = -0.5 * (b + math.copysign(root, b))
        roots = [q / a] if q == 0 else [q / a, c / q]

    return [
        min(upper, max(lower, root))
        for root in roots
        if lower - tolerance <= root <= upper + tolerance
    ]


def _directed_path_hausdorff(source: np.ndarray, target: np.ndarray) -> float:
    maximum = 0.0
    intersection_checks = 0
    distance_evaluations = 0
    starts = target[:-1]
    segments = target[1:] - starts
    for source_start, source_end in pairwise(source):
        source_delta = source_end - source_start
        midpoint = source_start + 0.5 * source_delta
        midpoint_distances = _point_to_segment_distances(
            midpoint[None, :], starts, segments
        )[0]
        cutoff = np.min(midpoint_distances) + np.linalg.norm(source_delta)
        nearby = midpoint_distances <= cutoff + 64 * np.finfo(float).eps
        nearby_starts = starts[nearby]
        nearby_segments = segments[nearby]
        pieces = [
            piece
            for target_start, target_end in zip(
                nearby_starts, target[1:][nearby], strict=True
            )
            for piece in _target_distance_pieces(
                source_start,
                source_delta,
                target_start,
                target_end,
            )
        ]
        candidates = {0.0, 1.0}
        for piece in pieces:
            candidates.update((piece[0], piece[1]))
        intersection_checks += len(pieces) * (len(pieces) - 1) // 2
        if intersection_checks > _MAX_PATH_INTERSECTION_CHECKS:
            raise ValueError("path comparison exceeds supported complexity")
        distance_evaluations += len(segments)
        candidate_limit = (
            _MAX_PATH_DISTANCE_EVALUATIONS - distance_evaluations
        ) // len(nearby_segments)
        for index, first in enumerate(pieces):
            if len(candidates) > candidate_limit:
                raise ValueError("path comparison exceeds supported complexity")
            for second in pieces[index + 1 :]:
                candidates.update(_quadratic_intersections(first, second))

        parameters = np.asarray(sorted(candidates), dtype=float)
        distance_evaluations += len(parameters) * len(nearby_segments)
        if distance_evaluations > _MAX_PATH_DISTANCE_EVALUATIONS:
            raise ValueError("path comparison exceeds supported complexity")
        batch_size = _PATH_DISTANCE_BATCH_SIZE // len(nearby_segments)
        for offset in range(0, len(parameters), batch_size):
            batch = parameters[offset : offset + batch_size]
            points = source_start + batch[:, np.newaxis] * source_delta
            distances = _point_to_segment_distances(points, nearby_starts, nearby_segments)
            maximum = max(maximum, np.max(np.min(distances, axis=1)).item())
    return maximum


def _merge_collinear_segments(path: np.ndarray) -> np.ndarray:
    corners = [0]
    previous_direction = None
    previous = tuple(map(Fraction, path[0]))
    for index, point in enumerate(path[1:], start=1):
        current = tuple(map(Fraction, point))
        delta = tuple(end - start for start, end in zip(previous, current, strict=True))
        previous = current
        scale = next((abs(component) for component in delta if component), None)
        if scale is None:
            continue
        direction = tuple(component / scale for component in delta)
        if previous_direction is not None and direction != previous_direction:
            corners.append(index - 1)
        previous_direction = direction
    corners.append(len(path) - 1)
    return path[corners]


def _prepare_paths_for_distance(
    reference: np.ndarray,
    submitted: np.ndarray,
    scales: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, float, float]:
    maximum_component_scale = np.max(scales).item()
    relative_scales = scales / maximum_component_scale
    nonzero_segments = [
        [not np.array_equal(start, end) for start, end in pairwise(path)]
        for path in (reference, submitted)
    ]

    reference = reference * relative_scales
    submitted = submitted * relative_scales
    origin = reference[0].copy()
    with np.errstate(over="ignore", invalid="ignore"):
        translated_reference = reference - origin
        translated_submitted = submitted - origin

    if (
        np.isfinite(translated_reference).all()
        and np.isfinite(translated_submitted).all()
    ):
        coordinate_scale = np.max(
            np.abs(np.vstack([translated_reference, translated_submitted]))
        ).item()
        if not math.isfinite(coordinate_scale) or coordinate_scale <= 0:
            raise ValueError("path scale must be finite and positive")
        reference = translated_reference / coordinate_scale
        submitted = translated_submitted / coordinate_scale
    else:
        coordinate_scale = np.max(np.abs(np.vstack([reference, submitted]))).item()
        if not math.isfinite(coordinate_scale) or coordinate_scale <= 0:
            raise ValueError("path scale must be finite and positive")
        reference = reference / coordinate_scale
        submitted = submitted / coordinate_scale
        scaled_origin = reference[0].copy()
        reference -= scaled_origin
        submitted -= scaled_origin

    segment_lengths = []
    for path, path_nonzero_segments in zip(
        (reference, submitted), nonzero_segments, strict=True
    ):
        for (start, end), was_nonzero in zip(
            pairwise(path), path_nonzero_segments, strict=True
        ):
            if not was_nonzero:
                continue
            length = math.dist(start, end)
            if length == 0:
                raise ValueError(
                    "path segment scales exceed supported numeric precision"
                )
            segment_lengths.append(length)

    longest_segment = max(segment_lengths)
    if min(segment_lengths) < longest_segment * _PATH_MIN_RELATIVE_SCALE:
        raise ValueError("path segment scales exceed supported numeric precision")

    return (
        _merge_collinear_segments(reference),
        _merge_collinear_segments(submitted),
        coordinate_scale,
        maximum_component_scale,
    )


def validate_path_numeric_support(
    path: object,
    *,
    component_scales: object = None,
    err_label: str = "path",
) -> None:
    points = np.asarray(normalize_path_coords(path, err_label), dtype=float)
    scales = np.asarray(
        normalize_path_component_scales(component_scales, points.shape[1]),
        dtype=float,
    )
    prepared, _, _, _ = _prepare_paths_for_distance(points, points, scales)
    try:
        _directed_path_hausdorff(prepared, prepared)
    except ValueError:
        raise ValueError(
            f"{err_label} exceeds supported comparison complexity for an exact answer"
        ) from None


def path_hausdorff_distance(
    reference_path: object,
    submitted_path: object,
    *,
    component_scales: object = None,
) -> float:
    reference = np.asarray(
        normalize_path_coords(reference_path, "reference path"), dtype=float
    )
    submitted = np.asarray(
        normalize_path_coords(submitted_path, "submitted path"), dtype=float
    )
    if reference.shape[1] != submitted.shape[1]:
        raise ValueError("reference path and submitted path dimensions must match")

    scales = np.asarray(
        normalize_path_component_scales(component_scales, reference.shape[1]),
        dtype=float,
    )
    reference, submitted, coordinate_scale, maximum_component_scale = (
        _prepare_paths_for_distance(reference, submitted, scales)
    )
    normalized_distance = max(
        _directed_path_hausdorff(reference, submitted),
        _directed_path_hausdorff(submitted, reference),
    )
    distance = normalized_distance * coordinate_scale * maximum_component_scale
    if not math.isfinite(distance):
        raise ValueError("path distance must be finite")
    return distance


def path_within_radius_match(
    reference_path: object,
    submitted_path: object,
    radius: float,
    *,
    component_scales: object = None,
) -> float:
    if not is_finite_number(radius) or radius < 0:
        raise ValueError("radius must be a finite non-negative number")

    distance = path_hausdorff_distance(
        reference_path,
        submitted_path,
        component_scales=component_scales,
    )
    return 1.0 if _within_radius(distance, radius) else 0.0


def normalize_polygon_coords(polygon: object, err_label: str) -> Polygon:

    if not isinstance(polygon, list):
        raise ValueError(f"{err_label} polygons need to be a list of list of floats!")

    if len(polygon) < 3:
        raise ValueError(f"{err_label} a polygon needs at least three points")
    if len(polygon) > _MAX_POLYGON_POINTS:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_POLYGON_POINTS} points"
        )

    normed_vecs = []

    for ind, v in enumerate(polygon):
        norm = normalize_coords(v, f"{err_label}[{ind}]")
        normed_vecs.append(norm)

        if len(norm) != 2:
            raise ValueError(f"{err_label}[{ind}] must contain exactly two coordinates")

    unique_vert = normed_vecs
    # kick out if First is last
    if normed_vecs[0] == normed_vecs[-1]:
        unique_vert = normed_vecs[:-1]

    if len({tuple(vertex) for vertex in unique_vert}) < 3:
        raise ValueError(f"{err_label} must contain at least three unique vertices")

    try:
        result = Polygon(normed_vecs)
    except (GEOSException, TypeError, ValueError) as exc:
        raise ValueError(f"{err_label} could not be constructed: {exc}") from None

    if result.is_empty:
        raise ValueError(f"{err_label} must be not empty")

    if not result.is_valid:
        reas = explain_validity(result)
        raise ValueError(f"polygon {err_label} is not a valid polygon, reason: {reas}")

    if not math.isfinite(result.area) or result.area <= 0:
        raise ValueError(f"{err_label} must have a finite positive area")

    return result


def normalize_polygon_list(polygons: object, err_label: str) -> list[Polygon]:
    if not isinstance(polygons, list):
        raise ValueError(f"{err_label} must be a list of polygons")

    return [
        normalize_polygon_coords(polygon, f"{err_label}[{index}]")
        for index, polygon in enumerate(polygons)
    ]


def _polygon_iou(ref_p: BaseGeometry, sub_p: BaseGeometry) -> float:
    try:
        interse_ar = ref_p.intersection(sub_p).area
    except GEOSException as exc:
        raise GeometryBackendError(f"polygon intersection failed: {exc}") from exc

    try:
        union_area = ref_p.union(sub_p).area
    except GEOSException as exc:
        raise GeometryBackendError(f"polygon union failed: {exc}") from exc

    if not math.isfinite(interse_ar):
        raise ValueError("polygon intersection produced a non finite area")

    if not math.isfinite(union_area) or union_area <= 0:
        raise ValueError("polygon union must have a positive, finite area!!!")

    iou = interse_ar / union_area
    return min(1.0, max(0.0, iou))


def iou_polygon_to_polygon(ref_polygon: object, sub_polygon: object) -> float:
    ref_p = normalize_polygon_coords(ref_polygon, "reference polygon")
    sub_p = normalize_polygon_coords(sub_polygon, "submitted polygon")
    return _polygon_iou(ref_p, sub_p)


def normalize_reference_polygon_set(polygons: object, err_label: str) -> list[Polygon]:
    normalized = normalize_polygon_list(polygons, err_label)
    if not normalized:
        raise ValueError(f"{err_label} must not be empty")
    if len(normalized) > _MAX_POLYGON_LIST_COUNT:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_POLYGON_LIST_COUNT} polygons"
        )
    return normalized


def normalize_count_bounds(
    bounds: object, err_label: str, *, limit: int
) -> tuple[int | None, int | None]:
    if bounds is None:
        return None, None
    if not isinstance(bounds, dict):
        raise ValueError(f"{err_label} must be an object with 'min' and/or 'max'")
    unknown = set(bounds) - {"min", "max"}
    if unknown:
        raise ValueError(f"{err_label} has unsupported keys: {sorted(unknown)}")
    if not bounds:
        raise ValueError(f"{err_label} must define 'min' and/or 'max'")

    parsed: dict[str, int | None] = {}
    for key in ("min", "max"):
        value = bounds.get(key)
        if value is None:
            parsed[key] = None
            continue
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"{err_label}.{key} must be an integer")
        if value < 1:
            raise ValueError(f"{err_label}.{key} must be at least 1")
        if value > limit:
            raise ValueError(f"{err_label}.{key} must be at most {limit}")
        parsed[key] = value

    minimum, maximum = parsed["min"], parsed["max"]
    if minimum is not None and maximum is not None and minimum > maximum:
        raise ValueError(f"{err_label}.min must not exceed {err_label}.max")
    return minimum, maximum


def normalize_overlap_fraction(
    fraction: object, err_label: str = "max_overlap_fraction"
) -> float | None:
    if fraction is None:
        return None
    if isinstance(fraction, bool) or not isinstance(fraction, (int, float)):
        raise ValueError(f"{err_label} must be a finite number in [0, 1]")
    if not is_finite_number(fraction) or not 0 <= fraction <= 1:
        raise ValueError(f"{err_label} must be a finite number in [0, 1]")
    return float(fraction)


def normalize_iou_ramp(
    iou_none: object,
    iou_full: object,
    *,
    none_label: str = "iou_none",
    full_label: str = "iou_full",
) -> tuple[float, float]:
    """Validate the optional score ramp for IoU operations.

    ``iou_none`` is the no-go floor: an IoU at or below it scores zero.
    ``iou_full`` is the full-credit ceiling: an IoU at or above it scores one.
    The defaults ``0`` and ``1`` make the ramp the identity.
    """

    values: list[float] = []
    for value, label, default in (
        (iou_none, none_label, 0.0),
        (iou_full, full_label, 1.0),
    ):
        if value is None:
            values.append(default)
            continue
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not is_finite_number(value)
            or not 0 <= value <= 1
        ):
            raise ValueError(f"{label} must be a finite number in [0, 1]")
        values.append(float(value))
    none, full = values
    if none >= full:
        raise ValueError(f"{none_label} must be less than {full_label}")
    return none, full


def ramp_iou(iou: float, iou_none: float, iou_full: float) -> float:
    if iou >= iou_full:
        return 1.0
    if iou <= iou_none:
        return 0.0
    return (iou - iou_none) / (iou_full - iou_none)


def _at_most(value: float, limit: float) -> bool:
    return value <= limit or math.isclose(
        value, limit, rel_tol=_RADIUS_REL_TOL, abs_tol=_RADIUS_ABS_TOL
    )


def _polygon_union(polygons: list[Polygon], err_label: str) -> BaseGeometry:
    try:
        union = unary_union(polygons)
    except GEOSException as exc:
        raise GeometryBackendError(f"{err_label} union failed: {exc}") from exc
    if not math.isfinite(union.area):
        raise ValueError(f"{err_label} union produced a non finite area")
    return union


def polygon_union_iou(
    reference_polygons: object,
    submitted_polygons: object,
    *,
    polygon_count: object = None,
    max_overlap_fraction: object = None,
) -> float:
    """IoU between the union of the reference polygons and the union of the
    submitted polygons. The score does not depend on how either side is split
    into pieces, only on the region they cover together.

    ``polygon_count`` bounds how many polygons the submission may contain and
    ``max_overlap_fraction`` bounds the share of the submitted area that is
    covered more than once. Violating either makes the submission invalid.
    """

    references = normalize_reference_polygon_set(
        reference_polygons, "reference polygons"
    )
    minimum, maximum = normalize_count_bounds(
        polygon_count, "polygon_count", limit=_MAX_POLYGON_LIST_COUNT
    )
    overlap_limit = normalize_overlap_fraction(max_overlap_fraction)

    items = _submitted_items(
        submitted_polygons, "submitted polygons", _MAX_POLYGON_LIST_COUNT
    )
    if minimum is not None and len(items) < minimum:
        raise ValueError(
            f"submitted polygons must contain at least {minimum} polygons, got {len(items)}"
        )
    if maximum is not None and len(items) > maximum:
        raise ValueError(
            f"submitted polygons must contain at most {maximum} polygons, got {len(items)}"
        )

    submissions = normalize_polygon_list(items, "submitted polygons")
    if not submissions:
        return 0.0

    submitted_union = _polygon_union(submissions, "submitted polygons")
    if overlap_limit is not None:
        _check_overlap_fraction(
            [polygon.area for polygon in submissions],
            submitted_union.area,
            overlap_limit,
            "submitted polygons",
            "area",
        )

    reference_union = _polygon_union(references, "reference polygons")
    return _polygon_iou(reference_union, submitted_union)


def _check_overlap_fraction(
    measures: list[float], union_measure: float, limit: float, err_label: str, unit: str
) -> None:
    total = sum(measures)
    if not math.isfinite(total) or total <= 0:
        raise ValueError(f"{err_label} must have a finite positive total {unit}")
    overlap = min(1.0, max(0.0, (total - union_measure) / total))
    if not _at_most(overlap, limit):
        raise ValueError(
            f"{err_label} overlap on {overlap:.4f} of their total {unit}, "
            f"more than the allowed {limit}"
        )


# --------------------------------- VOLUMETRIC STUFF \/ \/ \/


def normalize_volume_coords(vol: object, err_label: str):

    if not isinstance(vol, list):
        raise ValueError(f"{err_label} must be a list of rings!")

    if len(vol) < 2:
        raise ValueError(f"{err_label} must have at least two rings")

    open_rings: list[np.ndarray] = []

    for ri, r in enumerate(vol):
        ring_label = f"{err_label}[{ri}]"

        if not isinstance(r, list):
            raise ValueError(f"{ring_label} is not a polygon, ie list of vectors")

        if len(r) < 3:
            raise ValueError(
                f"{ring_label} each ring polygon needs to have at least 3 vectors"
            )

        normed_ring: list[list[float]] = []

        for vi, v in enumerate(r):
            v_label = f"{ring_label}[{vi}]"

            point = normalize_coords(v, v_label)

            if len(point) != 3:
                raise ValueError(f"{v_label} must contain 3 components")

            normed_ring.append(point)

        points = np.asarray(normed_ring, dtype=float)
        ring_scale = np.max(np.ptp(points, axis=0)).item()
        if len(points) > 1 and np.allclose(
            points[0], points[-1], rtol=0.0, atol=ring_scale * _RING_CLOSURE_REL_TOL
        ):
            points = points[:-1]

        if len(points) < 3 or len(np.unique(points, axis=0)) < 3:
            raise ValueError(f"{ring_label} must have at least 3 unique vecs")

        open_rings.append(points)

    if sum(len(points) for points in open_rings) > _MAX_VOLUME_POINTS:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_VOLUME_POINTS} points"
        )

    first_ring = open_rings[0]
    first_anchor = first_ring[0]
    first_centroid = first_anchor + np.mean(first_ring - first_anchor, axis=0)
    centered_first_ring = first_ring - first_centroid
    centered_scale = np.max(np.abs(centered_first_ring)).item()
    if not math.isfinite(centered_scale) or centered_scale <= 0:
        raise ValueError(f"{err_label}[0] defines a degenerate plane")

    try:
        _, singular_vals, right_vecs = np.linalg.svd(
            centered_first_ring / centered_scale,
            full_matrices=False,
        )
    except np.linalg.LinAlgError as exc:
        raise ValueError(f"{err_label} could not build loft axis!, err {exc}") from None

    if len(singular_vals) < 2 or singular_vals[1] <= 0:
        raise ValueError(f"{err_label}[0] defines a not degenerate plane!!!!!!")

    loft_axis = right_vecs[-1]
    if loft_axis[np.argmax(np.abs(loft_axis))] < 0:
        loft_axis = -loft_axis

    last_ring = open_rings[-1]
    last_anchor = last_ring[0]
    last_centroid = last_anchor + np.mean(last_ring - last_anchor, axis=0)
    try:
        total_progress = float(np.dot(last_centroid - first_centroid, loft_axis))
    except (TypeError, ValueError):
        raise ValueError(f"{err_label} loft progress could not be computed") from None

    if not math.isfinite(total_progress) or total_progress == 0:
        raise ValueError(
            f"{err_label} fors not progress away from the plane defined by the first ring!!!!!"
        )

    if total_progress < 0:
        open_rings = open_rings[::-1]
        first_ring = open_rings[0]
        first_centroid = first_ring[0] + np.mean(first_ring - first_ring[0], axis=0)

    frame = build_lframe(axis=loft_axis.tolist(), origin=first_centroid.tolist())
    normed_rings = [points.tolist() for points in open_rings]

    try:
        prepped_rings = prep_loft(
            normed_rings,
            frame=frame,
            plan_tol=_VOL_PLAN_TOL,
            min_ring_sep=_VOL_MIN_RING_STEP,
        )

        return build_loft_mesh(
            prepped_rings, frame=frame, smpls_per_ring=_VOL_SAMPLES_PER_RING
        )
    except ValueError as exc:
        raise ValueError(f"{err_label} is invalid because of > {exc}") from None


def build_lframe(axis: object, origin: object) -> LFrame:
    axis_array = np.asarray(normalize_coords(axis, "loft axis"), dtype=float)
    origin_array = np.asarray(normalize_coords(origin, "loft origin"), dtype=float)

    if axis_array.shape != (3,):
        raise ValueError("loft axis needs to be a vec with 3 components")

    if origin_array.shape != (3,):
        raise ValueError("loft origin must be a vec with 3 components")

    if not np.isfinite(axis_array).all():
        raise ValueError("loft axis must be finite")

    if not np.isfinite(origin_array).all():
        raise ValueError("origin axis must be finite")

    axis_length = np.linalg.norm(axis_array)
    if axis_length <= 0:
        raise ValueError("loft axis must be non 0")

    axis_array = axis_array / axis_length

    helper = np.eye(3)[np.argmin(np.abs(axis_array))]

    axis_u = np.cross(helper, axis_array)
    axis_u = axis_u / np.linalg.norm(axis_u)

    axis_v = np.cross(axis_array, axis_u)
    axis_v = axis_v / np.linalg.norm(axis_v)

    return LFrame(origin=origin_array, axis=axis_array, axis_u=axis_u, axis_v=axis_v)


def prep_ring(
    ring: object, *, frame: LFrame, plane_tol: float, err_label: str
) -> PreppedRing:
    if not is_finite_number(plane_tol) or plane_tol < 0:
        raise ValueError("plane_tol must be a finite non-negative number")

    if not isinstance(ring, list):
        raise ValueError(f"{err_label} must be an array")

    if len(ring) < 3:
        raise ValueError(f"{err_label} must contain at least three vertices")

    normed: list[list[float]] = []

    for i, v in enumerate(ring):
        point = normalize_coords(v, f"{err_label}[{i}]")

        if len(point) != 3:
            raise ValueError(f"{err_label}[{i}] vector must have exactly 3 components")

        normed.append(point)

    points = np.asarray(normed, dtype=float)

    if len(points) > 1 and np.array_equal(points[0], points[-1]):
        points = points[:-1]

    if len(points) < 3:
        raise ValueError(f"{err_label} must contain at least 3 vertices")

    if len(np.unique(points, axis=0)) < 3:
        raise ValueError(f"{err_label} must contain at least 3 unique vertices")

    relative = points - frame.origin

    local_u = relative @ frame.axis_u
    local_v = relative @ frame.axis_v
    depths = relative @ frame.axis

    try:
        ring_depth = float(np.mean(depths))
        max_error = float(np.max(np.abs(depths - ring_depth)))
    except (TypeError, ValueError):
        raise ValueError(f"{err_label} planarity error could not be computed") from None

    if max_error > plane_tol:
        raise ValueError(
            f"{err_label} exceeds plance tolerance \n{max_error} > {plane_tol}"
        )

    vertices_2d = np.column_stack([local_u, local_v])

    edges = np.roll(vertices_2d, -1, axis=0) - vertices_2d
    if np.any(np.all(edges == 0, axis=1)):
        raise ValueError(f"{err_label} contains consecutive duplicate vertices")

    planar_scale = np.max(np.abs(vertices_2d)).item()
    if not math.isfinite(planar_scale) or planar_scale <= 0:
        raise ValueError(f"{err_label} has invalid projected coordinates")
    normalized_vertices = vertices_2d / planar_scale
    x = normalized_vertices[:, 0]
    y = normalized_vertices[:, 1]

    signed_area = 0.5 * np.sum(x * np.roll(y, -1) - np.roll(x, -1) * y)

    if signed_area == 0:
        raise ValueError(f"{err_label} has 0 projected area")

    if signed_area < 0:
        vertices_2d = vertices_2d[::-1]
        normalized_vertices = normalized_vertices[::-1]
        points = points[::-1]

    polygon = Polygon(normalized_vertices)

    if polygon.is_empty:
        raise ValueError(f"{err_label} must not be empty")

    if not polygon.is_valid:
        raise ValueError(f"{err_label} invalid, reason: {explain_validity(polygon)}")

    if not np.isfinite(polygon.area) or polygon.area <= 0:
        raise ValueError(f"{err_label} must have a positive finite area")

    vertices_3d = (
        frame.origin
        + vertices_2d[:, 0, None] * frame.axis_u
        + vertices_2d[:, 1, None] * frame.axis_v
        + ring_depth * frame.axis
    )

    return PreppedRing(
        vertices_2d=vertices_2d,
        vertices_3d=vertices_3d,
        depth=ring_depth,
        max_plan_err=max_error,
        polygon_2d=polygon,
    )


def prep_loft(
    rings: object, *, frame: LFrame, plan_tol: float, min_ring_sep: float
) -> list[PreppedRing]:
    if not is_finite_number(plan_tol) or plan_tol < 0:
        raise ValueError("plan_tol must be a finite non-negative number")

    if not is_finite_number(min_ring_sep) or min_ring_sep < 0:
        raise ValueError("min_ring_sep must be a finite non-negative number")

    if not isinstance(rings, list):
        raise ValueError("rings must be an array")

    if len(rings) < 2:
        raise ValueError("construction of the volume requires at least two rings")

    prepp = [
        prep_ring(r, frame=frame, plane_tol=plan_tol, err_label=f"rings[{i}]")
        for i, r in enumerate(rings)
    ]

    depths = np.asarray([r.depth for r in prepp], dtype=float)

    seps = np.diff(depths)

    if np.any(seps <= 0) or np.any(seps < min_ring_sep):
        raise ValueError(
            f"rings must progress along loft axis with at least {min_ring_sep} separation"
        )

    return prepp


def _ring_breakpoints(vertices_2d: np.ndarray) -> np.ndarray:
    points = np.asarray(vertices_2d, dtype=float)

    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError("ring must have shape (n, 2)")

    edge_vectors = np.roll(points, -1, axis=0) - points
    edge_scales = np.max(np.abs(edge_vectors), axis=1)
    if np.any(edge_scales <= 0):
        raise ValueError("ring contains a zero length edge")
    edge_lens = edge_scales * np.linalg.norm(
        edge_vectors / edge_scales[:, np.newaxis],
        axis=1,
    )

    outline = np.sum(edge_lens).item()
    if not math.isfinite(outline) or outline <= 0:
        raise ValueError("ring perimeter must be finite and positive")

    return np.concatenate([[0.0], np.cumsum(edge_lens)[:-1]]) / outline


def _sample_closed_ring(vertices_2d: np.ndarray, parameters: np.ndarray) -> np.ndarray:
    points = np.asarray(vertices_2d, dtype=float)
    parameters = np.asarray(parameters, dtype=float)
    breakpoints = _ring_breakpoints(points)

    if (
        parameters.ndim != 1
        or len(parameters) < 3
        or not np.isfinite(parameters).all()
        or np.any(parameters < 0)
        or np.any(parameters >= 1)
    ):
        raise ValueError("ring parameters must be finite values in [0, 1)")

    edge_indices = np.searchsorted(breakpoints[1:], parameters, side="right")
    starts = breakpoints[edge_indices]
    ends = np.concatenate([breakpoints[1:], [1.0]])[edge_indices]
    fractions = (parameters - starts) / (ends - starts)
    next_points = np.roll(points, -1, axis=0)

    return points[edge_indices] + (
        (next_points[edge_indices] - points[edge_indices]) * fractions[:, None]
    )


def resample_closed_ring(vertices_2d: np.ndarray, *, count: int) -> np.ndarray:
    if isinstance(count, bool) or not isinstance(count, int) or count < 3:
        raise ValueError("count must be an integer of at least 3")

    return _sample_closed_ring(
        vertices_2d,
        np.linspace(0.0, 1.0, count, endpoint=False),
    )


def align_adjacent_ring(previous: np.ndarray, current: np.ndarray) -> np.ndarray:
    previous = np.asarray(previous, dtype=float)
    current = np.asarray(current, dtype=float)

    if previous.shape != current.shape:
        raise ValueError("adj resampled rings must have matching shapes")

    best_shift = 0
    best_cost = math.inf

    for shift in range(len(current)):
        shifted = np.roll(current, -shift, axis=0)
        cost = np.sum((previous - shifted) ** 2).item()

        if cost < best_cost:
            best_cost = cost
            best_shift = shift

    return np.roll(current, -best_shift, axis=0)


def ring_samples_to_world(
    vertices_2d: np.ndarray, *, depth: float, frame: LFrame
) -> np.ndarray:
    points = np.asarray(vertices_2d, dtype=float)

    return (
        frame.origin
        + points[:, 0, None] * frame.axis_u
        + points[:, 1, None] * frame.axis_v
        + depth * frame.axis
    )


def triang_cap(vertices_2d: np.ndarray) -> np.ndarray:
    points = np.asarray(vertices_2d, dtype=np.float64)
    minimum = np.min(points, axis=0)
    ranges = np.ptp(points, axis=0)
    if not np.isfinite(ranges).all() or np.any(ranges <= 0):
        raise ValueError("ring cap dimensions must be finite and positive")
    normalized_points = (points - minimum) / ranges
    point_indices = {
        tuple(point): index for index, point in enumerate(normalized_points)
    }

    try:
        triangles = constrained_delaunay_triangles(Polygon(normalized_points))
    except (GEOSException, TypeError, ValueError) as exc:
        raise ValueError(f"ring cap triangulation failed: {exc}") from None

    faces: list[list[int]] = []
    for triangle in triangles.geoms:
        if not isinstance(triangle, Polygon):
            raise ValueError("ring cap triangulation produced a non-polygon")
        coordinates = np.asarray(triangle.exterior.coords[:-1], dtype=float)
        if coordinates.shape != (3, 2):
            raise ValueError("ring cap triangulation produced a non-triangle")
        try:
            face = [point_indices[tuple(point)] for point in coordinates]
        except KeyError:
            raise ValueError(
                "ring cap triangulation introduced an unknown vertex"
            ) from None

        a, b, c = normalized_points[face]
        signed_area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        if signed_area == 0:
            raise ValueError("ring cap triangulation produced a zero-area face")
        if signed_area < 0:
            face[1], face[2] = face[2], face[1]
        faces.append(face)

    if not faces:
        raise ValueError("ring cap triangulation produced no faces")

    return np.asarray(faces, dtype=np.int64)


def _align_ring_origins(
    prepped_rings: list[PreppedRing], minimum_count: int
) -> list[PreppedRing]:
    first = prepped_rings[0]
    scale = np.max(np.abs(first.vertices_2d)).item()
    start = min(
        range(len(first.vertices_2d)),
        key=lambda index: (
            round(-first.vertices_2d[index, 0] / scale, 9),
            round(first.vertices_2d[index, 1] / scale, 9),
        ),
    )
    aligned = [
        PreppedRing(
            vertices_2d=np.roll(first.vertices_2d, -start, axis=0),
            vertices_3d=np.roll(first.vertices_3d, -start, axis=0),
            depth=first.depth,
            max_plan_err=first.max_plan_err,
            polygon_2d=first.polygon_2d,
        )
    ]

    for ring in prepped_rings[1:]:
        previous = aligned[-1]
        count = max(
            minimum_count,
            len(previous.vertices_2d),
            len(ring.vertices_2d),
        )
        previous_samples = resample_closed_ring(previous.vertices_2d, count=count)
        alignment_ranges = np.ptp(
            np.vstack([previous.vertices_2d, ring.vertices_2d]),
            axis=0,
        )
        if not np.isfinite(alignment_ranges).all() or np.any(alignment_ranges <= 0):
            raise ValueError("ring alignment dimensions must be finite and positive")
        best_shift = 0
        best_cost = math.inf

        for shift in range(len(ring.vertices_2d)):
            shifted = np.roll(ring.vertices_2d, -shift, axis=0)
            samples = resample_closed_ring(shifted, count=count)
            cost = np.sum(((previous_samples - samples) / alignment_ranges) ** 2).item()
            if cost < best_cost:
                best_cost = cost
                best_shift = shift

        aligned.append(
            PreppedRing(
                vertices_2d=np.roll(ring.vertices_2d, -best_shift, axis=0),
                vertices_3d=np.roll(ring.vertices_3d, -best_shift, axis=0),
                depth=ring.depth,
                max_plan_err=ring.max_plan_err,
                polygon_2d=ring.polygon_2d,
            )
        )

    return aligned


def _shared_ring_parameters(
    prepped_rings: list[PreppedRing], minimum_count: int
) -> list[np.ndarray]:
    clusters: list[_RingParameterCluster] = []

    for ring_index, ring in enumerate(prepped_rings):
        for raw_parameter in _ring_breakpoints(ring.vertices_2d):
            parameter = raw_parameter.item()
            nearest = None
            nearest_distance = math.inf
            for index, cluster in enumerate(clusters):
                if ring_index in cluster.ring_values:
                    continue
                distance = abs(parameter - cluster.parameter)
                if distance <= 1e-12 and distance < nearest_distance:
                    nearest = index
                    nearest_distance = distance
            if nearest is None:
                clusters.append(
                    _RingParameterCluster(
                        parameter=parameter,
                        ring_values={ring_index: parameter},
                    )
                )
            else:
                clusters[nearest].ring_values[ring_index] = parameter

    for raw_parameter in np.linspace(0.0, 1.0, minimum_count, endpoint=False):
        parameter = raw_parameter.item()
        if not any(abs(parameter - cluster.parameter) <= 1e-12 for cluster in clusters):
            clusters.append(_RingParameterCluster(parameter, {}))

    clusters.sort(key=lambda cluster: cluster.parameter)
    parameters_by_ring: list[np.ndarray] = []
    for ring_index in range(len(prepped_rings)):
        parameters = np.asarray(
            [
                cluster.ring_values.get(ring_index, cluster.parameter)
                for cluster in clusters
            ],
            dtype=float,
        )
        if np.any(np.diff(parameters) <= 0):
            raise ValueError("shared ring parameters are not strictly increasing")
        parameters_by_ring.append(parameters)

    return parameters_by_ring


def build_loft_mesh(
    prepped_rings: list[PreppedRing], *, frame: LFrame, smpls_per_ring: int
) -> Any:
    if len(prepped_rings) < 2:
        raise ValueError("at least two rings are required")
    if (
        isinstance(smpls_per_ring, bool)
        or not isinstance(smpls_per_ring, int)
        or smpls_per_ring < 3
    ):
        raise ValueError("smpls_per_ring must be an integer of at least 3")

    prepped_rings = _align_ring_origins(prepped_rings, smpls_per_ring)
    parameters_by_ring = _shared_ring_parameters(prepped_rings, smpls_per_ring)
    sampled_2d = [
        _sample_closed_ring(ring.vertices_2d, parameters)
        for ring, parameters in zip(prepped_rings, parameters_by_ring, strict=True)
    ]

    local_vertices = np.vstack(
        [
            np.column_stack([points, np.full(len(points), ring.depth, dtype=float)])
            for points, ring in zip(sampled_2d, prepped_rings, strict=True)
        ]
    )
    local_minimum = np.min(local_vertices, axis=0)
    local_ranges = np.ptp(local_vertices, axis=0)
    if not np.isfinite(local_ranges).all() or np.any(local_ranges <= 0):
        raise ValueError("loft mesh dimensions must be finite and positive")
    normalized_vertices = (local_vertices - local_minimum) / local_ranges
    faces: list[list[int]] = []

    count = len(parameters_by_ring[0])

    for ring_index in range(len(prepped_rings) - 1):
        lower_offset = ring_index * count
        upper_offset = (ring_index + 1) * count

        for vertex_index in range(count):
            next_index = (vertex_index + 1) % count

            a = lower_offset + vertex_index
            b = lower_offset + next_index
            c = upper_offset + next_index
            d = upper_offset + vertex_index

            faces.append([a, b, c])
            faces.append([a, c, d])

    first_cap = triang_cap(sampled_2d[0])
    faces.extend(first_cap[:, ::-1].tolist())

    last_offset = (len(prepped_rings) - 1) * count
    last_cap = triang_cap(sampled_2d[-1])
    faces.extend((last_cap + last_offset).tolist())

    mesh = trimesh.Trimesh(
        vertices=normalized_vertices,
        faces=np.asarray(faces, dtype=np.int64),
        process=False,
        validate=False,
    )

    if not mesh.is_watertight:
        raise ValueError("loft mesh is not watertight")

    if not mesh.is_winding_consistent:
        raise ValueError("loft mesh winding is inconsistent")

    if not mesh.is_volume:
        raise ValueError("loft mesh is not a valid positive volume")

    restored_local = (np.asarray(mesh.vertices) * local_ranges) + local_minimum
    world_vertices = (
        frame.origin
        + restored_local[:, 0, None] * frame.axis_u
        + restored_local[:, 1, None] * frame.axis_v
        + restored_local[:, 2, None] * frame.axis
    )
    if not np.isfinite(world_vertices).all():
        raise ValueError("loft mesh vertices must be finite")
    mesh.vertices = world_vertices

    return mesh


def volume_iou(reference: Any, submitted: Any) -> float:
    reference_bounds = np.asarray(reference.bounds, dtype=float)
    submitted_bounds = np.asarray(submitted.bounds, dtype=float)
    if (
        reference_bounds.shape != (2, 3)
        or submitted_bounds.shape != (2, 3)
        or not np.isfinite(reference_bounds).all()
        or not np.isfinite(submitted_bounds).all()
    ):
        raise ValueError("volume bounds must be finite three-dimensional bounds")

    if np.any(reference_bounds[1] <= submitted_bounds[0]) or np.any(
        submitted_bounds[1] <= reference_bounds[0]
    ):
        return 0.0

    reference_local = reference.copy()
    submitted_local = submitted.copy()
    origin = np.minimum(reference_bounds[0], submitted_bounds[0])
    reference_local.apply_translation(-origin)
    submitted_local.apply_translation(-origin)

    combined_ranges = np.maximum(reference_bounds[1], submitted_bounds[1]) - origin
    if not np.isfinite(combined_ranges).all() or np.any(combined_ranges <= 0):
        raise ValueError("combined volume dimensions must be finite and positive")
    scale = 1.0 / combined_ranges
    reference_local.apply_scale(scale)
    submitted_local.apply_scale(scale)

    if (
        not np.isfinite(reference_local.vertices).all()
        or not np.isfinite(submitted_local.vertices).all()
    ):
        raise ValueError("normalized volume vertices must be finite")
    if not reference_local.is_volume or not submitted_local.is_volume:
        raise ValueError(
            "volume scales differ too much to compare at supported numeric precision"
        )

    try:
        intersection = trimesh.boolean.intersection(
            [reference_local, submitted_local],
            engine="manifold",
            check_volume=True,
        )
    except Exception as exc:
        raise GeometryBackendError(f"volume intersection failed: {exc}") from exc

    intersection_volume = (
        0.0
        if intersection is None or intersection.is_empty
        else abs(intersection.volume)
    )
    reference_volume = abs(reference_local.volume)
    submitted_volume = abs(submitted_local.volume)
    union_volume = (reference_volume + submitted_volume) - intersection_volume

    if not np.isfinite(union_volume) or union_volume <= 0:
        raise ValueError("volume union must be finite and positive")

    result = min(1.0, max(0.0, intersection_volume / union_volume))
    if 1.0 - result <= _VOLUME_IOU_EXACT_TOL:
        result = 1.0
    return result.item() if isinstance(result, np.generic) else result


def iou_volume_to_volume(reference_volume: object, submitted_volume: object) -> float:
    reference = normalize_volume_coords(reference_volume, "reference volume")
    submitted = normalize_volume_coords(submitted_volume, "submitted volume")
    return volume_iou(reference, submitted)


def _volume_point_count(volume: object) -> int:
    if not isinstance(volume, list):
        return 0
    return sum(len(ring) for ring in volume if isinstance(ring, list))


def normalize_volume_list(volumes: object, err_label: str) -> list[Any]:
    if not isinstance(volumes, list):
        raise ValueError(f"{err_label} must be a list of volumes")
    if len(volumes) > _MAX_VOLUME_LIST_COUNT:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_VOLUME_LIST_COUNT} volumes"
        )
    if sum(_volume_point_count(volume) for volume in volumes) > _MAX_VOLUME_LIST_POINTS:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_VOLUME_LIST_POINTS} total points"
        )
    return [
        normalize_volume_coords(volume, f"{err_label}[{index}]")
        for index, volume in enumerate(volumes)
    ]


def normalize_reference_volume_set(volumes: object, err_label: str) -> list[Any]:
    normalized = normalize_volume_list(volumes, err_label)
    if not normalized:
        raise ValueError(f"{err_label} must not be empty")
    return normalized


def _meshes_to_unit_box(meshes: list[Any]) -> list[Any]:
    """Translate and scale meshes into a shared unit box so manifold booleans
    run at a stable numeric precision regardless of the image's coordinate
    scale. Volumes and their ratios are compared inside this box."""

    bounds = np.asarray([mesh.bounds for mesh in meshes], dtype=float)
    if bounds.shape[1:] != (2, 3) or not np.isfinite(bounds).all():
        raise ValueError("volume bounds must be finite three-dimensional bounds")
    origin = bounds[:, 0].min(axis=0)
    ranges = bounds[:, 1].max(axis=0) - origin
    if not np.isfinite(ranges).all() or np.any(ranges <= 0):
        raise ValueError("combined volume dimensions must be finite and positive")

    local_meshes = []
    for mesh in meshes:
        local = mesh.copy()
        local.apply_translation(-origin)
        local.apply_scale(1.0 / ranges)
        if not np.isfinite(local.vertices).all():
            raise ValueError("normalized volume vertices must be finite")
        if not local.is_volume:
            raise ValueError(
                "volume scales differ too much to compare at supported numeric precision"
            )
        local_meshes.append(local)
    return local_meshes


def _mesh_union(meshes: list[Any], err_label: str) -> Any:
    if len(meshes) == 1:
        return meshes[0]
    try:
        union = trimesh.boolean.union(meshes, engine="manifold", check_volume=True)
    except Exception as exc:
        raise GeometryBackendError(f"{err_label} union failed: {exc}") from exc
    if union is None or union.is_empty or not np.isfinite(union.volume):
        raise ValueError(f"{err_label} union must be a finite positive volume")
    return union


def volume_union_iou(
    reference_volumes: object,
    submitted_volumes: object,
    *,
    volume_count: object = None,
    max_overlap_fraction: object = None,
) -> float:
    """IoU between the union of the reference volumes and the union of the
    submitted volumes. As with ``polygon_union_iou`` the score depends only on
    the region covered, not on how either side is split into pieces.

    ``volume_count`` bounds how many volumes the submission may contain and
    ``max_overlap_fraction`` bounds the share of the submitted volume that is
    covered more than once. Violating either makes the submission invalid.
    """

    references = normalize_reference_volume_set(reference_volumes, "reference volumes")
    minimum, maximum = normalize_count_bounds(
        volume_count, "volume_count", limit=_MAX_VOLUME_LIST_COUNT
    )
    overlap_limit = normalize_overlap_fraction(max_overlap_fraction)

    items = _submitted_items(
        submitted_volumes, "submitted volumes", _MAX_VOLUME_LIST_COUNT
    )
    if minimum is not None and len(items) < minimum:
        raise ValueError(
            f"submitted volumes must contain at least {minimum} volumes, got {len(items)}"
        )
    if maximum is not None and len(items) > maximum:
        raise ValueError(
            f"submitted volumes must contain at most {maximum} volumes, got {len(items)}"
        )

    submissions = normalize_volume_list(items, "submitted volumes")
    if not submissions:
        return 0.0

    local = _meshes_to_unit_box(references + submissions)
    local_references = local[: len(references)]
    local_submissions = local[len(references) :]

    submitted_union = _mesh_union(local_submissions, "submitted volumes")
    if overlap_limit is not None:
        _check_overlap_fraction(
            [abs(mesh.volume) for mesh in local_submissions],
            abs(submitted_union.volume),
            overlap_limit,
            "submitted volumes",
            "volume",
        )

    reference_union = _mesh_union(local_references, "reference volumes")

    reference_bounds = np.asarray(reference_union.bounds, dtype=float)
    submitted_bounds = np.asarray(submitted_union.bounds, dtype=float)
    if np.any(reference_bounds[1] <= submitted_bounds[0]) or np.any(
        submitted_bounds[1] <= reference_bounds[0]
    ):
        return 0.0

    try:
        intersection = trimesh.boolean.intersection(
            [reference_union, submitted_union], engine="manifold", check_volume=True
        )
    except Exception as exc:
        raise GeometryBackendError(f"volume intersection failed: {exc}") from exc

    intersection_volume = (
        0.0
        if intersection is None or intersection.is_empty
        else abs(intersection.volume)
    )
    union_volume = (
        abs(reference_union.volume) + abs(submitted_union.volume) - intersection_volume
    )
    if not np.isfinite(union_volume) or union_volume <= 0:
        raise ValueError("volume union must be finite and positive")

    result = min(1.0, max(0.0, intersection_volume / union_volume))
    if 1.0 - result <= _VOLUME_IOU_EXACT_TOL:
        result = 1.0
    return result.item() if isinstance(result, np.generic) else result


# --------------------------------- VOLUMETRIC STUFF /\ /\ /\


def location_within_radius_match(
    reference_location: object, location: object, radius: float
) -> float:
    if not is_finite_number(radius) or radius < 0:
        raise ValueError("radius must be a finite non-negative number")

    ref_loc = normalize_coords(reference_location, err_label="reference location")
    sub_loc = normalize_coords(location, err_label="submitted location")

    if len(ref_loc) != len(sub_loc):
        raise ValueError(
            "dimensions of reference location and submitted location need to match"
        )

    dif = math.dist(ref_loc, sub_loc)

    return 1.0 if _within_radius(dif, radius) else 0.0


def location_within_radius_gradient(
    reference_location: object, location: object, radius_full: float, radius_none: float
) -> float:
    if (
        not is_finite_number(radius_full)
        or not is_finite_number(radius_none)
        or radius_full < 0
        or radius_full >= radius_none
    ):
        raise ValueError("radii must satisfy 0 <= radius_full < radius_none")

    ref_loc = normalize_coords(reference_location, err_label="reference location")
    sub_loc = normalize_coords(location, err_label="submitted location")

    if len(ref_loc) != len(sub_loc):
        raise ValueError(
            "dimensions of reference location and submitted location need to match"
        )

    dif = math.dist(ref_loc, sub_loc)

    if dif <= radius_full:
        return 1.0

    if dif >= radius_none:
        return 0.0

    return (radius_none - dif) / (radius_none - radius_full)


def location_within_polygon_match(reference_polygon: object, location: object) -> float:
    pol = normalize_polygon_coords(reference_polygon, "reference polygon")
    loc = normalize_coords(location, "submitted location")

    if len(loc) != 2:
        raise ValueError("location inside a polygon needs to have 2 coordinates")

    po = Point(loc)

    return 1.0 if pol.covers(po) else 0.0


def location_within_volume_match(
    reference_volume: object, location: object
) -> float:  # todo need to figure out how to build volumes from polygon rings
    raise ValueError("location-within-volume matching is not implemented")


def polygon_within_polygon_match(
    reference_polygon: object, polygon: object, threshold: float
) -> float:
    if not is_finite_number(threshold) or not 0 < threshold <= 1:
        raise ValueError("threshold must be a finite number in (0, 1]")

    iou = iou_polygon_to_polygon(reference_polygon, polygon)

    return 1.0 if iou >= threshold else 0.0


def polygon_within_polygon_gradient(
    reference_polygon: object, polygon: object, iou_full: float, iou_none: float
) -> float:
    if (
        not is_finite_number(iou_full)
        or not is_finite_number(iou_none)
        or not 0 <= iou_none < iou_full <= 1
    ):
        raise ValueError("IoU thresholds must satisfy 0 <= iou_none < iou_full <= 1")

    iou = iou_polygon_to_polygon(reference_polygon, polygon)

    if iou >= iou_full:
        return 1.0

    if iou <= iou_none:
        return 0.0

    return (iou - iou_none) / (iou_full - iou_none)


def volume_in_volume_match(
    reference_volume: object, submitted_volume: object, threshold: float
) -> float:
    if not is_finite_number(threshold) or not 0 < threshold <= 1:
        raise ValueError("threshold must be a finite number in (0, 1]")

    iou3d = iou_volume_to_volume(reference_volume, submitted_volume)

    if iou3d >= threshold:
        return 1.0
    else:
        return 0.0


def volume_in_volume_gradient(
    reference_volume: object,
    submitted_volume: object,
    threshold_full: float,
    threshold_null: float,
) -> float:
    if (
        not is_finite_number(threshold_full)
        or not is_finite_number(threshold_null)
        or not 0 <= threshold_null < threshold_full <= 1
    ):
        raise ValueError(
            "IoU thresholds must satisfy 0 <= threshold_null < threshold_full <= 1"
        )

    iou3d = iou_volume_to_volume(reference_volume, submitted_volume)

    if iou3d >= threshold_full:
        return 1.0

    if iou3d < threshold_null:
        return 0.0

    return (iou3d - threshold_null) / (threshold_full - threshold_null)


def _path_list_work(
    references: list[list[list[float]]], submissions: list[list[list[float]]]
) -> int:
    work = 0
    for reference in references:
        reference_segments = len(reference) - 1
        reference_pieces = 3 * reference_segments
        for submitted in submissions:
            submitted_segments = len(submitted) - 1
            submitted_pieces = 3 * submitted_segments
            work += min(
                reference_segments * submitted_pieces * (submitted_pieces - 1) // 2,
                _MAX_PATH_INTERSECTION_CHECKS,
            )
            work += min(
                submitted_segments * reference_pieces * (reference_pieces - 1) // 2,
                _MAX_PATH_INTERSECTION_CHECKS,
            )
    return work


def validate_path_list_support(references: list[list[list[float]]]) -> None:
    if _path_list_work(references, references) > _MAX_PATH_LIST_WORK:
        raise ValueError(
            "reference paths exceed supported matching complexity for an exact answer"
        )


def _submitted_items(submitted: object, err_label: str, max_count: int) -> list[object]:
    if not isinstance(submitted, list):
        raise ValueError(f"{err_label} must be a list")
    if len(submitted) > max_count:
        raise ValueError(f"{err_label} must contain at most {max_count} items")
    return submitted


def normalize_matching(matching: object) -> str:
    if matching is None:
        return "greedy"
    if not isinstance(matching, str) or matching not in _MATCHING_STRATEGIES:
        raise ValueError(f"matching must be one of {list(_MATCHING_STRATEGIES)}")
    return matching


def normalize_scoring(scoring: object) -> str:
    if scoring is None:
        return "binary"
    if not isinstance(scoring, str) or scoring not in _SCORING_MODES:
        raise ValueError(f"scoring must be one of {list(_SCORING_MODES)}")
    return scoring


def _greedy_assignment(
    reference_count: int,
    submitted_count: int,
    pair_values: dict[tuple[int, int], float],
) -> list[tuple[int, int]]:
    """First-fit in submission order: each submitted item takes the lowest
    still-free reference it is eligible for. Depends on submission order."""

    pairs: list[tuple[int, int]] = []
    matched_references: set[int] = set()
    for submitted_index in range(submitted_count):
        for reference_index in range(reference_count):
            if reference_index in matched_references:
                continue
            if (reference_index, submitted_index) not in pair_values:
                continue
            matched_references.add(reference_index)
            pairs.append((reference_index, submitted_index))
            break
    return pairs


def _optimal_assignment(
    pair_values: dict[tuple[int, int], float],
    quality: dict[tuple[int, int], float],
) -> list[tuple[int, int]]:
    """Maximise the number of matched pairs, then their total quality.

    Only references and submissions with at least one eligible partner enter
    the problem. Within the dense cap this is a single assignment whose weights
    put cardinality strictly ahead of quality; beyond it a sparse
    maximum-cardinality matching is used without the quality tie-break.
    """

    if not pair_values:
        return []
    rows = sorted({reference for reference, _ in pair_values})
    cols = sorted({submitted for _, submitted in pair_values})
    row_of = {reference: index for index, reference in enumerate(rows)}
    col_of = {submitted: index for index, submitted in enumerate(cols)}

    if len(rows) * len(cols) <= _MAX_OPTIMAL_ASSIGNMENT_CELLS:
        # Any solution with one more match outweighs any quality total.
        cardinality_weight = float(min(len(rows), len(cols)) + 1)
        weights = np.zeros((len(rows), len(cols)), dtype=float)
        for reference, submitted in pair_values:
            bonus = min(1.0, max(0.0, quality.get((reference, submitted), 0.0)))
            weights[row_of[reference], col_of[submitted]] = cardinality_weight + bonus
        row_ind, col_ind = linear_sum_assignment(weights, maximize=True)
        return sorted(
            (rows[row], cols[col])
            for row, col in zip(row_ind, col_ind, strict=True)
            if weights[row, col] > 0.0
        )

    graph = csr_matrix(
        (
            np.ones(len(pair_values)),
            (
                [row_of[reference] for reference, _ in pair_values],
                [col_of[submitted] for _, submitted in pair_values],
            ),
        ),
        shape=(len(rows), len(cols)),
    )
    assignment = maximum_bipartite_matching(graph, perm_type="column")
    return sorted(
        (rows[row], cols[int(col)]) for row, col in enumerate(assignment) if col >= 0
    )


def _list_match_stats(
    reference_count: int,
    submitted_count: int,
    pair_values: dict[tuple[int, int], float],
    value_key: str,
    *,
    matching: str = "greedy",
    quality: dict[tuple[int, int], float] | None = None,
) -> dict[str, object]:
    """Turn eligible (reference, submitted) pairs into a one-to-one matching
    and precision/recall/F1 over it.

    ``quality`` maps a pair to a value in [0, 1], higher is better. ``optimal``
    matching uses it to choose among equally large matchings, and the
    ``quality_*`` statistics weight each matched pair by it instead of
    counting it as 1, so a pair matched at IoU 0.65 contributes 0.65.
    """

    quality = quality or {}
    if matching == "optimal":
        pairs = _optimal_assignment(pair_values, quality)
    else:
        pairs = _greedy_assignment(reference_count, submitted_count, pair_values)
    pairs.sort(key=lambda pair: pair[1])

    pair_quality = {pair: min(1.0, max(0.0, quality.get(pair, 1.0))) for pair in pairs}
    matches = [
        {
            "reference_index": reference_index,
            "submitted_index": submitted_index,
            value_key: pair_values[(reference_index, submitted_index)],
            "quality": pair_quality[(reference_index, submitted_index)],
        }
        for reference_index, submitted_index in pairs
    ]
    matched_references = {reference for reference, _ in pairs}
    matched_submissions = {submitted for _, submitted in pairs}

    matched_count = len(matches)
    matched_quality = sum(pair_quality.values())
    return {
        "reference_count": reference_count,
        "submitted_count": submitted_count,
        "matched_count": matched_count,
        "recall": matched_count / reference_count,
        "precision": matched_count / submitted_count if submitted_count else 0.0,
        "f1": 2 * matched_count / (reference_count + submitted_count),
        "mean_match_quality": matched_quality / matched_count if matched_count else 0.0,
        "quality_recall": matched_quality / reference_count,
        "quality_precision": (
            matched_quality / submitted_count if submitted_count else 0.0
        ),
        "quality_f1": 2 * matched_quality / (reference_count + submitted_count),
        "matching": matching,
        "matches": matches,
        "unmatched_reference_indices": sorted(
            set(range(reference_count)) - matched_references
        ),
        "unmatched_submitted_indices": sorted(
            set(range(submitted_count)) - matched_submissions
        ),
    }


def _distance_quality(distance: float, radius: float) -> float:
    if radius <= 0:
        return 1.0
    return min(1.0, max(0.0, 1.0 - distance / radius))


def _within_radius(distance: float, radius: float) -> bool:
    return distance <= radius or math.isclose(
        distance, radius, rel_tol=_RADIUS_REL_TOL, abs_tol=_RADIUS_ABS_TOL
    )


def paths_list_to_paths_list_match(
    reference_paths: object,
    submitted_paths: object,
    radius: float,
    *,
    component_scales: object = None,
    matching: object = None,
) -> dict[str, object]:
    if not is_finite_number(radius) or radius < 0:
        raise ValueError("radius must be a finite non-negative number")
    strategy = normalize_matching(matching)

    references = normalize_path_list(reference_paths, "reference paths")
    if not references:
        raise ValueError("reference paths must not be empty")
    dimension = len(references[0][0])
    if any(len(path[0]) != dimension for path in references):
        raise ValueError("reference paths must have matching dimensions")
    scales = normalize_path_component_scales(component_scales, dimension)

    items = _submitted_items(submitted_paths, "submitted paths", _MAX_PATH_LIST_COUNT)
    submissions: dict[int, list[list[float]]] = {}
    for index, item in enumerate(items):
        try:
            path = normalize_path_coords(item, f"submitted paths[{index}]")
        except ValueError:
            continue
        if len(path[0]) == dimension:
            submissions[index] = path
    if sum(len(path) for path in submissions.values()) > _MAX_PATH_LIST_POINTS:
        raise ValueError(
            f"submitted paths must contain at most {_MAX_PATH_LIST_POINTS} total points"
        )
    if _path_list_work(references, list(submissions.values())) > _MAX_PATH_LIST_WORK:
        raise ValueError("path list exceeds supported matching complexity")

    distances: dict[tuple[int, int], float] = {}
    for submitted_index, submitted in submissions.items():
        for reference_index, reference in enumerate(references):
            try:
                distance = path_hausdorff_distance(
                    reference, submitted, component_scales=scales
                )
            except ValueError:
                continue
            if _within_radius(distance, radius):
                distances[(reference_index, submitted_index)] = distance

    return {
        **_list_match_stats(
            len(references),
            len(items),
            distances,
            "distance",
            matching=strategy,
            quality={
                pair: _distance_quality(distance, radius)
                for pair, distance in distances.items()
            },
        ),
        "tolerance_radius": radius,
        "component_scales": scales,
    }


def locations_list_to_locations_list_match(
    reference_locations: object,
    submitted_locations: object,
    radius: float,
    *,
    matching: object = None,
) -> dict[str, object]:
    if not is_finite_number(radius) or radius < 0:
        raise ValueError("radius must be a finite non-negative number")
    strategy = normalize_matching(matching)

    reference_locs = normalize_coords_list(reference_locations, "reference locations")
    if not reference_locs:
        raise ValueError("reference locations must not be empty")
    if len(reference_locs) > _MAX_LOCATION_LIST_COUNT:
        raise ValueError(
            f"reference locations must contain at most {_MAX_LOCATION_LIST_COUNT} items"
        )

    items = _submitted_items(
        submitted_locations, "submitted locations", _MAX_LOCATION_LIST_COUNT
    )
    distances: dict[tuple[int, int], float] = {}
    for submitted_index, item in enumerate(items):
        try:
            submitted = normalize_coords(
                item, f"submitted locations[{submitted_index}]"
            )
        except ValueError:
            continue
        for reference_index, reference in enumerate(reference_locs):
            if len(submitted) != len(reference):
                continue
            distance = math.dist(submitted, reference)
            if _within_radius(distance, radius):
                distances[(reference_index, submitted_index)] = distance

    return {
        **_list_match_stats(
            len(reference_locs),
            len(items),
            distances,
            "distance",
            matching=strategy,
            quality={
                pair: _distance_quality(distance, radius)
                for pair, distance in distances.items()
            },
        ),
        "tolerance_radius": radius,
    }


def polygons_list_to_polygons_list_match(
    reference_polygons: object,
    submitted_polygons: object,
    iou_threshold: float,
    *,
    matching: object = None,
) -> dict[str, object]:
    if not is_finite_number(iou_threshold) or not 0 < iou_threshold <= 1:
        raise ValueError("iou_threshold must be a finite number in (0, 1]")
    strategy = normalize_matching(matching)

    references = normalize_polygon_list(reference_polygons, "reference polygons")
    if not references:
        raise ValueError("reference polygons must not be empty")

    items = _submitted_items(
        submitted_polygons, "submitted polygons", _MAX_POLYGON_LIST_COUNT
    )
    ious: dict[tuple[int, int], float] = {}
    for submitted_index, item in enumerate(items):
        try:
            submitted = normalize_polygon_coords(
                item, f"submitted polygons[{submitted_index}]"
            )
        except ValueError:
            continue
        for reference_index, reference in enumerate(references):
            iou = _polygon_iou(reference, submitted)
            if iou >= iou_threshold:
                ious[(reference_index, submitted_index)] = iou

    return {
        **_list_match_stats(
            len(references), len(items), ious, "iou", matching=strategy, quality=ious
        ),
        "iou_threshold": iou_threshold,
    }


def volumes_list_to_volumes_list_match(
    reference_volumes: object,
    submitted_volumes: object,
    iou_threshold: float,
    *,
    matching: object = None,
) -> dict[str, object]:
    if not is_finite_number(iou_threshold) or not 0 < iou_threshold <= 1:
        raise ValueError("iou_threshold must be a finite number in (0, 1]")
    strategy = normalize_matching(matching)

    references = normalize_reference_volume_set(reference_volumes, "reference volumes")

    items = _submitted_items(
        submitted_volumes, "submitted volumes", _MAX_VOLUME_LIST_COUNT
    )
    if sum(_volume_point_count(item) for item in items) > _MAX_VOLUME_LIST_POINTS:
        raise ValueError(
            f"submitted volumes must contain at most {_MAX_VOLUME_LIST_POINTS} total points"
        )

    ious: dict[tuple[int, int], float] = {}
    for submitted_index, item in enumerate(items):
        try:
            submitted = normalize_volume_coords(
                item, f"submitted volumes[{submitted_index}]"
            )
        except ValueError:
            continue
        for reference_index, reference in enumerate(references):
            try:
                iou = volume_iou(reference, submitted)
            except ValueError:
                continue
            if iou >= iou_threshold:
                ious[(reference_index, submitted_index)] = iou

    return {
        **_list_match_stats(
            len(references), len(items), ious, "iou", matching=strategy, quality=ious
        ),
        "iou_threshold": iou_threshold,
    }


def normalize_frame(value: object, err_label: str) -> int:
    """A frame index: a nonnegative integer, or a string holding one."""

    if isinstance(value, str):
        try:
            value = int(value.strip())
        except ValueError:
            raise ValueError(f"{err_label} must be a nonnegative integer") from None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{err_label} must be a nonnegative integer")
    return value


def normalize_frame_tolerance(value: object, err_label: str = "frame_tolerance") -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{err_label} must be a nonnegative integer")
    return value


def normalize_frame_range(
    frame_range: object, err_label: str = "frame_range"
) -> tuple[int, int] | None:
    """An optional inclusive ``[first, last]`` scoring window."""

    if frame_range is None:
        return None
    if not isinstance(frame_range, list) or len(frame_range) != 2:
        raise ValueError(f"{err_label} must be [first, last]")
    first = normalize_frame(frame_range[0], f"{err_label}[0]")
    last = normalize_frame(frame_range[1], f"{err_label}[1]")
    if first > last:
        raise ValueError(f"{err_label} must be ordered as [first, last]")
    return first, last


def normalize_polygon_event(event: object, err_label: str) -> tuple[int, Polygon]:
    """A polygon observed at one frame: ``{"frame": int, "polygon": ring}``."""

    if not isinstance(event, dict):
        raise ValueError(f"{err_label} must be an object with frame and polygon")
    frame = normalize_frame(event.get("frame"), f"{err_label}.frame")
    polygon = normalize_polygon_coords(event.get("polygon"), f"{err_label}.polygon")
    return frame, polygon


def normalize_polygon_event_list(
    events: object, err_label: str
) -> list[tuple[int, Polygon]]:
    if not isinstance(events, list):
        raise ValueError(f"{err_label} must be a list of polygon events")
    return [
        normalize_polygon_event(event, f"{err_label}[{index}]")
        for index, event in enumerate(events)
    ]


def normalize_reference_polygon_event_set(
    events: object, err_label: str, *, frame_range: tuple[int, int] | None = None
) -> list[tuple[int, Polygon]]:
    normalized = normalize_polygon_event_list(events, err_label)
    if not normalized:
        raise ValueError(f"{err_label} must not be empty")
    if len(normalized) > _MAX_POLYGON_LIST_COUNT:
        raise ValueError(
            f"{err_label} must contain at most {_MAX_POLYGON_LIST_COUNT} events"
        )
    if frame_range is not None:
        first, last = frame_range
        if any(not first <= frame <= last for frame, _ in normalized):
            raise ValueError(f"{err_label} must lie within frame_range")
    return normalized


def _bounds_disjoint(a: tuple[float, ...], b: tuple[float, ...]) -> bool:
    return a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1]


def polygon_events_list_to_polygon_events_list_match(
    reference_events: object,
    submitted_events: object,
    iou_threshold: float,
    *,
    frame_tolerance: object,
    frame_range: object = None,
    matching: object = None,
) -> dict[str, object]:
    """``polygons_list_to_polygons_list_match`` for polygons observed at frames.

    A pair is eligible when the frames differ by at most ``frame_tolerance``
    and the 2D IoU reaches ``iou_threshold``. Submitted events outside the
    optional ``frame_range`` window, like malformed ones, stay unmatched and
    are listed in ``invalid_submitted_indices``. Each match also records its
    ``frame_difference``.
    """

    if not is_finite_number(iou_threshold) or not 0 < iou_threshold <= 1:
        raise ValueError("iou_threshold must be a finite number in (0, 1]")
    strategy = normalize_matching(matching)
    tolerance = normalize_frame_tolerance(frame_tolerance)
    window = normalize_frame_range(frame_range)

    references = normalize_reference_polygon_event_set(
        reference_events, "reference events", frame_range=window
    )
    reference_bounds = [polygon.bounds for _, polygon in references]

    items = _submitted_items(
        submitted_events, "submitted events", _MAX_POLYGON_LIST_COUNT
    )
    ious: dict[tuple[int, int], float] = {}
    frame_differences: dict[tuple[int, int], int] = {}
    invalid: list[int] = []
    for submitted_index, item in enumerate(items):
        try:
            frame, polygon = normalize_polygon_event(
                item, f"submitted events[{submitted_index}]"
            )
        except ValueError:
            invalid.append(submitted_index)
            continue
        if window is not None and not window[0] <= frame <= window[1]:
            invalid.append(submitted_index)
            continue
        bounds = polygon.bounds
        for reference_index, (reference_frame, reference) in enumerate(references):
            difference = abs(reference_frame - frame)
            if difference > tolerance or _bounds_disjoint(
                reference_bounds[reference_index], bounds
            ):
                continue
            iou = _polygon_iou(reference, polygon)
            if iou >= iou_threshold:
                ious[(reference_index, submitted_index)] = iou
                frame_differences[(reference_index, submitted_index)] = difference

    stats = _list_match_stats(
        len(references), len(items), ious, "iou", matching=strategy, quality=ious
    )
    for match in cast(list[dict[str, Any]], stats["matches"]):
        match["frame_difference"] = frame_differences[
            (match["reference_index"], match["submitted_index"])
        ]
    return {
        **stats,
        "iou_threshold": iou_threshold,
        "frame_tolerance": tolerance,
        "frame_range": list(window) if window is not None else None,
        "invalid_submitted_indices": invalid,
    }
