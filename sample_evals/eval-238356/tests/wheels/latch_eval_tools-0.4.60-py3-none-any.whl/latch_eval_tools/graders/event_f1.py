"""One-to-one event detection with independent spatial and temporal tolerances."""
from __future__ import annotations

import math
from typing import Any

import numpy as np
from scipy.optimize import linear_sum_assignment

from .base import BinaryGrader, GraderResult, configuration_error_result, get_nested_value

_MAX_EVENTS = 2048


def _number(value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("coordinates and tolerances must be finite numbers")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("coordinates and tolerances must be finite numbers")
    return result


def _frame(value: Any) -> int:
    if isinstance(value, str):
        value = int(value.strip())
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("frame must be a nonnegative integer or integer string")
    return value


def _point(value: Any) -> list[float]:
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError("point must be [x,y,z]")
    return [_number(x) for x in value]


def _event(value: Any) -> tuple[int, list[float]]:
    if not isinstance(value, dict):
        raise ValueError("event must contain frame and point")
    return _frame(value.get("frame")), _point(value.get("point"))


class SpatiotemporalEventF1Grader(BinaryGrader):
    """Award continuous F1; the pass flag never erases partial credit."""

    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        name = "Spatiotemporal Event F1"
        try:
            if not isinstance(config, dict):
                raise ValueError("config must be an object")
            field = config.get("answer_field")
            if not isinstance(field, str) or not field:
                raise ValueError("answer_field must be nonempty")
            refs = config.get("reference_events")
            if not isinstance(refs, list) or not 0 < len(refs) <= _MAX_EVENTS:
                raise ValueError("reference_events must contain 1 to 2048 events")
            reference = [_event(r) for r in refs]
            if len({(t, tuple(p)) for t, p in reference}) != len(reference):
                raise ValueError("reference_events contains duplicate events")
            scales = _point(config.get("voxel_size_um"))
            if any(x <= 0 for x in scales):
                raise ValueError("voxel_size_um must be positive")
            radius = _number(config.get("spatial_tolerance_um"))
            dt_limit = config.get("frame_tolerance")
            if radius < 0 or isinstance(dt_limit, bool) or not isinstance(dt_limit, int) or dt_limit < 0:
                raise ValueError("tolerances must be nonnegative; frame_tolerance must be integer")
            threshold = _number(config.get("pass_threshold", 0.7))
            if not 0 < threshold <= 1:
                raise ValueError("pass_threshold must be in (0,1]")
            bounds = config.get("frame_range")
            if not isinstance(bounds, list) or len(bounds) != 2:
                raise ValueError("frame_range must be [first,last]")
            first, last = [_frame(x) for x in bounds]
            if first > last or any(not first <= t <= last for t, _ in reference):
                raise ValueError("reference events must lie within ordered frame_range")
        except (ValueError, TypeError, OverflowError) as exc:
            return configuration_error_result(agent_answer, name, str(exc))

        def failure(reason: str) -> GraderResult:
            return GraderResult(passed=False, score=0.0, metrics={}, reasoning=reason,
                                agent_answer=agent_answer if isinstance(agent_answer, dict) else None)

        if not isinstance(agent_answer, dict):
            return failure("answer must be an object")
        submitted, found = get_nested_value(agent_answer, field)
        if not found or not isinstance(submitted, list) or len(submitted) > _MAX_EVENTS:
            return failure("event list missing, invalid, or larger than 2048 entries")
        if not submitted:
            return GraderResult(passed=False, score=0.0, metrics={"true_positives": 0,
                "false_positives": 0, "false_negatives": len(reference), "precision": 0.0,
                "recall": 0.0, "f1": 0.0}, reasoning="No divisions reported.", agent_answer=agent_answer)

        rewards = np.zeros((len(reference), len(submitted)), dtype=float)
        candidates: dict[tuple[int, int], tuple[float, int]] = {}
        cardinality_weight = min(len(reference), len(submitted)) + 1.0
        invalid = []
        for j, value in enumerate(submitted):
            try:
                t, point = _event(value)
                if not first <= t <= last:
                    raise ValueError("prediction outside scoring interval")
            except (ValueError, TypeError, OverflowError):
                invalid.append(j)
                continue
            for i, (rt, rp) in enumerate(reference):
                dt = abs(rt - t)
                if dt > dt_limit:
                    continue
                distance = math.hypot(*[(a - b) * scale for a, b, scale in zip(point, rp, scales)])
                if distance > radius:
                    continue
                quality = 0.5 * ((1.0 - distance / radius) if radius else 1.0)
                quality += 0.5 * ((1.0 - dt / dt_limit) if dt_limit else 1.0)
                rewards[i, j] = cardinality_weight + quality
                candidates[i, j] = (distance, dt)
        ri, pi = linear_sum_assignment(rewards, maximize=True)
        matches = [{"reference_index": int(i), "prediction_index": int(j),
                    "distance_um": candidates[i, j][0], "frame_difference": candidates[i, j][1]}
                   for i, j in zip(ri, pi) if (i, j) in candidates]
        tp = len(matches)
        fp, fn = len(submitted) - tp, len(reference) - tp
        score = 2.0 * tp / (len(submitted) + len(reference))
        return GraderResult(passed=score >= threshold, score=score, metrics={
            "true_positives": tp, "false_positives": fp, "false_negatives": fn,
            "precision": tp / len(submitted), "recall": tp / len(reference), "f1": score,
            "matches": matches, "invalid_prediction_indices": invalid,
            "spatial_tolerance_um": radius, "frame_tolerance": dt_limit,
            "pass_threshold": threshold}, reasoning=f"Matched {tp}/{len(reference)} divisions; F1={score:.4f}.",
            agent_answer=agent_answer)
