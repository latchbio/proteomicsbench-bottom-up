from .artifact import (
    ARTIFACT_GRADER_TYPE,
    ARTIFACT_NEEDS_SANDBOX_MESSAGE,
    ArtifactCompute,
    ArtifactGrader,
    ArtifactGraderConfig,
    ArtifactGraderSpec,
    ArtifactSandbox,
    artifact_sandbox_names,
    artifact_spec_key,
    artifact_system_error_payload,
    eval_json_contains_artifact_grader,
    iter_artifact_grader_specs,
    normalize_artifact_payload,
    validate_artifact_results,
)
from .base import BinaryGrader, GraderResult, get_nested_value, normalize_score
from .completion import FinishedFileGrader
from .composite import (
    AllOfGrader,
    AverageOfGrader,
    DictMatchGrader,
    ListMatchGrader,
    evaluate_composite_predicate_leaf,
)
from .confidence import ConfidenceLogScoreGrader
from .event_f1 import SpatiotemporalEventF1Grader
from .distribution import DistributionComparisonGrader
from .helpers import (
    grade_multiple_graders_single_answer,  # noqa: E402 -- depends on GRADER_REGISTRY
)
from .label_set import LabelSetJaccardGrader
from .longest_subsequence import LongestSubsequenceGrader
from .marker_gene import MarkerGenePrecisionRecallGrader, MarkerGeneSeparationGrader
from .multiple_choice import MultipleChoiceGrader
from .numeric import NumericRangeGrader, NumericToleranceGrader
from .predicate import PredicateLeafGrader
from .refusal import RefusalVocabGrader
from .rubric import (
    GraderError,
    GraderTransientError,
    RubricCriterion,
    RubricCriterionGraderOutput,
    RubricCriterionJudgment,
    RubricGrader,
    RubricGraderConfig,
    RubricGraderOutput,
    RubricGraderOutputParseError,
    RubricLengthPenaltyConfig,
    RubricScoreResult,
    compute_rubric_length_penalty,
    compute_rubric_reward,
    rubric_criterion_output_config,
)
from .spatial import SpatialAdjacencyGrader
from .visual import (
    LocationRadiusListGrader,
    PathRadiusListGrader,
    PolygonFrameIoUListGrader,
    PolygonIoUListGrader,
    VolumeIoUListGrader,
)

GRADER_REGISTRY = {
    "spatiotemporal_event_f1": SpatiotemporalEventF1Grader,
    "confidence_log_score": ConfidenceLogScoreGrader,
    "numeric_tolerance": NumericToleranceGrader,
    "numeric_range": NumericRangeGrader,
    "label_set_jaccard": LabelSetJaccardGrader,
    "jaccard_label_set": LabelSetJaccardGrader,
    "distribution_comparison": DistributionComparisonGrader,
    "marker_gene_precision_recall": MarkerGenePrecisionRecallGrader,
    "marker_gene_separation": MarkerGeneSeparationGrader,
    "spatial_adjacency": SpatialAdjacencyGrader,
    "location_radius": LocationRadiusListGrader,
    "path_radius_list": PathRadiusListGrader,
    "polygon_iou_list": PolygonIoUListGrader,
    "volume_iou_list": VolumeIoUListGrader,
    "polygon_frame_iou_list": PolygonFrameIoUListGrader,
    "multiple_choice": MultipleChoiceGrader,
    "refusal_vocab": RefusalVocabGrader,
    "predicate_leaf": PredicateLeafGrader,
    "all_of": AllOfGrader,
    "composite": AllOfGrader,
    "average_of": AverageOfGrader,
    "list_match": ListMatchGrader,
    "dict_match": DictMatchGrader,
    "longest_subsequence": LongestSubsequenceGrader,
    "finished_file": FinishedFileGrader,
}

LLM_GRADER_REGISTRY = {
    "rubric": RubricGrader,
}

# Graders whose real evaluation runs a package in a sandbox (`platform_grading.ArtifactRunner`).
# Kept out of GRADER_REGISTRY so the in-process registry's invariant holds: every grader in it
# can award credit on its own. `get_grader` refuses these with a message that says where they run.
SANDBOX_GRADER_REGISTRY = {
    ARTIFACT_GRADER_TYPE: ArtifactGrader,
}


def get_grader(grader_type: str) -> BinaryGrader:
    if grader_type in SANDBOX_GRADER_REGISTRY:
        raise ValueError(ARTIFACT_NEEDS_SANDBOX_MESSAGE)
    if grader_type not in GRADER_REGISTRY:
        raise ValueError(
            f"Unknown grader type: {grader_type}. Available: {list(GRADER_REGISTRY.keys())}"
        )
    return GRADER_REGISTRY[grader_type]()


__all__ = [
    "ARTIFACT_GRADER_TYPE",
    "ARTIFACT_NEEDS_SANDBOX_MESSAGE",
    "ArtifactCompute",
    "ArtifactGrader",
    "ArtifactGraderConfig",
    "ArtifactGraderSpec",
    "ArtifactSandbox",
    "SANDBOX_GRADER_REGISTRY",
    "artifact_sandbox_names",
    "artifact_spec_key",
    "artifact_system_error_payload",
    "eval_json_contains_artifact_grader",
    "iter_artifact_grader_specs",
    "normalize_artifact_payload",
    "validate_artifact_results",
    "BinaryGrader",
    "GraderResult",
    "ConfidenceLogScoreGrader",
    "get_nested_value",
    "normalize_score",
    "SpatiotemporalEventF1Grader",
    "NumericRangeGrader",
    "NumericToleranceGrader",
    "MarkerGenePrecisionRecallGrader",
    "MarkerGeneSeparationGrader",
    "LabelSetJaccardGrader",
    "DistributionComparisonGrader",
    "SpatialAdjacencyGrader",
    "LocationRadiusListGrader",
    "PathRadiusListGrader",
    "PolygonFrameIoUListGrader",
    "PolygonIoUListGrader",
    "VolumeIoUListGrader",
    "MultipleChoiceGrader",
    "RefusalVocabGrader",
    "PredicateLeafGrader",
    "AllOfGrader",
    "AverageOfGrader",
    "ListMatchGrader",
    "DictMatchGrader",
    "evaluate_composite_predicate_leaf",
    "LongestSubsequenceGrader",
    "FinishedFileGrader",
    "GraderError",
    "GraderTransientError",
    "RubricCriterion",
    "RubricCriterionGraderOutput",
    "RubricCriterionJudgment",
    "RubricGrader",
    "RubricGraderConfig",
    "RubricGraderOutput",
    "RubricGraderOutputParseError",
    "RubricLengthPenaltyConfig",
    "RubricScoreResult",
    "GRADER_REGISTRY",
    "LLM_GRADER_REGISTRY",
    "compute_rubric_length_penalty",
    "compute_rubric_reward",
    "rubric_criterion_output_config",
    "get_grader",
    "grade_multiple_graders_single_answer",
]
