"""The `artifact` grader's contract: config schema, the `results.json` payload contract, spec
discovery, and the fail-closed payloads.

An artifact grader uses a Python script and JSON-declared checks, or a legacy
author-supplied package (`grader.sh` plus whatever it needs, as a gzipped
tarball in Latch Data) that the platform runs against a rollout's output directory:

    bash grader.sh --rollout_output_dir <dir> --trajectory_path <file> --grader_output_dir <dir>

and that must write `<grader_output_dir>/results.json` in the same per-grader payload shape every
other grader produces (`platform_grading.grader_result_payload`). Running the package needs a
sandbox, which only a sandbox-backed grading context provides (the Yeast `rollouts_flow`, through
`platform_grading.ArtifactRunner`); in-process evaluation fails closed as a configuration error.

The config field names and defaults mirror `eval_linter.types.ARTIFACT_COMPUTE_DEFAULTS`; the
linter only warns on unknown fields, so the models here ignore them rather than reject them.
"""

import hashlib
import json
import keyword
import math
import re
from typing import Any, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    SerializerFunctionWrapHandler,
    StrictBool,
    field_validator,
    model_serializer,
    model_validator,
)

from .base import BinaryGrader, GraderResult, configuration_error_result

ARTIFACT_GRADER_TYPE = "artifact"
ARTIFACT_GRADER_LABEL = "Artifact"
DEFAULT_ARTIFACT_SANDBOX_NAME = "artifact_grader_env_v1"
LATEST_SANDBOX_HASH = "latest"
ARTIFACT_ENTRYPOINT = "grader.sh"
ARTIFACT_RESULTS_FILENAME = "results.json"
ARTIFACT_STDERR_FILENAME = "stderr.log"
STDERR_TAIL_LINES = 50

LATCH_LDATA_PATH_PATTERN = re.compile(r"^latch://\d+\.(account|node)(/.*)?$")

ARTIFACT_NEEDS_SANDBOX_MESSAGE = """artifact graders run author code in its own sandbox and are only available when grading runs in a sandbox-backed context (the rollouts compute node with its sandbox grading backend); they cannot be evaluated in-process"""

COMPOSITE_GRADER_TYPES = ("all_of", "composite", "average_of")


class ArtifactSandbox(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    sandbox_name: str = DEFAULT_ARTIFACT_SANDBOX_NAME
    sandbox_hash: str = LATEST_SANDBOX_HASH

    @field_validator("sandbox_name", "sandbox_hash")
    @classmethod
    def _non_empty(cls, value: str) -> str:
        if not isinstance(value, str) or value.strip() == "":
            raise ValueError("must be a non-empty string")
        return value


class ArtifactCompute(BaseModel):
    model_config = ConfigDict(extra="ignore", frozen=True)

    sandbox: ArtifactSandbox = ArtifactSandbox()
    cpu: int = Field(default=2, ge=1)
    memory_gib: int = Field(default=4, ge=1)
    storage_gib: int = Field(default=12, ge=1)
    timeout_seconds: int = Field(default=300, ge=1)
    allow_internet: bool = False


def is_artifact_file_reference(value: Any) -> bool:
    """A data node or a file in the current Yeast run's explicit read-only mounts.

    Relative authoring paths must be bound by the importer before execution.
    Native paths are scoped to the run, never host filesystem paths.
    """
    if not isinstance(value, str) or not value or "\x00" in value:
        return False
    if LATCH_LDATA_PATH_PATTERN.fullmatch(value):
        return not any(part in {".", ".."} for part in value.split("/"))
    return value.startswith(("/workspace/", "/user/", "/references/")) and all(
        part not in {"", ".", ".."} for part in value.split("/")[1:]
    )


class ArtifactCheck(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    title: str
    reference_needed: StrictBool = False
    reference: Optional[str] = None

    @field_validator("reference_needed", mode="before")
    @classmethod
    def _empty_reference_needed(cls, value: Any) -> Any:
        if value is None or (isinstance(value, str) and not value.strip()):
            return False
        return value

    @field_validator("id")
    @classmethod
    def _callable_name(cls, value: str) -> str:
        if (
            not value.isascii()
            or not value.isidentifier()
            or keyword.iskeyword(value)
            or value.startswith("_")
        ):
            raise ValueError("check id must be a public Python function name")
        return value

    @field_validator("title")
    @classmethod
    def _title(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("title must not be blank")
        return value

    @model_validator(mode="after")
    def _reference_contract(self):
        if self.reference_needed:
            if not is_artifact_file_reference(self.reference):
                raise ValueError(
                    "reference_needed=true requires a valid reference file"
                )
        elif self.reference is not None:
            raise ValueError("reference must be omitted when reference_needed=false")
        return self


def is_artifact_grader_path(value: Any) -> bool:
    """A normalized file destination relative to the package's rollout output dir."""
    return (
        isinstance(value, str)
        and bool(value)
        and value == value.strip()
        and not value.startswith("/")
        and re.match(r"^[A-Za-z]:", value) is None
        and "\\" not in value
        and "\x00" not in value
        and all(part not in {"", ".", ".."} for part in value.split("/"))
        # The structured answer is a context file, never a directory. A role
        # may replace that file with the exact artifact selected by Decisions.
        and not value.startswith("eval_answer.json/")
    )


class ArtifactInput(BaseModel):
    """A semantic deliverable whose filename is chosen by the rollout agent."""

    model_config = ConfigDict(extra="forbid", frozen=True)
    description: str = Field(min_length=1)
    required: StrictBool = True
    grader_path: str | None = Field(
        default=None,
        description="Package input filename relative to rollout_output_dir.",
    )

    @field_validator("description")
    @classmethod
    def _description(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("description must not be blank")
        return value

    @field_validator("grader_path", mode="before")
    @classmethod
    def _grader_path(cls, value: Any) -> str:
        if not is_artifact_grader_path(value):
            raise ValueError(
                "grader_path must be a normalized relative file path; "
                "eval_answer.json cannot be a directory"
            )
        return value

    @model_serializer(mode="wrap")
    def _serialize(self, handler: SerializerFunctionWrapHandler) -> dict[str, Any]:
        data = handler(self)
        # Adding an opt-in field must not change persisted configs or spec hashes.
        if self.grader_path is None:
            data.pop("grader_path", None)
        return data


class ArtifactResolutionOptions(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    model: str
    max_cost_usd: float = Field(default=0.05, gt=0, allow_inf_nan=False)
    # Accepted for persisted evals and older flow callers; selection ignores both.
    min_confidence: float = Field(
        default=0.8,
        ge=0,
        le=1,
        allow_inf_nan=False,
        description="Deprecated and ignored: the highest-probability outcome wins.",
    )
    min_margin: float = Field(
        default=0.2,
        ge=0,
        le=1,
        allow_inf_nan=False,
        description="Deprecated and ignored: the highest-probability outcome wins.",
    )

    @field_validator("model")
    @classmethod
    def _model(cls, value: str) -> str:
        if value != "gpt-6-luna":
            raise ValueError("artifact Decisions resolution requires gpt-6-luna")
        return value


class ArtifactGraderConfig(BaseModel):
    """The `config` block of `{"type": "artifact", "config": {...}}`."""

    model_config = ConfigDict(extra="ignore", frozen=True)

    package: Optional[str] = None
    script: Optional[str] = None
    checks: list[ArtifactCheck] = Field(default_factory=list)
    compute: ArtifactCompute = ArtifactCompute()
    artifacts: dict[str, ArtifactInput] = Field(default_factory=dict)
    resolution: ArtifactResolutionOptions | None = None

    @field_validator("resolution", mode="before")
    @classmethod
    def _resolution(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("resolution must be an object")
        return value

    @field_validator("artifacts")
    @classmethod
    def _artifacts(cls, value: dict[str, ArtifactInput]) -> dict[str, ArtifactInput]:
        if len(value) > 400:
            raise ValueError("at most 400 semantic artifacts are supported")
        for name in value:
            if not name.isascii() or not name.isidentifier() or name.startswith("_"):
                raise ValueError("artifact roles must be public ASCII identifiers")
        return value

    @field_validator("package")
    @classmethod
    def _package_is_ldata_path(cls, value: Optional[str]) -> Optional[str]:
        if not isinstance(value, str) or LATCH_LDATA_PATH_PATTERN.match(value) is None:
            raise ValueError(
                "package must be a latch://<id>.node or latch://<workspace>.account/... path to the grading tarball"
            )
        return value

    @property
    def roles_only(self) -> bool:
        """Declares artifact roles (for rubric graders with `artifact`) and runs no author code."""
        return self.package is None and not (
            {"script", "checks"} & self.model_fields_set
        )

    @model_validator(mode="after")
    def _format(self):
        if self.artifacts and self.resolution is None:
            raise ValueError("resolution.model is required when artifacts are declared")
        grader_paths = [
            artifact.grader_path
            for artifact in self.artifacts.values()
            if artifact.grader_path is not None
        ]
        if grader_paths:
            if self.package is None:
                raise ValueError("grader_path is only supported for package graders")
            if len(grader_paths) != len(self.artifacts):
                raise ValueError("all artifact roles must declare grader_path or none")
            for index, destination in enumerate(grader_paths):
                for previous in grader_paths[:index]:
                    if (
                        destination == previous
                        or destination.startswith(previous + "/")
                        or previous.startswith(destination + "/")
                    ):
                        raise ValueError(
                            "grader_path destinations must be distinct and cannot "
                            "contain another destination"
                        )
        if self.package is not None:
            if "script" in self.model_fields_set or "checks" in self.model_fields_set:
                raise ValueError("package and script/checks formats cannot be combined")
        elif self.roles_only and self.artifacts:
            pass  # roles for rubric graders with `artifact`; no author code runs
        elif not is_artifact_file_reference(self.script):
            raise ValueError("script must be a data node or scoped Yeast file path")
        elif not self.checks:
            raise ValueError("checks must contain at least one check")
        elif len({check.id for check in self.checks}) != len(self.checks):
            raise ValueError("check ids must be unique")
        return self

    @model_serializer(mode="wrap")
    def _serialize(self, handler: SerializerFunctionWrapHandler) -> dict[str, Any]:
        data = handler(self)
        if not self.artifacts:
            data.pop("artifacts", None)
        if "resolution" not in self.model_fields_set:
            data.pop("resolution", None)
        # Preserve the mutually exclusive wire formats on model round-trips.
        if self.package is not None or self.roles_only:
            data.pop("script", None)
            data.pop("checks", None)
        if self.package is None:
            data.pop("package", None)
        return data


class ArtifactGraderSpec(BaseModel):
    """One artifact grader found in an eval. `key` is a content hash of the grader spec, so the
    same spec appearing twice (or inside a composite) maps to one package run."""

    model_config = ConfigDict(frozen=True)

    key: str
    config: ArtifactGraderConfig


def artifact_spec_key(grader_spec: dict[str, Any]) -> str:
    """Content hash of the grader's `config` alone, so the same package with the same compute
    block maps to one run wherever it appears and whatever `name`/`points` wrap it."""
    config = grader_spec.get("config") if isinstance(grader_spec, dict) else None
    canonical = json.dumps(config, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _walk_grader_specs(spec: Any, found: list[dict[str, Any]]) -> None:
    if not isinstance(spec, dict):
        return
    grader_type = spec.get("type")
    if grader_type == ARTIFACT_GRADER_TYPE:
        found.append(spec)
        return
    if grader_type in COMPOSITE_GRADER_TYPES:
        config = spec.get("config")
        children = config.get("children") if isinstance(config, dict) else None
        for child in children or []:
            _walk_grader_specs(child, found)


def iter_artifact_grader_dicts(eval_json: dict[str, Any]) -> list[dict[str, Any]]:
    """Every `type: artifact` grader dict in `grader` / `graders[]`, recursing through composites,
    in document order. Unlike `iter_artifact_grader_specs` this does not validate the configs."""
    found: list[dict[str, Any]] = []
    graders = eval_json.get("graders")
    specs = graders if isinstance(graders, list) else [eval_json.get("grader")]
    for spec in specs:
        _walk_grader_specs(spec, found)
    return found


def iter_artifact_grader_specs(eval_json: dict[str, Any]) -> list[ArtifactGraderSpec]:
    """Every valid artifact grader in the eval, deduplicated by spec key. Invalid configs are
    skipped here; they surface as configuration errors when the grader is evaluated."""
    specs: list[ArtifactGraderSpec] = []
    seen: set[str] = set()
    for grader_spec in iter_artifact_grader_dicts(eval_json):
        config = grader_spec.get("config")
        if not isinstance(config, dict):
            continue
        try:
            parsed = ArtifactGraderConfig.model_validate(config)
        except ValueError:
            continue
        key = artifact_spec_key(grader_spec)
        if key in seen:
            continue
        seen.add(key)
        specs.append(ArtifactGraderSpec(key=key, config=parsed))
    return specs


def eval_json_contains_artifact_grader(eval_json: dict[str, Any]) -> bool:
    return bool(iter_artifact_grader_dicts(eval_json))


def is_roles_only_artifact_config(config: Any) -> bool:
    """An artifact grader config that only declares roles: no package, script or checks. At the
    top level it gates the eval on its required deliverables without scoring."""
    return (
        isinstance(config, dict)
        and bool(config.get("artifacts"))
        and not {"package", "script", "checks"} & config.keys()
    )


def artifact_sandbox_names(eval_json: dict[str, Any]) -> list[str]:
    """Distinct sandbox names the eval's artifact graders run in, for hash resolution."""
    names: list[str] = []
    for spec in iter_artifact_grader_specs(eval_json):
        name = spec.config.compute.sandbox.sandbox_name
        if name not in names:
            names.append(name)
    return names


def _is_finite_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def validate_artifact_results(payload: Any) -> list[str]:
    """Problems with a `results.json` object; empty when it is a valid per-grader payload.

    The backend aggregator needs `passed`, `metrics`, `raw_score` and `score_max` with the right
    types (anything else is a "Malformed grader result"); the console needs `score`; a string in
    `field_scores` breaks the eval page. NaN/Infinity are not JSON and are rejected by the parser
    before this runs, but a float that slipped through is still refused."""
    if not isinstance(payload, dict):
        return ["results.json must be a JSON object"]
    problems: list[str] = []
    if not isinstance(payload.get("passed"), bool):
        problems.append("passed must be a boolean")
    raw_score = payload.get("raw_score")
    if not _is_finite_number(raw_score):
        problems.append("raw_score must be a finite number")
    score_max = payload.get("score_max")
    if not _is_finite_number(score_max):
        problems.append("score_max must be a finite number")
    elif float(score_max) <= 0.0:
        problems.append("score_max must be greater than 0")
    score = payload.get("score")
    if score is not None and not _is_finite_number(score):
        problems.append("score must be a finite number when present")
    elif _is_finite_number(score) and not 0.0 <= float(score) <= 1.0:
        problems.append("score must be between 0 and 1")
    if not isinstance(payload.get("metrics"), dict):
        problems.append("metrics must be an object")
    reasoning = payload.get("reasoning")
    if reasoning is not None and not isinstance(reasoning, str):
        problems.append("reasoning must be a string when present")
    field_scores = payload.get("field_scores")
    if field_scores is not None:
        if not isinstance(field_scores, dict):
            problems.append("field_scores must be an object")
        else:
            for name, value in field_scores.items():
                if not isinstance(name, str) or not _is_finite_number(value):
                    problems.append(f"field_scores[{name!r}] must be a finite number")
                    break
    agent_answer = payload.get("agent_answer")
    if agent_answer is not None and not isinstance(agent_answer, dict):
        problems.append("agent_answer must be an object or null")
    return problems


def normalize_artifact_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """A validated `results.json` as the platform stores it: `metrics.type` is `artifact`, `score`
    is recomputed from `raw_score / score_max` (the aggregator does the same), optional fields get
    their defaults, and unknown top-level keys are dropped."""
    raw_score = float(payload["raw_score"])
    score_max = float(payload["score_max"])
    metrics = dict(payload["metrics"])
    metrics["type"] = ARTIFACT_GRADER_TYPE
    return {
        "passed": bool(payload["passed"]),
        "metrics": metrics,
        "reasoning": payload.get("reasoning") or "",
        "agent_answer": payload.get("agent_answer"),
        "score": min(1.0, max(0.0, raw_score / score_max)),
        "raw_score": raw_score,
        "score_max": score_max,
        "field_scores": dict(payload.get("field_scores") or {}),
    }


def stderr_tail(text: Optional[str], lines: int = STDERR_TAIL_LINES) -> str:
    if not text:
        return ""
    return "\n".join(text.rstrip("\n").splitlines()[-lines:])


def artifact_system_error_payload(
    error: str,
    *,
    stderr: Optional[str] = None,
    agent_answer: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """The fail-closed result the runtime substitutes when `grader.sh` exits non-zero, times out,
    or does not write a valid `results.json`. `metrics.grader_system_error` tells the platform this
    was the grader's failure, not a wrong agent answer."""
    tail = stderr_tail(stderr)
    reasoning = (
        error
        if not tail
        else f"{error}\n\nstderr (last {STDERR_TAIL_LINES} lines):\n{tail}"
    )
    return {
        "passed": False,
        "metrics": {
            "type": ARTIFACT_GRADER_TYPE,
            "grader_system_error": True,
            "grader_error": error,
        },
        "reasoning": reasoning,
        "agent_answer": agent_answer,
        "score": 0.0,
        "raw_score": 0.0,
        "score_max": 1.0,
        "field_scores": {},
    }


class ArtifactGrader(BinaryGrader):
    """In-process placeholder for the `artifact` grader type. It validates the config and then
    fails closed: executing a package needs a sandbox, which only a sandbox-backed grading context
    supplies (`platform_grading.ArtifactRunner`). Registered separately from `GRADER_REGISTRY`
    (`SANDBOX_GRADER_REGISTRY`) so the in-process registry keeps its guarantee that every grader in
    it can award credit."""

    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        if not isinstance(config, dict):
            return configuration_error_result(
                agent_answer, ARTIFACT_GRADER_LABEL, "config must be an object"
            )
        try:
            ArtifactGraderConfig.model_validate(config)
        except ValueError as exc:
            return configuration_error_result(
                agent_answer, ARTIFACT_GRADER_LABEL, str(exc)
            )
        return configuration_error_result(
            agent_answer, ARTIFACT_GRADER_LABEL, ARTIFACT_NEEDS_SANDBOX_MESSAGE
        )
