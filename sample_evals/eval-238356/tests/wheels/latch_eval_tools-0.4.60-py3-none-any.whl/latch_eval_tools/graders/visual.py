from __future__ import annotations

from typing import cast

from .base import (
    BinaryGrader,
    GraderResult,
    configuration_error_result,
    get_nested_value,
)
from .geometry import (
    _MAX_LOCATION_LIST_COUNT,
    _MAX_POLYGON_LIST_COUNT,
    GeometryBackendError,
    locations_list_to_locations_list_match,
    normalize_coords_list,
    normalize_frame_range,
    normalize_frame_tolerance,
    normalize_matching,
    normalize_path_component_scales,
    normalize_path_list,
    normalize_polygon_list,
    normalize_reference_polygon_event_set,
    normalize_reference_volume_set,
    normalize_scoring,
    paths_list_to_paths_list_match,
    polygon_events_list_to_polygon_events_list_match,
    polygons_list_to_polygons_list_match,
    validate_path_list_support,
    validate_path_numeric_support,
    volumes_list_to_volumes_list_match,
)
from .number_contract import is_finite_number

_GRADER_NAME = "Location Radius List"
_PATH_GRADER_NAME = "Path Radius List"
_POLYGON_GRADER_NAME = "Polygon IoU List"
_VOLUME_GRADER_NAME = "Volume IoU List"
_POLYGON_FRAME_GRADER_NAME = "Polygon Frame IoU List"


def _finite_float(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if not is_finite_number(value):
        return None
    try:
        parsed = float(value)
        if isinstance(value, int) and int(parsed) != value:
            return None
    except (OverflowError, TypeError, ValueError):
        return None
    return parsed


def _failure(
    agent_answer: object,
    reason: str,
    grader_name: str = _GRADER_NAME,
) -> GraderResult:
    return GraderResult(
        passed=False,
        metrics={},
        reasoning=f"{grader_name}: FAIL\n\n  x {reason}",
        agent_answer=agent_answer if isinstance(agent_answer, dict) else None,
        score=0.0,
    )


def _matching_strategy(
    agent_answer: object, config: dict, grader_name: str
) -> tuple[str | None, GraderResult | None]:
    try:
        return normalize_matching(config.get("matching")), None
    except ValueError as exc:
        return None, configuration_error_result(agent_answer, grader_name, str(exc))


def _scoring_mode(
    agent_answer: object, config: dict, grader_name: str
) -> tuple[str | None, GraderResult | None]:
    try:
        return normalize_scoring(config.get("scoring")), None
    except ValueError as exc:
        return None, configuration_error_result(agent_answer, grader_name, str(exc))


def _list_score(stats: dict[str, object], scoring: str | None) -> tuple[float, str]:
    """The score under ``scoring`` and a reasoning suffix describing it.

    ``binary`` is the F1 of matched counts. ``continuous`` weights each
    matched pair by its match quality (IoU, or ``1 - distance / radius``) so
    partial overlaps carry through to the score.
    """

    if scoring == "continuous":
        score = cast(float, stats["quality_f1"])
        mean_quality = cast(float, stats["mean_match_quality"])
        return score, (
            f"\n  Continuous score {score:.3f} (mean match quality {mean_quality:.3f})"
        )
    return cast(float, stats["f1"]), ""


def _system_failure(
    agent_answer: object,
    reason: str,
    grader_name: str,
) -> GraderResult:
    return GraderResult(
        passed=False,
        metrics={"grader_error": reason, "grader_system_error": True},
        reasoning=f"{grader_name}: SYSTEM ERROR\n\n  x {reason}",
        agent_answer=agent_answer if isinstance(agent_answer, dict) else None,
        score=0.0,
    )


class LocationRadiusListGrader(BinaryGrader):
    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        if not isinstance(config, dict):
            return configuration_error_result(
                agent_answer, _GRADER_NAME, "config must be an object"
            )

        try:
            references = normalize_coords_list(
                config.get("reference_locations"), "reference_locations"
            )
        except ValueError as exc:
            return configuration_error_result(agent_answer, _GRADER_NAME, str(exc))

        if not references:
            return configuration_error_result(
                agent_answer,
                _GRADER_NAME,
                "reference_locations must not be empty",
            )
        if len(references) > _MAX_LOCATION_LIST_COUNT:
            return configuration_error_result(
                agent_answer,
                _GRADER_NAME,
                f"reference_locations must contain at most {_MAX_LOCATION_LIST_COUNT} items",
            )

        dimensions = len(references[0])
        if any(len(location) != dimensions for location in references):
            return configuration_error_result(
                agent_answer,
                _GRADER_NAME,
                "reference locations must have matching dimensions",
            )

        radius = _finite_float(config.get("tolerance_radius"))
        if radius is None or radius < 0:
            return configuration_error_result(
                agent_answer,
                _GRADER_NAME,
                "tolerance_radius must be a finite non-negative number",
            )

        pass_threshold = _finite_float(config.get("pass_threshold", 1.0))
        if pass_threshold is None or not 0 < pass_threshold <= 1:
            return configuration_error_result(
                agent_answer,
                _GRADER_NAME,
                "pass_threshold must be a finite number in (0, 1]",
            )

        matching, matching_error = _matching_strategy(
            agent_answer, config, _GRADER_NAME
        )
        if matching_error is not None:
            return matching_error
        scoring, scoring_error = _scoring_mode(agent_answer, config, _GRADER_NAME)
        if scoring_error is not None:
            return scoring_error

        field = config.get("answer_field")
        if not isinstance(field, str) or not field:
            return configuration_error_result(
                agent_answer,
                _GRADER_NAME,
                "answer_field must be a non-empty string",
            )

        if not isinstance(agent_answer, dict):
            return _failure(agent_answer, "agent answer must be an object")

        submitted, found = get_nested_value(agent_answer, field)
        if not found:
            return _failure(agent_answer, f"missing required field: {field}")

        try:
            stats = locations_list_to_locations_list_match(
                references, submitted, radius, matching=matching
            )
        except ValueError as exc:
            return _failure(agent_answer, str(exc))

        score, score_note = _list_score(stats, scoring)
        passed = score >= pass_threshold
        metrics = {
            **stats,
            "answer_field": field,
            "pass_threshold": pass_threshold,
            "scoring": scoring,
        }

        return GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning=(
                f"{_GRADER_NAME}: {'PASS' if passed else 'FAIL'}\n\n"
                f"  Matched {stats['matched_count']}/{stats['reference_count']} "
                f"reference locations{score_note}"
            ),
            agent_answer=agent_answer,
            score=score,
        )


class PathRadiusListGrader(BinaryGrader):
    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        if not isinstance(config, dict):
            return configuration_error_result(
                agent_answer, _PATH_GRADER_NAME, "config must be an object"
            )

        try:
            references = normalize_path_list(
                config.get("reference_paths"), "reference_paths"
            )
            if not references:
                raise ValueError("reference_paths must not be empty")
            dimension = len(references[0][0])
            if any(len(path[0]) != dimension for path in references):
                raise ValueError("reference paths must have matching dimensions")
            scales = normalize_path_component_scales(
                config.get("component_scales"), dimension
            )
            for index, reference in enumerate(references):
                validate_path_numeric_support(
                    reference,
                    component_scales=scales,
                    err_label=f"reference_paths[{index}]",
                )
            validate_path_list_support(references)
        except ValueError as exc:
            return configuration_error_result(agent_answer, _PATH_GRADER_NAME, str(exc))

        radius = _finite_float(config.get("tolerance_radius"))
        if radius is None or radius < 0:
            return configuration_error_result(
                agent_answer,
                _PATH_GRADER_NAME,
                "tolerance_radius must be a finite non-negative number",
            )

        pass_threshold = _finite_float(config.get("pass_threshold", 1.0))
        if pass_threshold is None or not 0 < pass_threshold <= 1:
            return configuration_error_result(
                agent_answer,
                _PATH_GRADER_NAME,
                "pass_threshold must be a finite number in (0, 1]",
            )

        matching, matching_error = _matching_strategy(
            agent_answer, config, _PATH_GRADER_NAME
        )
        if matching_error is not None:
            return matching_error
        scoring, scoring_error = _scoring_mode(agent_answer, config, _PATH_GRADER_NAME)
        if scoring_error is not None:
            return scoring_error

        field = config.get("answer_field")
        if not isinstance(field, str) or not field:
            return configuration_error_result(
                agent_answer,
                _PATH_GRADER_NAME,
                "answer_field must be a non-empty string",
            )

        if not isinstance(agent_answer, dict):
            return _failure(
                agent_answer,
                "agent answer must be an object",
                _PATH_GRADER_NAME,
            )

        submitted, found = get_nested_value(agent_answer, field)
        if not found:
            return _failure(
                agent_answer,
                f"missing required field: {field}",
                _PATH_GRADER_NAME,
            )

        try:
            stats = paths_list_to_paths_list_match(
                references,
                submitted,
                radius,
                component_scales=scales,
                matching=matching,
            )
        except ValueError as exc:
            return _failure(agent_answer, str(exc), _PATH_GRADER_NAME)

        score, score_note = _list_score(stats, scoring)
        passed = score >= pass_threshold
        metrics = {
            **stats,
            "answer_field": field,
            "pass_threshold": pass_threshold,
            "scoring": scoring,
        }

        return GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning=(
                f"{_PATH_GRADER_NAME}: {'PASS' if passed else 'FAIL'}\n\n"
                f"  Matched {stats['matched_count']}/{stats['reference_count']} "
                f"reference paths{score_note}"
            ),
            agent_answer=agent_answer,
            score=score,
        )


class PolygonIoUListGrader(BinaryGrader):
    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        if not isinstance(config, dict):
            return configuration_error_result(
                agent_answer, _POLYGON_GRADER_NAME, "config must be an object"
            )

        iou_threshold = _finite_float(config.get("iou_threshold"))
        if iou_threshold is None or not 0 < iou_threshold <= 1:
            return configuration_error_result(
                agent_answer,
                _POLYGON_GRADER_NAME,
                "iou_threshold must be a finite number in (0, 1]",
            )

        references = config.get("reference_polygons")
        try:
            if not normalize_polygon_list(references, "reference polygons"):
                raise ValueError("reference polygons must not be empty")
        except ValueError as exc:
            return configuration_error_result(
                agent_answer, _POLYGON_GRADER_NAME, str(exc)
            )

        pass_threshold = _finite_float(config.get("pass_threshold", 1.0))
        if pass_threshold is None or not 0 < pass_threshold <= 1:
            return configuration_error_result(
                agent_answer,
                _POLYGON_GRADER_NAME,
                "pass_threshold must be a finite number in (0, 1]",
            )

        matching, matching_error = _matching_strategy(
            agent_answer, config, _POLYGON_GRADER_NAME
        )
        if matching_error is not None:
            return matching_error
        scoring, scoring_error = _scoring_mode(
            agent_answer, config, _POLYGON_GRADER_NAME
        )
        if scoring_error is not None:
            return scoring_error

        field = config.get("answer_field")
        if not isinstance(field, str) or not field:
            return configuration_error_result(
                agent_answer,
                _POLYGON_GRADER_NAME,
                "answer_field must be a non-empty string",
            )

        if not isinstance(agent_answer, dict):
            return _failure(
                agent_answer,
                "agent answer must be an object",
                _POLYGON_GRADER_NAME,
            )

        submitted, found = get_nested_value(agent_answer, field)
        if not found:
            return _failure(
                agent_answer,
                f"missing required field: {field}",
                _POLYGON_GRADER_NAME,
            )

        try:
            stats = polygons_list_to_polygons_list_match(
                references, submitted, iou_threshold, matching=matching
            )
        except GeometryBackendError as exc:
            return _system_failure(agent_answer, str(exc), _POLYGON_GRADER_NAME)
        except ValueError as exc:
            return _failure(agent_answer, str(exc), _POLYGON_GRADER_NAME)

        score, score_note = _list_score(stats, scoring)
        passed = score >= pass_threshold
        metrics = {
            **stats,
            "answer_field": field,
            "pass_threshold": pass_threshold,
            "scoring": scoring,
        }

        return GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning=(
                f"{_POLYGON_GRADER_NAME}: {'PASS' if passed else 'FAIL'}\n\n"
                f"  Matched {stats['matched_count']}/{stats['reference_count']} "
                f"reference polygons{score_note}"
            ),
            agent_answer=agent_answer,
            score=score,
        )


class VolumeIoUListGrader(BinaryGrader):
    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        if not isinstance(config, dict):
            return configuration_error_result(
                agent_answer, _VOLUME_GRADER_NAME, "config must be an object"
            )

        iou_threshold = _finite_float(config.get("iou_threshold"))
        if iou_threshold is None or not 0 < iou_threshold <= 1:
            return configuration_error_result(
                agent_answer,
                _VOLUME_GRADER_NAME,
                "iou_threshold must be a finite number in (0, 1]",
            )

        references = config.get("reference_volumes")
        try:
            normalize_reference_volume_set(references, "reference_volumes")
        except ValueError as exc:
            return configuration_error_result(
                agent_answer, _VOLUME_GRADER_NAME, str(exc)
            )

        pass_threshold = _finite_float(config.get("pass_threshold", 1.0))
        if pass_threshold is None or not 0 < pass_threshold <= 1:
            return configuration_error_result(
                agent_answer,
                _VOLUME_GRADER_NAME,
                "pass_threshold must be a finite number in (0, 1]",
            )

        matching, matching_error = _matching_strategy(
            agent_answer, config, _VOLUME_GRADER_NAME
        )
        if matching_error is not None:
            return matching_error
        scoring, scoring_error = _scoring_mode(
            agent_answer, config, _VOLUME_GRADER_NAME
        )
        if scoring_error is not None:
            return scoring_error

        field = config.get("answer_field")
        if not isinstance(field, str) or not field:
            return configuration_error_result(
                agent_answer,
                _VOLUME_GRADER_NAME,
                "answer_field must be a non-empty string",
            )

        if not isinstance(agent_answer, dict):
            return _failure(
                agent_answer,
                "agent answer must be an object",
                _VOLUME_GRADER_NAME,
            )

        submitted, found = get_nested_value(agent_answer, field)
        if not found:
            return _failure(
                agent_answer,
                f"missing required field: {field}",
                _VOLUME_GRADER_NAME,
            )

        try:
            stats = volumes_list_to_volumes_list_match(
                references, submitted, iou_threshold, matching=matching
            )
        except GeometryBackendError as exc:
            return _system_failure(agent_answer, str(exc), _VOLUME_GRADER_NAME)
        except ValueError as exc:
            return _failure(agent_answer, str(exc), _VOLUME_GRADER_NAME)

        score, score_note = _list_score(stats, scoring)
        passed = score >= pass_threshold
        metrics = {
            **stats,
            "answer_field": field,
            "pass_threshold": pass_threshold,
            "scoring": scoring,
        }

        return GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning=(
                f"{_VOLUME_GRADER_NAME}: {'PASS' if passed else 'FAIL'}\n\n"
                f"  Matched {stats['matched_count']}/{stats['reference_count']} "
                f"reference volumes{score_note}"
            ),
            agent_answer=agent_answer,
            score=score,
        )


class PolygonFrameIoUListGrader(BinaryGrader):
    """``polygon_iou_list`` for polygons observed at frames.

    Each reference and submitted event is ``{"frame": int, "polygon": ring}``.
    A pair matches when the frames differ by at most ``frame_tolerance`` and
    the 2D IoU reaches ``iou_threshold``; both bounds are inclusive and
    independent. ``matching``, ``scoring``, and ``pass_threshold`` follow the
    other list graders. An optional ``frame_range`` is the inclusive scoring
    window: reference events must lie inside it and submitted events outside
    it stay unmatched.
    """

    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        name = _POLYGON_FRAME_GRADER_NAME
        if not isinstance(config, dict):
            return configuration_error_result(
                agent_answer, name, "config must be an object"
            )

        iou_threshold = _finite_float(config.get("iou_threshold"))
        if iou_threshold is None or not 0 < iou_threshold <= 1:
            return configuration_error_result(
                agent_answer, name, "iou_threshold must be a finite number in (0, 1]"
            )

        try:
            normalize_frame_tolerance(config.get("frame_tolerance"))
            frame_range = normalize_frame_range(config.get("frame_range"))
            normalize_reference_polygon_event_set(
                config.get("reference_events"),
                "reference events",
                frame_range=frame_range,
            )
        except ValueError as exc:
            return configuration_error_result(agent_answer, name, str(exc))

        pass_threshold = _finite_float(config.get("pass_threshold", 1.0))
        if pass_threshold is None or not 0 < pass_threshold <= 1:
            return configuration_error_result(
                agent_answer, name, "pass_threshold must be a finite number in (0, 1]"
            )

        matching, matching_error = _matching_strategy(agent_answer, config, name)
        if matching_error is not None:
            return matching_error
        scoring, scoring_error = _scoring_mode(agent_answer, config, name)
        if scoring_error is not None:
            return scoring_error

        field = config.get("answer_field")
        if not isinstance(field, str) or not field:
            return configuration_error_result(
                agent_answer, name, "answer_field must be a non-empty string"
            )

        if not isinstance(agent_answer, dict):
            return _failure(agent_answer, "agent answer must be an object", name)

        submitted, found = get_nested_value(agent_answer, field)
        if not found:
            return _failure(agent_answer, f"missing required field: {field}", name)

        try:
            stats = polygon_events_list_to_polygon_events_list_match(
                config["reference_events"],
                submitted,
                iou_threshold,
                frame_tolerance=config["frame_tolerance"],
                frame_range=config.get("frame_range"),
                matching=matching,
            )
        except GeometryBackendError as exc:
            return _system_failure(agent_answer, str(exc), name)
        except ValueError as exc:
            return _failure(agent_answer, str(exc), name)

        score, score_note = _list_score(stats, scoring)
        passed = score >= pass_threshold
        metrics = {
            **stats,
            "answer_field": field,
            "pass_threshold": pass_threshold,
            "scoring": scoring,
        }

        return GraderResult(
            passed=passed,
            metrics=metrics,
            reasoning=(
                f"{name}: {'PASS' if passed else 'FAIL'}\n\n"
                f"  Matched {stats['matched_count']}/{stats['reference_count']} "
                f"reference events{score_note}"
            ),
            agent_answer=agent_answer,
            score=score,
        )
