"""Exact, unbounded logarithmic reward for a declared categorical answer.

The nullable score and explicit state keep zero-probability outcomes valid
without putting non-standard Infinity tokens on a JSON/database boundary.
"""

import json
import math
import statistics
from typing import Any

from .base import BinaryGrader, GraderResult

CONFIDENCE_GRADER = "confidence_log_score"
CONFIDENCE_REWARD = "log_confidence_v1"


def validate_confidence_config(config: object) -> str | None:
    if not isinstance(config, dict):
        return "config must be an object"
    if set(config) != {"options", "correct_option", "response_format"}:
        return "config requires only options, correct_option and response_format"
    options = config["options"]
    if options not in (["A", "B"], ["A", "B", "C"], ["A", "B", "C", "D"]):
        return "options must be A/B, A/B/C or A/B/C/D"
    if config["correct_option"] not in options:
        return "correct_option must be among options"
    if config["response_format"] not in ("binary_complement", "full_vector"):
        return "response_format must be binary_complement or full_vector"
    if config["response_format"] == "binary_complement" and options != ["A", "B"]:
        return "binary_complement requires exactly A/B"
    return None


def confidence_answer_fields(config: dict) -> list[str]:
    if validate_confidence_config(config) is not None:
        return []
    options = (
        ["A"] if config["response_format"] == "binary_complement" else config["options"]
    )
    return [f"confidence_{option}" for option in options]


def contains_confidence_grader(value: object) -> bool:
    if isinstance(value, list):
        return any(contains_confidence_grader(item) for item in value)
    if not isinstance(value, dict):
        return False
    if value.get("type") == CONFIDENCE_GRADER:
        return True
    config = value.get("config")
    return isinstance(config, dict) and contains_confidence_grader(
        config.get("children")
    )


def confidence_bundle_error(specs: list, scoring: object = None) -> str | None:
    if not contains_confidence_grader(specs):
        return None
    if len(specs) != 1 or specs[0].get("type") != CONFIDENCE_GRADER:
        return "confidence_log_score must be the sole top-level grader (no composites)"
    if scoring is not None or "points" in specs[0] or "required" in specs[0]:
        return "confidence_log_score does not support weighted points or alternate pass rules"
    return None


def unavailable_confidence_result(
    agent_answer: object, error: str, *, configuration_error: bool = False
) -> GraderResult:
    try:
        json.dumps(agent_answer, allow_nan=False)
    except (ValueError, TypeError, OverflowError):
        # The raw submission remains in the trajectory; invalid Python values
        # must not make the grader's own result non-interoperable JSON.
        agent_answer = None
    return GraderResult(
        passed=None,
        score=None,
        reward_type=CONFIDENCE_REWARD,
        score_state="unavailable",
        metrics={
            "valid": None if configuration_error else False,
            "configuration_error" if configuration_error else "invalid_answer": error,
        },
        reasoning=error,
        agent_answer=agent_answer if isinstance(agent_answer, dict) else None,
    )


class ConfidenceLogScoreGrader(BinaryGrader):
    def evaluate_answer(self, agent_answer: dict, config: dict) -> GraderResult:
        error = validate_confidence_config(config)
        if error is not None:
            return unavailable_confidence_result(
                agent_answer, error, configuration_error=True
            )
        fields = confidence_answer_fields(config)
        if not isinstance(agent_answer, dict) or set(agent_answer) != set(fields):
            return unavailable_confidence_result(
                agent_answer, f"Required fields: {', '.join(fields)}"
            )
        for field in fields:
            value = agent_answer[field]
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                return unavailable_confidence_result(
                    agent_answer, f"{field} must be a JSON number"
                )
            # Bounds first, so arbitrarily large JSON integers do not overflow isfinite.
            if not 0 <= value <= 100 or not math.isfinite(value):
                return unavailable_confidence_result(
                    agent_answer, f"{field} must be finite and in [0,100]"
                )
        percentages = dict(agent_answer)
        if config["response_format"] == "binary_complement":
            percentages["confidence_B"] = 100 - percentages["confidence_A"]
        elif not math.isclose(
            math.fsum(percentages.values()), 100, rel_tol=0, abs_tol=1e-6
        ):
            return unavailable_confidence_result(
                agent_answer, "Confidence percentages must sum to 100 within 1e-6"
            )
        confidence = percentages[f"confidence_{config['correct_option']}"]
        probability = confidence / 100
        score = (
            None
            if confidence == 0
            else (
                1 + math.log2(probability)
                if probability > 0
                else 1 + math.log2(confidence) - math.log2(100)
            )
        )
        preferred = [
            o
            for o in config["options"]
            if percentages[f"confidence_{o}"] == max(percentages.values())
        ]
        passed = preferred == [config["correct_option"]]
        brier_reward = 1 - math.fsum(
            (percentages[f"confidence_{o}"] / 100 - (o == config["correct_option"])) ** 2
            for o in config["options"]
        ) / 2
        return GraderResult(
            passed=passed,
            score=score,
            reward_type=CONFIDENCE_REWARD,
            score_state="negative_infinity" if confidence == 0 else "finite",
            metrics={
                "valid": True,
                "confidence_percentages": percentages,
                "p_correct": probability,
                "confidence_correct_percent": confidence,
                "brier_reward": brier_reward,
                "probability_underflow": confidence > 0 and probability == 0,
                "choice_pass": passed,
                "choice_tie": len(preferred) > 1,
                "preferred_options": preferred,
            },
            reasoning="Exact confidence reward: 1 + log2(probability on the correct option)",
            agent_answer=agent_answer,
        )


def summarize_confidence_results(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize persisted grader payloads, retaining invalid and zero outcomes."""
    valid = [r for r in results if r.get("metrics", {}).get("valid") is True]
    scores = [r["score"] for r in valid if r.get("score_state") == "finite"]
    zeros = sum(r.get("score_state") == "negative_infinity" for r in valid)
    n = len(valid)
    return {
        "reward_type": CONFIDENCE_REWARD,
        "completed_answers": len(results),
        "valid_answers": n,
        "invalid_answers": sum(
            r.get("metrics", {}).get("valid") is False for r in results
        ),
        "unavailable_grades": sum(
            r.get("metrics", {}).get("valid") is None for r in results
        ),
        "choice_passes": sum(r["metrics"]["choice_pass"] for r in valid),
        "choice_ties": sum(r["metrics"]["choice_tie"] for r in valid),
        "choice_pass_rate": sum(r["metrics"]["choice_pass"] for r in valid) / n
        if n
        else None,
        "mean_correct_option_confidence_percent": statistics.mean(
            r["metrics"]["confidence_correct_percent"] for r in valid
        )
        if n
        else None,
        "mean_score": statistics.mean(scores) if scores and not zeros else None,
        "mean_score_state": "negative_infinity"
        if zeros
        else "finite"
        if scores
        else "unavailable",
        "sample_variance_ddof1": statistics.variance(scores)
        if len(scores) >= 2 and not zeros
        else None,
        "zero_probability_correct": zeros,
    }


def completed_confidence_payload(entry: dict) -> dict | None:
    payload = entry.get("grader_result")
    if not isinstance(payload, dict) or payload.get("reward_type") != CONFIDENCE_REWARD:
        return None
    if payload.get("metrics", {}).get("valid") in (True, False):
        return payload
    return None
